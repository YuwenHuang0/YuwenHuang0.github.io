"""A small Ising model, the program of Laboratory Slides 3.

This module contains the code behind Laboratory Slides 3. Every function is
named as on the slides, and every number that the slides quote is printed by
``python ising.py``. The command ``python ising.py --check`` compares the
column-by-column closing with brute-force enumeration, the variance of the
energy with a finite difference of the entropy, and the log-sum-exp with the
direct sum wherever the direct sum is finite; it exits non-zero on any
mismatch.

The model (Definition 1 of the laboratory, after Ising 1925). A grid of
``rows x cols`` sites carries one spin ``s_i`` in ``{-1, +1}`` per site. The
sites are numbered row by row, so that site ``r * cols + c`` sits in row
``r`` and column ``c``. Every pair of horizontal or vertical neighbours is an
edge. The energy of a configuration is

    E(s) = - J * sum over edges (i, j) of s_i s_j  -  h * sum over sites of s_i,

with the coupling ``J = 1`` and the field ``h = 0`` unless stated otherwise.
The Boltzmann distribution at temperature ``T`` is ``p_T(s) = exp(-E(s)/T) /
Z_T`` with the partition function ``Z_T = sum over s of exp(-E(s)/T)``
(Lecture Slides 3, Definition 19).

Conventions shared by every function.

* A configuration is a vector of ``n`` spins, each ``-1`` or ``+1``.
  ``all_configurations(n)`` lists all ``2**n`` of them in one array of shape
  ``(2**n, n)``; row ``k`` is the configuration whose site ``i`` has the spin
  ``+1`` when bit ``i`` of ``k`` is one and ``-1`` otherwise, so site 0 is the
  least significant bit.
* The value ``x_i = (s_i + 1) / 2`` in ``{0, 1}`` is the variable of Lecture
  Slides 3; ``s_i = 2 x_i - 1`` is the spin.
* A distribution ``p`` is an array of ``2**n`` probabilities in the order of
  ``all_configurations(n)``.
* All logarithms are natural, so entropies and divergences are in nats.
"""

from __future__ import annotations

import json
import math
import os
import sys
from decimal import Decimal, ROUND_HALF_UP

import numpy as np

# ==========================================================================
# Section 1. Sites, edges and configurations
# ==========================================================================


def grid_edges(rows, cols):
    """Return the edges of a grid with free boundary, as a list of pairs.

    Sites are numbered row by row. Each site is joined to its right
    neighbour and to the neighbour below it, when they exist, so a grid of
    ``rows x cols`` sites has ``rows * (cols - 1) + (rows - 1) * cols``
    edges: 24 for the 4 x 4 grid of the laboratory.
    """
    edges = []
    for r in range(rows):
        for c in range(cols):
            i = r * cols + c
            if c + 1 < cols:
                edges.append((i, i + 1))
            if r + 1 < rows:
                edges.append((i, i + cols))
    return edges


def chain_edges(n):
    """Return the ``n - 1`` edges of a chain of ``n`` sites."""
    return [(i, i + 1) for i in range(n - 1)]


def all_configurations(n):
    """Return every configuration of ``n`` spins as an int8 array.

    The array has shape ``(2**n, n)``. Row ``k`` is the configuration in
    which site ``i`` carries the spin ``+1`` when bit ``i`` of the integer
    ``k`` is one and the spin ``-1`` otherwise. Site 0 is therefore the least
    significant bit, row 0 is the configuration of all ``-1`` and the last
    row is the configuration of all ``+1``.
    """
    states = np.arange(1 << n)
    spins = np.empty((1 << n, n), dtype=np.int8)
    for i in range(n):
        spins[:, i] = 2 * ((states >> i) & 1) - 1
    return spins


# ==========================================================================
# Section 2. The energy
# ==========================================================================


def _edge_couplings(J, edges):
    """Return one coupling per edge from a scalar, a sequence or a matrix."""
    J = np.asarray(J, dtype=float)
    if J.ndim == 0:
        return np.full(len(edges), float(J))
    if J.ndim == 1:
        if len(J) != len(edges):
            raise ValueError("one coupling per edge is required")
        return J
    if J.ndim == 2:
        return np.array([J[i, j] for (i, j) in edges], dtype=float)
    raise ValueError("J must be a scalar, a sequence over the edges or a matrix")


def ising_energy(spins, edges, J=1.0, h=0.0):
    """Return the energy ``E(s) = -J sum s_i s_j - h sum s_i``.

    Parameters
    ----------
    spins : array of shape ``(n,)`` or ``(m, n)``
        One configuration, or a batch of ``m`` configurations.
    edges : list of pairs ``(i, j)``
        The edges of the graph.
    J : scalar, a sequence with one entry per edge, or an ``n x n`` matrix
        The coupling. A matrix is read at the entries ``J[i, j]`` of the
        edges, which is how the Hebbian couplings of exploration E4 enter.
    h : scalar or a sequence with one entry per site
        The field.

    Returns
    -------
    A scalar for one configuration, or an array of ``m`` energies.
    """
    spins = np.asarray(spins, dtype=float)
    single = spins.ndim == 1
    if single:
        spins = spins[None, :]
    couplings = _edge_couplings(J, edges)
    energy = np.zeros(spins.shape[0])
    for coupling, (i, j) in zip(couplings, edges):
        energy -= coupling * spins[:, i] * spins[:, j]
    energy -= spins @ np.broadcast_to(np.asarray(h, dtype=float), (spins.shape[1],))
    return float(energy[0]) if single else energy


def ising_from_pairwise(tables, edges, n):
    """Rewrite a pairwise model with positive tables in Ising form.

    Lecture Slides 3, Lemma 24: a positive table ``f(x_i, x_j)`` with rows
    indexed by ``x_i`` and columns by ``x_j`` satisfies

        ln f(x_i, x_j) = c + J s_i s_j + a s_i + b s_j,

    with ``s = 2x - 1``, ``J = (l00 + l11 - l01 - l10) / 4``, ``a = (l10 +
    l11 - l00 - l01) / 4``, ``b = (l01 + l11 - l00 - l10) / 4`` and ``c =
    (l00 + l01 + l10 + l11) / 4`` where ``l_ab = ln f(a, b)``. Summing over
    the edges gives ``ln g(x) = constant + sum J_ij s_i s_j + sum h_i s_i``,
    so the energy ``E(x) = -ln g(x)`` is an Ising energy up to the constant.

    Parameters
    ----------
    tables : list of ``2 x 2`` tables, one per edge, rows ``x_i``, columns ``x_j``
    edges : list of pairs ``(i, j)``, in the same order as ``tables``
    n : the number of sites

    Returns
    -------
    couplings : dict mapping each edge ``(i, j)`` to ``J_ij``
    fields : array of ``n`` fields ``h_i``
    constant : the constant ``c``, summed over the edges

    The order of the two indices matters: transposing a table exchanges
    ``a`` and ``b`` and therefore the fields of the two sites.
    """
    couplings = {}
    fields = np.zeros(n)
    constant = 0.0
    for table, (i, j) in zip(tables, edges):
        table = np.asarray(table, dtype=float)
        if table.shape != (2, 2) or (table <= 0).any():
            raise ValueError("each table must be 2 x 2 with positive entries")
        l = np.log(table)
        couplings[(i, j)] = 0.25 * (l[0, 0] + l[1, 1] - l[0, 1] - l[1, 0])
        fields[i] += 0.25 * (l[1, 0] + l[1, 1] - l[0, 0] - l[0, 1])
        fields[j] += 0.25 * (l[0, 1] + l[1, 1] - l[0, 0] - l[1, 0])
        constant += 0.25 * l.sum()
    return couplings, fields, constant


def hebbian_couplings(patterns):
    """Return the Hebbian coupling matrix ``(1/n) Xi^T Xi`` with zero diagonal.

    ``patterns`` is an array of shape ``(P, n)`` whose rows are the stored
    configurations of ``+1`` and ``-1``. A Hopfield network with these
    couplings and no field is an Ising model whose energy is lowest at the
    stored patterns and at their negatives (exploration E4).
    """
    patterns = np.asarray(patterns, dtype=float)
    n = patterns.shape[1]
    W = patterns.T @ patterns / n
    np.fill_diagonal(W, 0.0)
    return W


# ==========================================================================
# Section 3. Partition function, Boltzmann distribution, information
# ==========================================================================


def log_partition_function(energies, temperature):
    """Return ``ln Z_T`` by the log-sum-exp identity.

    ``ln sum exp(-E/T) = m + ln sum exp(-E/T - m)`` with ``m`` the largest
    value of ``-E/T``. Every exponent is then at most zero, so nothing
    overflows, and the result is exact even after an energy shift of
    ``10**6`` (Definition 3 of the laboratory).
    """
    a = -np.asarray(energies, dtype=float) / temperature
    m = a.max()
    return float(m + np.log(np.exp(a - m).sum()))


def naive_partition_function(energies, temperature):
    """Return ``sum exp(-E/T)`` by direct exponentiation, for Task 3.

    At low temperature the exponentials overflow to ``inf`` and the
    probabilities become ``nan``. The function silences the overflow
    warning so that the student sees the numbers, not a warning.
    """
    with np.errstate(over="ignore", invalid="ignore"):
        return float(np.exp(-np.asarray(energies, dtype=float) / temperature).sum())


def boltzmann_distribution(energies, temperature):
    """Return the Boltzmann distribution ``p_T(s) = exp(-E(s)/T) / Z_T``."""
    a = -np.asarray(energies, dtype=float) / temperature
    return np.exp(a - log_partition_function(energies, temperature))


def entropy(p):
    """Return the entropy ``H(p) = -sum p ln p`` in nats; ``0 ln 0 = 0``."""
    p = np.asarray(p, dtype=float)
    q = p[p > 0]
    return float(-(q * np.log(q)).sum())


def cross_entropy(p, q):
    """Return ``H(p, q) = -sum p ln q`` in nats, ``inf`` where ``q = 0 < p``."""
    p = np.asarray(p, dtype=float)
    q = np.asarray(q, dtype=float)
    support = p > 0
    if (q[support] <= 0).any():
        return math.inf
    return float(-(p[support] * np.log(q[support])).sum())


def kl_divergence(p, q):
    """Return ``D(p || q) = sum p ln (p / q)`` in nats, ``inf`` on a support violation."""
    p = np.asarray(p, dtype=float)
    q = np.asarray(q, dtype=float)
    support = p > 0
    if (q[support] <= 0).any():
        return math.inf
    return float((p[support] * np.log(p[support] / q[support])).sum())


def pair_marginal(p, configs, i, j):
    """Return the ``2 x 2`` marginal of the spins at sites ``i`` and ``j``.

    Entry ``[a, b]`` is the probability that ``x_i = a`` and ``x_j = b``,
    with ``x = (s + 1) / 2``; index 0 is the spin ``-1`` and index 1 the
    spin ``+1``.
    """
    p = np.asarray(p, dtype=float)
    xi = (configs[:, i] + 1) // 2
    xj = (configs[:, j] + 1) // 2
    table = np.zeros((2, 2))
    for a in (0, 1):
        for b in (0, 1):
            table[a, b] = p[(xi == a) & (xj == b)].sum()
    return table


def mutual_information(p, configs, i, j):
    """Return ``I(s_i; s_j)`` in nats from the pair marginal.

    ``I = sum over a, b of p(a, b) ln ( p(a, b) / (p(a) p(b)) )``, which is
    ``H(s_i) + H(s_j) - H(s_i, s_j)`` (Lecture Slides 3, Definition 14).
    """
    table = pair_marginal(p, configs, i, j)
    row = table.sum(axis=1)
    col = table.sum(axis=0)
    total = 0.0
    for a in (0, 1):
        for b in (0, 1):
            if table[a, b] > 0:
                total += table[a, b] * math.log(table[a, b] / (row[a] * col[b]))
    return float(total)


def magnetization_distribution(p, configs):
    """Return the values of ``M = sum s_i`` and their probabilities.

    The values run from ``-n`` to ``n`` in steps of two; the probabilities
    are ``P(M = value)`` under ``p``. Under ``h = 0`` the distribution is
    symmetric and, at low temperature, bimodal (Example 4 of the laboratory).
    """
    p = np.asarray(p, dtype=float)
    M = configs.sum(axis=1)
    n = configs.shape[1]
    values = np.arange(-n, n + 1, 2)
    probabilities = np.array([p[M == m].sum() for m in values])
    return values, probabilities


def mean_energy(p, energies):
    """Return the average energy ``U = sum p E``."""
    return float((np.asarray(p, dtype=float) * np.asarray(energies, dtype=float)).sum())


def heat_capacity(p, energies, temperature):
    """Return the heat capacity ``C = Var_p(E) / T**2`` (Definition 5).

    Lecture Slides 3, Theorem 21, gives ``dU/dT = Var(E) / T**2``, and the
    same variance gives ``dH/dT = Var(E) / T**3``.
    """
    p = np.asarray(p, dtype=float)
    energies = np.asarray(energies, dtype=float)
    U = mean_energy(p, energies)
    return float((p * (energies - U) ** 2).sum() / temperature ** 2)


def spin_correlation(p, configs, i, j):
    """Return the spin correlation ``E_p[s_i s_j]`` (Definition 4).

    With no field the mean of every spin is zero, so this expectation is
    also the covariance of the two spins.
    """
    p = np.asarray(p, dtype=float)
    return float((p * configs[:, i] * configs[:, j]).sum())


def ground_state_probability(p, energies):
    """Return the total probability of the configurations of lowest energy."""
    energies = np.asarray(energies, dtype=float)
    return float(np.asarray(p, dtype=float)[energies == energies.min()].sum())


def temperature_sweep(energies, configs, temperatures, pairs=((5, 6), (0, 15))):
    """Return the quantities of the temperature table, one array per column.

    The dictionary holds ``temperature``, ``log_partition_function``,
    ``entropy``, ``ground_state_probability``, ``energy_per_site``,
    ``heat_capacity_per_site``, and for every pair ``(i, j)`` in ``pairs``
    the arrays ``correlation[(i, j)]`` and ``mutual_information[(i, j)]``.
    """
    energies = np.asarray(energies, dtype=float)
    n = configs.shape[1]
    out = {"temperature": np.asarray(temperatures, dtype=float),
           "log_partition_function": [], "entropy": [],
           "ground_state_probability": [], "energy_per_site": [],
           "heat_capacity_per_site": [],
           "correlation": {pair: [] for pair in pairs},
           "mutual_information": {pair: [] for pair in pairs}}
    for T in out["temperature"]:
        p = boltzmann_distribution(energies, T)
        out["log_partition_function"].append(log_partition_function(energies, T))
        out["entropy"].append(entropy(p))
        out["ground_state_probability"].append(ground_state_probability(p, energies))
        out["energy_per_site"].append(mean_energy(p, energies) / n)
        out["heat_capacity_per_site"].append(heat_capacity(p, energies, T) / n)
        for pair in pairs:
            out["correlation"][pair].append(spin_correlation(p, configs, *pair))
            out["mutual_information"][pair].append(mutual_information(p, configs, *pair))
    for key in ("log_partition_function", "entropy", "ground_state_probability",
                "energy_per_site", "heat_capacity_per_site"):
        out[key] = np.array(out[key])
    for pair in pairs:
        out["correlation"][pair] = np.array(out["correlation"][pair])
        out["mutual_information"][pair] = np.array(out["mutual_information"][pair])
    return out


def chain_correlation(J, temperature, distance):
    """Return ``tanh(J/T) ** distance``, the correlation on a chain with no field.

    On a chain of spins with constant coupling and free boundary the
    correlation of two spins ``d`` edges apart is ``tanh(J/T)**d`` (Claim 3
    of the laboratory; Homework 3, Problem 7 style).
    """
    return math.tanh(J / temperature) ** distance


# ==========================================================================
# Section 4. Closing the box column by column
# ==========================================================================


def transfer_matrix_log_partition(L, temperature, J=1.0, h=0.0):
    """Return ``ln Z_T`` of the ``L x L`` grid by closing one column at a time.

    Each column of ``L`` spins is one variable with ``2**L`` values (Claim 1
    of the laboratory). The weight of a column is ``exp((J * sum of its
    vertical products + h * sum of its spins) / T)``, and the weight between
    two adjacent columns is ``exp(J * sum of the horizontal products / T)``.
    Summing out the columns from left to right is the sum-product algorithm
    on a chain of ``L`` variables (Lecture Slides 3, Lemma 3), and it costs
    ``(L - 1) * 4**L`` products. Everything is kept in the log domain with
    the log-sum-exp identity, so no exponential overflows.
    """
    column = all_configurations(L).astype(float)
    within = np.zeros(1 << L)
    for i in range(L - 1):
        within += J * column[:, i] * column[:, i + 1]
    within += h * column.sum(axis=1)
    between = J * (column @ column.T)
    log_message = within / temperature
    for _ in range(L - 1):
        exponent = log_message[:, None] + (between + within[None, :]) / temperature
        m = exponent.max(axis=0)
        log_message = m + np.log(np.exp(exponent - m[None, :]).sum(axis=0))
    m = log_message.max()
    return float(m + math.log(np.exp(log_message - m).sum()))


def _peak_cache_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "peak_table.json")


def heat_capacity_peak(L, temperatures, step=1e-3, cache=True):
    """Return ``(T_peak, C/n at the peak)`` of the ``L x L`` grid.

    The heat capacity per site is ``Var(E) / (T**2 * L**2)``, and the
    variance is the second derivative of ``ln Z`` with respect to ``beta =
    1/T`` (Lecture Slides 3, Proposition 26). The derivative is taken as a
    central second difference of ``transfer_matrix_log_partition`` with the
    step ``step`` in ``beta``, and the peak is the largest value on the grid
    ``temperatures``. Results are cached in ``peak_table.json`` next to this
    file, keyed by ``L`` and by the temperature grid.
    """
    temperatures = np.asarray(temperatures, dtype=float)
    signature = f"{temperatures[0]:.6f}:{temperatures[-1]:.6f}:{len(temperatures)}:{step:g}"
    key = f"L={L}"
    path = _peak_cache_path()
    table = {}
    if cache and os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            table = json.load(f)
        entry = table.get(key)
        if entry and entry.get("grid") == signature:
            return entry["T_peak"], entry["C_per_site"]
    best_T, best_C = None, -math.inf
    for T in temperatures:
        beta = 1.0 / T
        f0 = transfer_matrix_log_partition(L, 1.0 / beta)
        fp = transfer_matrix_log_partition(L, 1.0 / (beta + step))
        fm = transfer_matrix_log_partition(L, 1.0 / (beta - step))
        variance = (fp - 2 * f0 + fm) / step ** 2
        C = variance * beta ** 2 / (L * L)
        if C > best_C:
            best_T, best_C = float(T), float(C)
    if cache:
        table[key] = {"T_peak": best_T, "C_per_site": best_C, "grid": signature,
                      "products": (L - 1) * 4 ** L}
        with open(path, "w", encoding="utf-8") as f:
            json.dump(table, f, indent=1, sort_keys=True)
    return best_T, best_C


# ==========================================================================
# Section 5. Printing every number of the slides
# ==========================================================================


def four(x):
    """Format a float with four decimals, rounding half-up from the unrounded value."""
    return str(Decimal(repr(float(x))).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP))


RESEARCH_GRID = np.round(np.arange(80, 361)) / 100.0      # 0.80 .. 3.60 step 0.01
PEAK_GRID = np.linspace(1.0, 4.0, 601)                     # the 4 x 4 peak search


def grid_model(L=4, J=1.0, h=0.0):
    """Return ``(edges, configs, energies)`` of the ``L x L`` grid."""
    edges = grid_edges(L, L)
    configs = all_configurations(L * L)
    return edges, configs, ising_energy(configs, edges, J, h)


def lecture_chain():
    """Print the numbers of Lecture Slides 3 on the running chain.

    The chain has three variables, the tables ``f12 = [[4, 1], [8, 5]]`` and
    ``f23 = [[3, 1], [1, 4]]``, ``Z = 78``, and the energy ``E(x) = -ln
    g(x)``. Everything is computed with the functions of this module.
    """
    f12 = np.array([[4.0, 1.0], [8.0, 5.0]])
    f23 = np.array([[3.0, 1.0], [1.0, 4.0]])
    edges = [(0, 1), (1, 2)]
    configs = all_configurations(3)
    x = (configs + 1) // 2
    g = f12[x[:, 0], x[:, 1]] * f23[x[:, 1], x[:, 2]]
    energies = -np.log(g)
    print("Lecture Slides 3: the running chain")
    print("  weights in the order x = (x1, x2, x3):",
          [int(g[k]) for k in sorted(range(8), key=lambda k: tuple(x[k]))], " Z =", int(g.sum()))
    p = boltzmann_distribution(energies, 1.0)
    print("  ln Z =", four(log_partition_function(energies, 1.0)),
          " H(p) =", four(entropy(p)), " E_p[E] =", four(mean_energy(p, energies)),
          " Var_p(E) =", four(heat_capacity(p, energies, 1.0)))
    marginal = lambda i: np.array([p[x[:, i] == 0].sum(), p[x[:, i] == 1].sum()])
    for i in range(3):
        print(f"  H(X{i + 1}) = {four(entropy(marginal(i)))}", end="")
    print()
    print("  I(X1;X2) =", four(mutual_information(p, configs, 0, 1)),
          " I(X2;X3) =", four(mutual_information(p, configs, 1, 2)),
          " I(X1;X3) =", four(mutual_information(p, configs, 0, 2)))
    uniform = np.full(8, 1 / 8)
    print("  D(p || u) =", four(kl_divergence(p, uniform)),
          " D(u || p) =", four(kl_divergence(uniform, p)),
          " H(u, p) =", four(cross_entropy(uniform, p)),
          " D(p_X2 || u) =", four(kl_divergence(marginal(1), [0.5, 0.5])))
    print("  temperature table (T, ln Z_T, T ln Z_T, H, U, p_T(1,0,0)):")
    k100 = int(np.flatnonzero((x == [1, 0, 0]).all(axis=1))[0])
    for T in (0.25, 0.5, 1, 2, 4, 100):
        pT = boltzmann_distribution(energies, T)
        lnZ = log_partition_function(energies, T)
        print(f"    T = {T:<5} {four(lnZ):>8} {four(T * lnZ):>9} {four(entropy(pT)):>7}"
              f" {four(mean_energy(pT, energies)):>8} {four(pT[k100]):>7}")
    couplings, fields, constant = ising_from_pairwise([f12, f23], edges, 3)
    print("  Ising form: J12 =", four(couplings[(0, 1)]), " J23 =", four(couplings[(1, 2)]),
          " h = (" + ", ".join(four(v) for v in fields) + ")", " c =", four(constant))
    spins = configs.astype(float)
    ising = ising_energy(configs, edges, [couplings[e] for e in edges], fields)
    residual = float(np.abs(np.log(g) - (constant - ising)).max())
    print("  maximum residual of the rewrite:", f"{residual:.1e}",
          " Z_Ising = 78 exp(-c) =", four(78 * math.exp(-constant)),
          "=", four(math.exp(log_partition_function(ising, 1.0))))
    print("  E[s] = (" + ", ".join(four(v) for v in p @ spins) + ")",
          " E[s1 s2] =", four(spin_correlation(p, configs, 0, 1)),
          " E[s2 s3] =", four(spin_correlation(p, configs, 1, 2)),
          " E[s1 s3] =", four(spin_correlation(p, configs, 0, 2)))
    J23 = couplings[(1, 2)]
    print("  chain with constant J23 and no field: tanh J =", four(math.tanh(J23)),
          " 2 cosh J =", four(2 * math.cosh(J23)),
          " correlation at distance 1, 2, 4, 9 =",
          ", ".join(four(chain_correlation(J23, 1.0, d)) for d in (1, 2, 4, 9)))


def main():
    """Print every number that appears on Laboratory Slides 3."""
    edges, configs, energies = grid_model()
    n = configs.shape[1]
    print("Laboratory Slides 3: the 4 x 4 Ising grid, free boundary, J = 1, h = 0")
    print("  sites:", n, " edges:", len(edges), " configurations:", configs.shape[0])
    levels, counts = np.unique(energies, return_counts=True)
    print(f"  ground energy {levels[0]:g} with {counts[0]} configurations;"
          f" first excited level {levels[1]:g} with {counts[1]};"
          f" maximum {levels[-1]:g} with {counts[-1]}")

    print("\nLog-sum-exp at T = 0.01 (Definition 3, Example 2)")
    naive = naive_partition_function(energies, 0.01)
    with np.errstate(over="ignore", invalid="ignore"):
        probabilities = np.exp(-energies / 0.01) / naive
    print("  naive sum exp(-E/T) =", naive, " probabilities nan:", bool(np.isnan(probabilities).any()))
    print("  stable ln Z =", four(log_partition_function(energies, 0.01)),
          " = 2400 + ln 2 =", four(2400 + math.log(2)))

    print("\nClosing the box column by column (Claim 1)")
    print("  transfer ln Z at T = 2:", f"{transfer_matrix_log_partition(4, 2.0):.6f}",
          " enumeration:", f"{log_partition_function(energies, 2.0):.6f}",
          " products: 3 * 16^2 =", 3 * 16 ** 2)

    print("\nTemperature sweep (Examples 3 and 5)")
    temperatures = (0.5, 1, 1.5, 2, 2.5, 3, 5, 100)
    sweep = temperature_sweep(energies, configs, temperatures)
    print(f"  {'T':>5} {'ln Z':>8} {'H':>8} {'P(gnd)':>7} {'E/16':>8} {'C/16':>7}"
          f" {'E[s5s6]':>8} {'E[s0s15]':>9} {'I(5;6)':>7} {'I(0;15)':>8} {'tanh^6':>7}")
    for k, T in enumerate(temperatures):
        print(f"  {T:>5} {four(sweep['log_partition_function'][k]):>8}"
              f" {four(sweep['entropy'][k]):>8}"
              f" {four(sweep['ground_state_probability'][k]):>7}"
              f" {four(sweep['energy_per_site'][k]):>8}"
              f" {four(sweep['heat_capacity_per_site'][k]):>7}"
              f" {four(sweep['correlation'][(5, 6)][k]):>8}"
              f" {four(sweep['correlation'][(0, 15)][k]):>9}"
              f" {four(sweep['mutual_information'][(5, 6)][k]):>7}"
              f" {four(sweep['mutual_information'][(0, 15)][k]):>8}"
              f" {four(chain_correlation(1.0, T, 6)):>7}")
    print("  limits: ln 2 =", four(math.log(2)), " 16 ln 2 =", four(16 * math.log(2)),
          " P(ground) as T -> infinity: 2/65536 =", f"{2 / 65536:.2e}")
    for T in (0.25, 1.0):
        p = boltzmann_distribution(energies, T)
        print(f"  T = {T}: H = {four(entropy(p))},"
              f" P(ground) = {four(ground_state_probability(p, energies))},"
              f" each ground state {four(ground_state_probability(p, energies) / 2)}")

    print("\nMagnetisation M = sum s_i (Example 4)")
    M = configs.sum(axis=1)
    for T in (1.5, 2, 3, 5):
        p = boltzmann_distribution(energies, T)
        values, probabilities = magnetization_distribution(p, configs)
        print(f"  T = {T}: P(|M| = 16) = {four(probabilities[np.abs(values) == 16].sum())},"
              f" P(M = 0) = {four(probabilities[values == 0].sum())},"
              f" E[s0] = {four((p * configs[:, 0]).sum())},"
              f" E|m| = {four((p * np.abs(M) / n).sum())}")

    print("\nExplorations at T = 2")
    energies_h = ising_energy(configs, edges, 1.0, 0.1)
    p = boltzmann_distribution(energies_h, 2.0)
    print("  E1, h = 0.1: E[s5] =", four((p * configs[:, 5]).sum()),
          " E|m| =", four((p * np.abs(M) / n).sum()),
          " E[s0 s15] =", four(spin_correlation(p, configs, 0, 15)),
          " I(s0;s15) =", four(mutual_information(p, configs, 0, 15)))
    energies_af = ising_energy(configs, edges, -1.0, 0.0)
    p = boltzmann_distribution(energies_af, 2.0)
    print("  E2, J = -1: ln Z =", four(log_partition_function(energies_af, 2.0)),
          " E[s5 s6] =", four(spin_correlation(p, configs, 5, 6)),
          " E[s0 s15] =", four(spin_correlation(p, configs, 0, 15)))
    chain = chain_edges(16)
    energies_chain = ising_energy(configs, chain, 1.0, 0.0)
    for T in (1, 2, 3):
        p = boltzmann_distribution(energies_chain, T)
        print(f"  E3, chain of 16 at T = {T}: E[s0 s6] = {four(spin_correlation(p, configs, 0, 6))}"
              f"  tanh(1/T)^6 = {four(chain_correlation(1.0, T, 6))}")

    print("\nHeat capacity (Definition 5)")
    p = boltzmann_distribution(energies, 2.0)
    step = 1e-4
    dH = (entropy(boltzmann_distribution(energies, 2.0 + step))
          - entropy(boltzmann_distribution(energies, 2.0 - step))) / (2 * step)
    print("  Var(E)/T^3 at T = 2:", four(heat_capacity(p, energies, 2.0) / 2.0),
          " dH/dT by central difference (step 1e-4):", four(dH))
    values = [heat_capacity(boltzmann_distribution(energies, T), energies, T) / n for T in PEAK_GRID]
    k = int(np.argmax(values))
    print(f"  peak of C/16 on np.linspace(1, 4, 601): T = {PEAK_GRID[k]:.3f}, value {four(values[k])}")

    print("\nResearch track: heat-capacity peak against L (column closing, beta step 1e-3,"
          " T = 0.80..3.60 step 0.01)")
    for L in range(2, 9):
        T_peak, C = heat_capacity_peak(L, RESEARCH_GRID)
        print(f"  L = {L}: T_peak = {T_peak:.2f}  C/n = {four(C)}  products (L-1) 4^L = {(L - 1) * 4 ** L}")
    print("  Onsager's critical temperature 2 / ln(1 + sqrt 2) =", four(2 / math.log(1 + math.sqrt(2))))
    print()
    lecture_chain()


def check():
    """Compare independent computations and exit non-zero on a mismatch."""
    failures = []

    def compare(label, got, want, tol=1e-9):
        ok = abs(got - want) <= tol
        print(f"  [{'ok' if ok else 'FAIL'}] {label}: {got!r} against {want!r}")
        if not ok:
            failures.append(label)

    edges, configs, energies = grid_model()
    for T in (0.5, 1.0, 2.0, 5.0):
        compare(f"column closing equals enumeration at T = {T}",
                transfer_matrix_log_partition(4, T), log_partition_function(energies, T), 1e-9)
    for L in (2, 3):
        e, c, en = grid_model(L)
        compare(f"column closing equals enumeration on the {L} x {L} grid at T = 1.5",
                transfer_matrix_log_partition(L, 1.5), log_partition_function(en, 1.5), 1e-9)
    compare("column closing equals enumeration with h = 0.1 at T = 2",
            transfer_matrix_log_partition(4, 2.0, 1.0, 0.1),
            log_partition_function(ising_energy(configs, edges, 1.0, 0.1), 2.0), 1e-9)
    for T in (1.0, 2.0, 3.0):
        p = boltzmann_distribution(energies, T)
        step = 1e-4
        dH = (entropy(boltzmann_distribution(energies, T + step))
              - entropy(boltzmann_distribution(energies, T - step))) / (2 * step)
        compare(f"Var(E)/T^3 equals dH/dT by central difference at T = {T}",
                heat_capacity(p, energies, T) / T, dH, 1e-5)
    for T in (1.0, 2.0, 5.0):
        naive = naive_partition_function(energies, T)
        compare(f"log-sum-exp equals ln of the direct sum at T = {T}",
                log_partition_function(energies, T), math.log(naive), 1e-9)
    compare("the direct sum overflows at T = 0.01 while log-sum-exp gives 2400 + ln 2",
            log_partition_function(energies, 0.01), 2400 + math.log(2), 1e-9)
    print("  naive sum at T = 0.01:", naive_partition_function(energies, 0.01))
    compare("log-sum-exp is invariant under an energy shift of 1e6",
            log_partition_function(energies + 1e6, 2.0) + 1e6 / 2.0,
            log_partition_function(energies, 2.0), 1e-6)
    chain = chain_edges(16)
    en = ising_energy(configs, chain, 1.0, 0.0)
    for T in (1.0, 2.0, 3.0):
        p = boltzmann_distribution(en, T)
        compare(f"chain of 16: E[s0 s6] equals tanh(1/T)^6 at T = {T}",
                spin_correlation(p, configs, 0, 6), chain_correlation(1.0, T, 6), 1e-9)
    f12 = [[4, 1], [8, 5]]
    f23 = [[3, 1], [1, 4]]
    couplings, fields, constant = ising_from_pairwise([f12, f23], [(0, 1), (1, 2)], 3)
    c3 = all_configurations(3)
    x = (c3 + 1) // 2
    g = np.array(f12, float)[x[:, 0], x[:, 1]] * np.array(f23, float)[x[:, 1], x[:, 2]]
    ising = ising_energy(c3, [(0, 1), (1, 2)], [couplings[(0, 1)], couplings[(1, 2)]], fields)
    compare("Ising rewrite of the chain: maximum residual",
            float(np.abs(np.log(g) - (constant - ising)).max()), 0.0, 1e-12)
    compare("Z_Ising = 78 exp(-c)", math.exp(log_partition_function(ising, 1.0)),
            78 * math.exp(-constant), 1e-9)
    if failures:
        print(f"{len(failures)} MISMATCHES")
        for f in failures:
            print("  ", f)
        sys.exit(1)
    print("all checks passed")


if __name__ == "__main__":
    if "--check" in sys.argv[1:]:
        check()
    else:
        main()
