import unittest,tempfile,subprocess,sys,json,contextlib,io
from pathlib import Path
import numpy as np
import xml.etree.ElementTree as ET
from lab10 import encode,decode,mse,svg,run
class Adversarial(unittest.TestCase):
 def test_invalid(self):
  for x in [[],np.zeros((0,4)),np.zeros((2,0)),np.zeros((3,4)),[1,2],np.zeros((2,2,1)),np.full((2,2),np.nan),np.full((2,2),np.inf),np.ones((2,2))*1j]:
   with self.subTest(shape=np.shape(x)):
    with self.assertRaises(ValueError):encode(x)
 def test_decode_invalid(self):
  for x in [[],1,np.full((2,2),np.nan)]:
   with self.assertRaises(ValueError):decode(x)
  with self.assertRaises(ValueError):decode(np.zeros((2,2)),np.zeros((1,2)))
 def test_mse_shapes(self):
  with self.assertRaises(ValueError):mse(np.zeros((2,2)),np.zeros((1,2)))
 def test_rectangular(self):
  rng=np.random.default_rng(42)
  for shape in [(1,1),(2,3),(5,2)]:
   m=rng.random(shape);c=rng.random(shape);mm,cc=encode(decode(m,c));np.testing.assert_allclose(mm,m,atol=1e-12);np.testing.assert_allclose(cc,c,atol=1e-12)
 def test_arbitrary_not_exact(self):
  x=np.array([[1.,0],[0,0]]);m,c=encode(x);self.assertGreater(mse(x,decode(m,c)),0)
 def test_constant(self):
  x=np.full((4,6),.4);m,c=encode(x);np.testing.assert_allclose(c,0);np.testing.assert_allclose(decode(m),x)
 def test_views_and_no_mutation(self):
  x=np.arange(64.).reshape(8,8).T;y=x.copy();encode(x);np.testing.assert_array_equal(x,y)
 def test_unknown(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'missing'
   with self.assertRaises(ValueError):run('bad',p)
   self.assertFalse(p.exists())
 def test_svg(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'目录 with spaces'/'x.svg';svg([np.ones((14,20))],['A < B & C'],p);r=ET.parse(p).getroot();self.assertGreaterEqual(int(r.attrib['height']),409)
 def test_cli(self):
  with tempfile.TemporaryDirectory() as td:
   for name in ['compress','attention','noise']:
    r=subprocess.run([sys.executable,'lab10.py',name,'--out',str(Path(td)/'结果')],capture_output=True,text=True);self.assertEqual(r.returncode,0,r.stderr)
   p=Path(td)/'结果/latent_noise.svg';old=p.read_bytes();subprocess.run([sys.executable,'lab10.py','noise','--out',str(p.parent)],check=True,capture_output=True);self.assertEqual(old,p.read_bytes())
 def test_notebook(self):
  n=json.loads(Path('lab10.ipynb').read_text(encoding='utf-8'));scope={}
  with contextlib.redirect_stdout(io.StringIO()):
   for c in n['cells']:
    if c['cell_type']=='code':exec(''.join(c['source']),scope)
