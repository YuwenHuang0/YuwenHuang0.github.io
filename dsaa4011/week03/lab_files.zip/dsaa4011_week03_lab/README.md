# Week 3 laboratory: a small Ising model

This directory contains the material of *Laboratory Slides 3*. In the
laboratory session the instructor presents the main ideas and you read the
slides. The notebook `lab.ipynb` and the program `ising.py` are for
exploration after the session, at your own pace; the notebook follows the
slides task by task.

## The question of the laboratory

The lecture defined the Boltzmann distribution $p_T(x) = e^{-E(x)/T} / Z_T$
and showed on a chain of three variables how the temperature moves the
distribution between the uniform distribution and the ground states. This
laboratory runs the same definitions on a model with cycles: a $4 \times 4$
grid of sixteen spins, the Ising model. Its graph has cycles, so we
enumerate all 65 536 configurations and every number is exact. The
questions are how the entropy, the probability of the ground states, the
magnetisation and the correlation of two spins change with the temperature;
why the mean of a spin hides the two modes of the distribution; why the
correlation of two spins on the grid is not what a chain predicts; and, on
the research track, how the temperature of the heat-capacity peak moves
with the size of the lattice.

## The files

| file | contents |
|---|---|
| `lab.ipynb` | the notebook: Tasks 1 to 9, the research track, references |
| `ising.py` | the model, the log-sum-exp partition function, entropy, mutual information, correlation, magnetisation, the column-by-column closing and the heat-capacity peak; `python ising.py` prints every number quoted on the slides, and `python ising.py --check` compares the column closing with enumeration, the variance of the energy with a finite difference of the entropy, and the log-sum-exp with the direct sum wherever the direct sum is finite |
| `starter.py`, `test_public.py` | the five functions that you write (`log_partition_function`, `entropy`, `magnetization_distribution`, `spin_correlation`, `mutual_information`) and their public tests |
| `evidence_card.md` | the record of your predictions and results: one claim, one test, one limit |
| `peak_table.json` | the cache of the research track (Task 8); delete it to recompute |
| `requirements.txt` | `numpy`, `pytest`, `matplotlib` |

## The nine tasks

The table is the same as on the slides and in the notebook.

| task | what you do | expected output |
|---|---|---|
| 1 | run the first cell: the chain of the lecture in Ising form | $J_{12} = 0.2291$, $J_{23} = 0.6212$, $h = (0.5756, -0.3922, 0.0719)$, $c = 1.8900$, residual below $10^{-12}$, $Z_{\text{Ising}} = 11.7834$ |
| 2 | enumerate the grid | 65 536 configurations; lowest energy $-24$ (2 configurations), next level $-20$ (8), highest $24$ (2) |
| 3 | predict, then run the direct sum and the log-sum-exp at $T = 0.01$; write `log_partition_function` | `inf`, `nan: True`; `2400.6931` |
| 4 | write the entropy prediction, then run `temperature_sweep`; write `entropy` | the table of the slides; $H(0.25) = 0.6932$ |
| 5 | write `magnetization_distribution` | $P(\lvert M\rvert = 16) = 0.4776, 0.1645, 0.0220, 0.0023$ and $P(M = 0) = 0.0112, 0.0377, 0.0871, 0.1320$ at $T = 1.5, 2, 3, 5$; `E[s_0] = 0.0000` |
| 6 | write `spin_correlation` and `mutual_information` | neighbours / corners $0.9940$ / $0.8994$ at $T = 1$, $0.6776$ / $0.1985$ at $T = 2$, $0.3967$ / $0.0248$ at $T = 3$; chain of 16 at distance 6: $0.0097$ at $T = 2$ |
| 7 | one exploration, E1 to E4 | E1: $E[s_5] = 0.4078$; E2: $\ln Z = 14.4977$, $-0.6776$, $+0.1985$; E3: equals $\tanh(1/T)^6$; E4: four modes |
| 8 | research track, optional: the heat-capacity peak against $L$ | `transfer = enumeration = 14.497711`; the table of $(L, T_{\text{peak}}, C/n)$ |
| 9 | fill in `evidence_card.md` | one claim, one test, one limit |

## Names on the slides and in the code

| on the slides | in the code |
|---|---|
| the grid, its edges, a chain | `grid_edges(rows, cols)`, `chain_edges(n)` |
| all $2^n$ configurations, site 0 in the least significant bit | `all_configurations(n)` |
| the energy $E(s) = -J \sum s_i s_j - h \sum s_i$ | `ising_energy(spins, edges, J=1.0, h=0.0)` |
| the Ising form of a pairwise model (Lecture Slides 3, Lemma 24) | `ising_from_pairwise(tables, edges, n)` |
| Hebbian couplings (exploration E4) | `hebbian_couplings(patterns)` |
| $\ln Z_T$ by log-sum-exp; the direct sum | `log_partition_function(energies, temperature)`, `naive_partition_function(...)` |
| the Boltzmann distribution $p_T$ | `boltzmann_distribution(energies, temperature)` |
| entropy, cross-entropy, KL divergence (nats) | `entropy(p)`, `cross_entropy(p, q)`, `kl_divergence(p, q)` |
| the pair marginal and the mutual information of two spins | `pair_marginal(p, configs, i, j)`, `mutual_information(p, configs, i, j)` |
| the distribution of the magnetisation $M$ | `magnetization_distribution(p, configs)` |
| the average energy $U$ and the heat capacity $C = \mathrm{Var}(E)/T^2$ | `mean_energy(p, energies)`, `heat_capacity(p, energies, temperature)` |
| the spin correlation $E[s_i s_j]$; the probability of the ground states | `spin_correlation(p, configs, i, j)`, `ground_state_probability(p, energies)` |
| the temperature table | `temperature_sweep(energies, configs, temperatures, pairs=((5, 6), (0, 15)))` |
| the chain prediction $\tanh(J/T)^d$ | `chain_correlation(J, temperature, distance)` |
| closing the box column by column | `transfer_matrix_log_partition(L, temperature, J=1.0, h=0.0)` |
| the heat-capacity peak of the $L \times L$ grid | `heat_capacity_peak(L, temperatures)` |
| the running chain of the lecture | `lecture_chain()` |

## The research track (Task 8)

Closing the box column by column costs $(L - 1) \cdot 4^L$ products instead
of $2^{L^2}$ terms: 768 against 65 536 at $L = 4$, and 458 752 against
$2^{64}$ at $L = 8$. With it the heat capacity per site can be computed
exactly for $L = 2, \dots, 8$ by a second difference of $\ln Z$ in
$\beta = 1/T$. The peak moves from $T = 1.26$ at $L = 2$ to $1.93$ at
$L = 8$, slowly toward Onsager's critical temperature $2.2692$ of the
infinite lattice (Onsager 1944), and its height grows from $0.4148$ to
$0.8717$; boundary spins have fewer neighbours, which is why a finite grid
with free boundary orders at a lower temperature. Exact results for finite
lattices are in Ferdinand and Fisher (1969). What the peak does at
$L = 16$ or $L = 32$, where closing a column costs $4^{16}$ products and
more, is the open question that leads to sampling (Lecture Slides 4).

## Checks

```
python ising.py --check
python ising.py
python -m pytest -q test_public.py
```

## Using AI

You may use any assistant for the code. Do not paste chat transcripts;
nobody grades prompt style. What the evidence card examines is the
hypothesis and the prediction that you wrote before each run, the reference
that you compared against, the boundary case that you found, and your
explanation.

## What to save

`evidence_card.md` and the notebook. This laboratory is formative practice
and carries no separate mark.

## References

The numbers are those of the slides and of the notebook.

1. E. Ising, "Beitrag zur Theorie des Ferromagnetismus," *Zeitschrift für
   Physik*, vol. 31, pp. 253-258, 1925.
2. H. A. Kramers and G. H. Wannier, "Statistics of the two-dimensional
   ferromagnet. Part I," *Physical Review*, vol. 60, no. 3, pp. 252-262,
   1941.
3. L. Onsager, "Crystal statistics. I. A two-dimensional model with an
   order-disorder transition," *Physical Review*, vol. 65, nos. 3-4,
   pp. 117-149, 1944.
4. A. E. Ferdinand and M. E. Fisher, "Bounded and inhomogeneous Ising
   models. I. Specific-heat anomaly of a finite lattice," *Physical
   Review*, vol. 185, no. 2, pp. 832-846, 1969.
5. R. J. Glauber, "Time-dependent statistics of the Ising model," *Journal
   of Mathematical Physics*, vol. 4, no. 2, pp. 294-307, 1963.
6. D. H. Ackley, G. E. Hinton, and T. J. Sejnowski, "A learning algorithm
   for Boltzmann machines," *Cognitive Science*, vol. 9, no. 1,
   pp. 147-169, 1985.
7. F. R. Kschischang, B. J. Frey, and H.-A. Loeliger, "Factor graphs and
   the sum-product algorithm," *IEEE Transactions on Information Theory*,
   vol. 47, no. 2, pp. 498-519, 2001.
8. D. J. C. MacKay, *Information Theory, Inference, and Learning
   Algorithms*. Cambridge, UK: Cambridge University Press, 2003.
9. J. J. Hopfield, "Neural networks and physical systems with emergent
   collective computational abilities," *Proceedings of the National
   Academy of Sciences*, vol. 79, no. 8, pp. 2554-2558, 1982.
