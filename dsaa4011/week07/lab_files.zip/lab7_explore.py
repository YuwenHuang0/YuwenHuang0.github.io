"""DSAA 4011 Lab 7, explore after class: sharing data, not people.

A clinic releases fake patients drawn from a Chow-Liu tree of noisy counts (the idea of MST, simplified), so that others
can train models on its data without seeing any real patient. Each experiment asks you to PREDICT first, then complete
the line marked TODO, then run.

    python lab7_explore.py 1        # the clinic: noisy pair tables, the best tree, fake patients
    python lab7_explore.py 2        # the two-gene disease: a pattern that no pair can see
    python lab7_explore.py 3        # more columns: the full table against a tree

Needs numpy and matplotlib. Every run is seeded, so you and your neighbour get the same numbers. The figures appear
together when the experiment ends; with MPLBACKEND=Agg (no display) they are saved as PNG files instead.
"""
import sys
import itertools
import numpy as np
import matplotlib
import matplotlib.pyplot as plt


def show():
    """Show every figure at the end of an experiment, or save them when there is no display."""
    if matplotlib.get_backend().lower().startswith("agg"):
        for n in plt.get_fignums():
            name = "lab7_%s.png" % plt.figure(n).get_label()
            plt.figure(n).savefig(name, dpi=120, bbox_inches="tight")
            print("figure saved as", name)
    else:
        plt.show()


# ---------------------------------------------------------------------------------------------
# Tools shared by the experiments
# ---------------------------------------------------------------------------------------------
def draw_tree_data(n, rng, parent, agree):
    """n records of m yes/no columns (1 = yes): column 0 is yes with chance 1/2; column c agrees with column parent[c]
    with chance agree[c], else gives the other answer. These are Lecture 7's friends."""
    m = len(parent)
    x = np.zeros((n, m), dtype=int)
    x[:, 0] = rng.random(n) < 0.5
    for c in range(1, m):
        same = rng.random(n) < agree[c]
        x[:, c] = np.where(same, x[:, parent[c]], 1 - x[:, parent[c]])
    return x


def pair_table(x, i, j):
    """2 x 2 counts of (column i, column j), rows and columns ordered (yes, no)"""
    t = np.zeros((2, 2))
    for a in (1, 0):
        for b in (1, 0):
            t[1 - a, 1 - b] = np.sum((x[:, i] == a) & (x[:, j] == b))
    return t


def info(t):
    """mutual information (nats) of a 2 x 2 table of nonnegative numbers (Lecture 7: the counted information)"""
    n = t.sum()
    if n <= 0:
        return 0.0
    r, c = t.sum(1, keepdims=True), t.sum(0, keepdims=True)
    mask = t > 0
    return float(np.sum(t[mask] / n * np.log(t[mask] * n / (r @ c)[mask])))


def greedy_tree(w, pairs, m):
    """Lecture 7's greedy rule (Kruskal): strongest pair first, skip a pair that closes a loop, stop at m - 1 links"""
    comp = list(range(m))
    def find(a):
        while comp[a] != a:
            a = comp[a]
        return a
    edges = []
    for k in np.argsort(-np.asarray(w), kind="stable"):
        i, j = pairs[k]
        a, b = find(i), find(j)
        if a != b:
            comp[a] = b
            edges.append((i, j))
        if len(edges) == m - 1:
            break
    return sorted(edges)


def laplace(rng, scale, shape):
    return rng.laplace(0.0, scale, size=shape)


def release_tree(x, eps, rng):
    """the simplified MST: (1) every pair table with Laplace noise (half of eps), (2) the greedy tree on their information,
    (3) the tree's tables again with fresh noise (the other half), (4) fake records drawn along the tree"""
    n, m = x.shape
    pairs = list(itertools.combinations(range(m), 2))
    # TODO (experiment 1): the noise scale for step (1). Each record sits in one cell of each of the len(pairs) tables, and
    # this step may use eps / 2 of the privacy. (Answer: len(pairs) / (eps / 2).)
    b1 = None
    if b1 is None:
        sys.exit("Complete the TODO in release_tree first: the noise scale b1 (experiment 1).")
    noisy = [np.maximum(0, pair_table(x, i, j) + laplace(rng, b1, (2, 2))) for i, j in pairs]
    w = [info(t) for t in noisy]
    tree = greedy_tree(w, pairs, m)
    return (tree, w) + (release_given(x, tree, eps / 2, rng),)


def release_given(x, tree, eps, rng):
    """release the tables of a given tree with Laplace noise (m - 1 tables share eps) and draw fake records along it"""
    n, m = x.shape
    b2 = (m - 1) / eps
    tabs = {e: np.maximum(0, pair_table(x, *e) + laplace(rng, b2, (2, 2))) for e in tree}
    # draw along the tree from column 0
    adj = {i: [] for i in range(m)}
    for i, j in tree:
        adj[i].append(j); adj[j].append(i)
    order, par = [0], {0: None}
    for u in order:
        for v in sorted(adj[u]):
            if v not in par:
                par[v] = u; order.append(v)
    e0 = next(e for e in tree if 0 in e)
    t0 = tabs[e0] if e0[0] == 0 else tabs[e0].T
    p0 = t0[0].sum() / max(t0.sum(), 1e-12)
    fake = np.zeros((n, m), dtype=int)
    fake[:, 0] = rng.random(n) < p0
    for v in order[1:]:
        u = par[v]
        t = tabs[(min(u, v), max(u, v))]
        if u > v:
            t = t.T                                   # rows = u
        p_yes = np.where(t.sum(1) > 0, t[:, 0] / np.maximum(t.sum(1), 1e-12), 0.5)   # P(v = yes | u = yes), (u = no)
        fake[:, v] = rng.random(n) < np.where(fake[:, u] == 1, p_yes[0], p_yes[1])
    return fake


# ---------------------------------------------------------------------------------------------
# Experiment 1. The clinic (the story of Lab 7). 1000 patients, columns smokes, coughs, breathless, chest pain; coughs
# agrees with smokes 7/8, breathless and chest pain agree with coughs 3/4 and 5/8 (Lecture 7's friends).
# PREDICT: at privacy level EPS = 1 the released tree is 1-2, 2-3, 2-4. At EPS = 0.3? At EPS = 0.1 with N = 10 000?
# ---------------------------------------------------------------------------------------------
COLS = ["smokes", "coughs", "breathless", "chest pain"]
PARENT, AGREE = [None, 0, 1, 1], [None, 7 / 8, 3 / 4, 5 / 8]
N, EPS, SEED = 1000, 1.0, 7


def experiment1():
    rng = np.random.default_rng(SEED)
    x = draw_tree_data(N, rng, PARENT, AGREE)
    tree, w, fake = release_tree(x, EPS, rng)
    pairs = list(itertools.combinations(range(4), 2))
    real_i = [info(pair_table(x, i, j)) for i, j in pairs]
    fake_i = [info(pair_table(fake, i, j)) for i, j in pairs]
    print("privacy level eps = %g, %d patients" % (EPS, N))
    print("released tree:", ", ".join("%d-%d" % (i + 1, j + 1) for i, j in tree), " (the truth: 1-2, 2-3, 2-4)")
    print("pair   real   noisy  fake")
    for k, (i, j) in enumerate(pairs):
        print("%d-%d   %.3f  %.3f  %.3f" % (i + 1, j + 1, real_i[k], w[k], fake_i[k]))
    print("share saying yes, real:", np.round(x.mean(0), 3), " fake:", np.round(fake.mean(0), 3))
    # how often is the tree right, by privacy level (200 releases each)
    levels, right = [0.05, 0.1, 0.2, 0.5, 1, 2], []
    for eps in levels:
        r = np.random.default_rng(SEED + 1)
        ok = sum(release_tree(x, eps, r)[0] == [(0, 1), (1, 2), (1, 3)] for _ in range(200))
        right.append(ok / 200)
    print("tree right, by privacy level:", dict(zip(levels, right)))
    fig = plt.figure("clinic", figsize=(11, 4))
    ax = fig.add_subplot(1, 2, 1)
    k = np.arange(6)
    ax.bar(k - 0.2, real_i, 0.4, label="real", color="#0057e7"); ax.bar(k + 0.2, fake_i, 0.4, label="fake", color="#07843a")
    ax.set_xticks(k, ["%d-%d" % (i + 1, j + 1) for i, j in pairs]); ax.set_ylabel("information (nats)"); ax.legend(); ax.set_title("eps = %g" % EPS)
    ax = fig.add_subplot(1, 2, 2)
    ax.semilogx(levels, right, "o-", color="#a600a6"); ax.set_xlabel("privacy level eps"); ax.set_ylabel("true tree released"); ax.set_ylim(0, 1.05)
    show()


# ---------------------------------------------------------------------------------------------
# Experiment 2. The two-gene disease: the disease appears when exactly one of two risk genes is present (C = A xor B).
# Every pair of columns has information about 0, so the tree cannot keep the pattern.
# PREDICT: in the fake patients, what share of each gene group has the disease? What if we also release the noisy
# three-column table (8 cells) and draw from it?
# ---------------------------------------------------------------------------------------------
def experiment2():
    rng = np.random.default_rng(SEED)
    a = (rng.random(N) < 0.5).astype(int); b = (rng.random(N) < 0.5).astype(int)
    x = np.stack([a, b, a ^ b], 1)
    _, w, fake_tree = release_tree(x, 1.0, rng)
    print("pair information (real):", [round(info(pair_table(x, i, j)), 3) for i, j in itertools.combinations(range(3), 2)])
    cells = np.array([np.sum((x[:, 0] == p) & (x[:, 1] == q) & (x[:, 2] == r)) for p in (0, 1) for q in (0, 1) for r in (0, 1)], float)
    # TODO (experiment 2): release the 8 cells with Laplace noise of scale 1 / eps, eps = 1 (one table: each patient
    # changes one cell), and set negative counts to 0. (Answer: np.maximum(0, cells + laplace(rng, 1 / 1.0, 8)).)
    noisy = None
    if noisy is None:
        sys.exit("Complete the TODO in experiment2 first: the noisy 8-cell table.")
    idx = rng.choice(8, size=N, p=noisy / noisy.sum())
    fake_full = np.array([[(i >> 2) & 1, (i >> 1) & 1, i & 1] for i in idx])
    for name, data in (("real", x), ("fake from a tree", fake_tree), ("fake from the 3-column table", fake_full)):
        shares = [data[(data[:, 0] == p) & (data[:, 1] == q), 2].mean() for p, q in ((1, 1), (1, 0), (0, 1), (0, 0))]
        print("%-30s disease share in groups both / A only / B only / neither: %s" % (name, np.round(shares, 2)))


# ---------------------------------------------------------------------------------------------
# Experiment 3. More columns: a chain of m columns, each agreeing with the one before with chance 3/4, N = 2000,
# eps = 1. Release (a) the full table of 2^m cells with Laplace noise 1 / eps per cell, (b) the chain's m - 1 tables with
# Laplace noise (m - 1) / eps, the links taken as known (as if chosen on a public sample; experiment 1 shows the cost of
# choosing them, which real MST keeps small with a private greedy rule). Score: the average error of the fake data's
# pair agreement rates against the real ones.
# PREDICT: as m grows, which error grows faster, and why?
# ---------------------------------------------------------------------------------------------
def experiment3():
    errs = {"full table": [], "tree": []}
    ms = [4, 6, 8, 10, 12, 14, 16]
    for m in ms:
        rng = np.random.default_rng(SEED + m)
        x = draw_tree_data(2000, rng, [None] + list(range(m - 1)), [None] + [0.75] * (m - 1))
        codes = x @ (1 << np.arange(m)[::-1])
        cells = np.bincount(codes, minlength=2 ** m).astype(float)
        noisy = np.maximum(0, cells + laplace(rng, 1.0, 2 ** m))
        idx = rng.choice(2 ** m, size=2000, p=noisy / noisy.sum())
        fake_full = (idx[:, None] >> np.arange(m)[::-1]) & 1
        fake_tree = release_given(x, [(c, c + 1) for c in range(m - 1)], 1.0, rng)
        agree = lambda d: np.array([np.mean(d[:, i] == d[:, j]) for i, j in itertools.combinations(range(m), 2)])
        errs["full table"].append(np.abs(agree(fake_full) - agree(x)).mean())
        errs["tree"].append(np.abs(agree(fake_tree) - agree(x)).mean())
        print("m = %2d: average error, full table %.3f, tree %.3f" % (m, errs["full table"][-1], errs["tree"][-1]))
    fig = plt.figure("columns", figsize=(6, 4))
    for k, col in (("full table", "#c86400"), ("tree", "#a600a6")):
        plt.plot(ms, errs[k], "o-", color=col, label=k)
    plt.xlabel("columns m"); plt.ylabel("average error of pair agreement"); plt.legend()
    show()


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "1"
    {"1": experiment1, "2": experiment2, "3": experiment3}[which]()
