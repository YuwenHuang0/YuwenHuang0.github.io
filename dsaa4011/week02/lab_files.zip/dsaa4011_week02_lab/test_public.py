"""Public tests. Run with:  python -m pytest -q test_public.py

By default these exercise ``starter.py``.

Read the last test in this file before you start. It is the one that matters:
a symmetric example cannot tell a correct implementation from a transposed one.
"""

import importlib
import os

import numpy as np
import pytest

import model

M = importlib.import_module(os.environ.get("LAB_MODULE", "starter"))


# --------------------------------------------------------------------------
# The interface itself
# --------------------------------------------------------------------------
def test_normalize_scales_to_one():
    assert np.allclose(M.normalize([1, 3]), [0.25, 0.75])


def test_normalize_rejects_zero_total_weight():
    """Zero total weight means impossible evidence, not a small number."""
    with pytest.raises(ValueError):
        M.normalize([0.0, 0.0])


def test_normalize_rejects_negative_entries():
    with pytest.raises(ValueError):
        M.normalize([1.0, -1.0])


def test_degree_two_warm_up_matches_the_hand_calculation():
    """The calculation done by hand on the slides."""
    assert np.allclose(M.factor_message([[1, 2], [3, 4]], [2, 1]), [5, 8])


def test_variable_belief_multiplies_then_normalizes():
    assert np.allclose(M.variable_belief([1, 3], [2, 1]), [0.4, 0.6])


# --------------------------------------------------------------------------
# The two local rules
# --------------------------------------------------------------------------
def test_message_length_follows_the_receiver_not_the_table():
    """f245 holds twelve entries yet sends two numbers to X4 and three to X5."""
    scope = (model.X2, model.X4, model.X5)
    ones2, ones3 = np.ones(2), np.ones(3)
    to_x4 = M.factor_to_variable(scope, model.F245, model.X4,
                                 {model.X2: ones2, model.X5: ones3})
    to_x5 = M.factor_to_variable(scope, model.F245, model.X5,
                                 {model.X2: ones2, model.X4: ones2})
    assert to_x4.shape == (2,)
    assert to_x5.shape == (3,)


def test_the_message_out_of_f245_matches_the_slide():
    """m_{245->2} = (10, 20), computed on the slide by hand."""
    scope = (model.X2, model.X4, model.X5)
    got = M.factor_to_variable(scope, model.F245, model.X2,
                               {model.X4: np.ones(2), model.X5: np.ones(3)})
    assert np.allclose(got, [10.0, 20.0])


def test_empty_product_is_one_not_zero():
    """An unobserved leaf sends all ones. A three-state leaf sends (1, 1, 1)."""
    assert np.allclose(M.variable_to_factor(3, []), [1.0, 1.0, 1.0])


# --------------------------------------------------------------------------
# The whole calculation, against the independent reference
# --------------------------------------------------------------------------
def test_sum_product_reproduces_enumeration_on_the_week_two_tree():
    domains, local_functions, evidence = model.tree_model()
    got = M.sum_product(domains, local_functions, evidence)
    want = M.enumerate_marginals(domains, local_functions, evidence)
    for g, w in zip(got, want):
        assert np.allclose(g, w)


def test_the_marginals_are_the_ones_on_the_slide():
    domains, local_functions, evidence = model.tree_model()
    got = M.sum_product(domains, local_functions, evidence)
    assert np.allclose(got[model.X2], [1 / 5, 4 / 5])
    assert np.allclose(got[model.X4], [19 / 50, 31 / 50])
    assert np.allclose(got[model.X5], [9 / 50, 3 / 10, 13 / 25])


@pytest.mark.parametrize("root", [0, 1, 2, 3, 4])
def test_the_answer_does_not_depend_on_the_root(root):
    """Changing the root changes the order of work, never the answer."""
    domains, local_functions, evidence = model.tree_model()
    base = M.sum_product(domains, local_functions, evidence, root=0)
    got = M.sum_product(domains, local_functions, evidence, root=root)
    for g, b in zip(got, base):
        assert np.allclose(g, b)


def test_a_cyclic_graph_is_rejected_rather_than_answered():
    domains, local_functions, evidence = model.cyclic_model()
    with pytest.raises(ValueError):
        M.sum_product(domains, local_functions, evidence)


def test_impossible_evidence_is_reported_not_divided_by():
    domains, local_functions, _ = model.hard_constraint_model()
    impossible = {model.X2: 1, model.X4: 1, model.X5: model.LOW}
    with pytest.raises(ValueError):
        M.sum_product(domains, local_functions, impossible)


def test_a_declared_shape_that_does_not_match_its_scope_is_rejected():
    bad = ((2, 3), (((0, 1), np.ones((3, 2))),), {})
    with pytest.raises(ValueError):
        M.sum_product(*bad)


# --------------------------------------------------------------------------
# Read this one.
# --------------------------------------------------------------------------
def test_a_symmetric_example_proves_almost_nothing():
    """A passing suite is not evidence if every case is symmetric.

    This model is invariant under transposing the table, so an implementation
    that sums the wrong axis returns exactly the same answer. Design better
    tests than this one.
    """
    symmetric = ((2, 2), (((0, 1), np.array([[2.0, 1.0], [1.0, 2.0]])),), {})
    got = M.sum_product(*symmetric)
    assert np.allclose(got[0], [0.5, 0.5])
