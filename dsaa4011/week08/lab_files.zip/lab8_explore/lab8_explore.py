"""DSAA 4011 Lab 8, explore after class: when the reward is wrong.

A toy world of reward hacking. An answer has quality q and length l (standard units, 0 = typical). People want
g = q + l - l^2: a bit longer helps, much longer hurts. A reward model r = a*q + b*l is fitted to people's picks
(Bradley-Terry), and best-of-n keeps the answer with the largest r. Each experiment asks you to PREDICT first, then
complete the line marked TODO, then run.

    python lab8_explore.py 1        # the numbers layer: how many ratings find the best n?
    python lab8_explore.py 2        # the question layer: a leash to the base model instead of best-of-n
    python lab8_explore.py 3        # a new blind spot: raters who like flattery

Needs numpy and matplotlib. Every run is seeded, so you and your neighbour get the same numbers. The figures appear
together when the experiment ends; with MPLBACKEND=Agg (no display) they are saved as PNG files instead.
"""
import sys
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

NS = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024]


def show():
    """Show every figure at the end of an experiment, or save them when there is no display."""
    if matplotlib.get_backend().lower().startswith("agg"):
        for n in plt.get_fignums():
            name = "lab8_%s.png" % plt.figure(n).get_label()
            plt.figure(n).savefig(name, dpi=120, bbox_inches="tight")
            print("figure saved as", name)
    else:
        plt.show()


def todo(x, what):
    if x is None:
        sys.exit("Complete the TODO line first: " + what)
    return x


# ---------------------------------------------------------------------------------------------
# Tools shared by the experiments
# ---------------------------------------------------------------------------------------------
def true_score(Z):
    """people's score of answers Z[..., 0] = quality q, Z[..., 1] = length l"""
    q, l = Z[..., 0], Z[..., 1]
    return q + l - l ** 2


def fit_bradley_terry(XA, XB, y, steps=50):
    """Maximum likelihood for P(A preferred) = sigmoid(w . (xA - xB)), by Newton's method (Lecture 5)."""
    X = XA - XB
    w = np.zeros(X.shape[1])
    for _ in range(steps):
        p = 1 / (1 + np.exp(-X @ w))
        H = X.T @ (X * (p * (1 - p))[:, None]) + 1e-9 * np.eye(len(w))
        w += np.linalg.solve(H, X.T @ (y - p))
    return w


def picks(rng, m, judge):
    """m pairs of base answers and the label 1 if a person picked the first; judge(Z) is the person's taste"""
    A, B = rng.standard_normal((m, 2)), rng.standard_normal((m, 2))
    p = 1 / (1 + np.exp(-(judge(A) - judge(B))))
    return A, B, (rng.random(m) < p).astype(float)


def best_of_n(rng, n, reps, w, feats):
    """reps prompts: draw n base answers each, keep the one with the largest r = w . feats(answer)"""
    Z = rng.standard_normal((reps, n, 2))
    k = np.argmax(feats(Z) @ w, axis=1)
    return Z[np.arange(reps), k]


lin = lambda Z: Z                                                   # r sees q and l


# ---------------------------------------------------------------------------------------------
# Experiment 1: the numbers layer
# ---------------------------------------------------------------------------------------------
def experiment1(m=20, seeds=5):
    rng = np.random.default_rng(8)
    A, B, y = picks(rng, 5000, true_score)
    w = fit_bradley_terry(A, B, y)
    print("reward model: r = %.2f q + %.2f l" % tuple(w))
    exact = [true_score(best_of_n(rng, n, 4000, w, lin)).mean() for n in NS]
    print("people's score, many ratings:  " + "  ".join("n=%d: %.2f" % (n, g) for n, g in zip(NS, exact)))
    fig = plt.figure("exp1_ratings", figsize=(8, 4.5))
    plt.plot(NS, exact, "k--", label="many ratings")
    for s in range(seeds):
        er = np.random.default_rng(100 + s)
        means, ses = [], []
        for n in NS:
            g = true_score(best_of_n(er, n, m, w, lin))
            means.append(g.mean())
            se = None   # TODO: the standard error of the mean of the m ratings in g (use g.std(ddof=1))
            ses.append(todo(se, "experiment 1, the standard error"))
        best = NS[int(np.argmax(means))]
        print("seed %d, %d ratings per n: best-looking n = %4d   (2 standard errors at n = 32: %.2f)" % (s, m, best, 2 * ses[5]))
        plt.errorbar(np.array(NS) * (1 + 0.04 * s), means, yerr=2 * np.array(ses), fmt="o", ms=4, capsize=2, alpha=0.7)
    plt.xscale("log", base=2); plt.xlabel("n"); plt.ylabel("people's score"); plt.title("%d ratings per n, %d seeds" % (m, seeds))
    plt.legend(); show()


# ---------------------------------------------------------------------------------------------
# Experiment 2: the question layer
# ---------------------------------------------------------------------------------------------
def experiment2():
    rng = np.random.default_rng(8)
    A, B, y = picks(rng, 5000, true_score)
    w = fit_bradley_terry(A, B, y)
    # The leash: maximize E[r] - beta * KL(pi || pi0). The best pi is pi0(y) * exp(r(y)/beta) / Z. For our normal base
    # model and a straight-line r = w . (q, l), that is again normal, with the mean moved by w / beta.
    betas = [4, 2, 1, 0.7, 0.5, 0.35, 0.25, 0.15, 0.1]
    out = []
    for beta in betas:
        shift = None   # TODO: the shift of the mean of (q, l) for this beta
        Z = rng.standard_normal((200000, 2)) + todo(shift, "experiment 2, the shift")
        kl = float(np.sum(np.asarray(shift) ** 2) / 2)
        out.append((beta, kl, true_score(Z).mean(), (Z @ w).mean()))
        print("beta = %4.2f   KL = %5.2f   people's score = %6.3f   reward = %5.2f" % out[-1])
    bon = [(np.log(n) - (n - 1) / n, true_score(best_of_n(rng, n, 4000, w, lin)).mean()) for n in NS]
    fig = plt.figure("exp2_leash", figsize=(8, 4.5))
    plt.plot([np.sqrt(k) for _, k, _, _ in out], [g for _, _, g, _ in out], "o-", label="leash (one beta per dot)")
    plt.plot([np.sqrt(k) for k, _ in bon], [g for _, g in bon], "s-", label="best-of-n (one n per dot)")
    plt.xlabel("distance from the base model, sqrt(KL)"); plt.ylabel("people's score"); plt.legend(); show()


# ---------------------------------------------------------------------------------------------
# Experiment 3: a new blind spot
# ---------------------------------------------------------------------------------------------
def experiment3(like=0.5):
    """Answers now also have flattery f. Raters enjoy it a little (+like * f); people who use the answers later do not
    (- f^2). The reward model sees q, l, l^2 and f, so its model layer is no longer the problem."""
    rng = np.random.default_rng(8)
    feats = lambda Z: np.stack([Z[..., 0], Z[..., 1], Z[..., 1] ** 2, Z[..., 2]], axis=-1)
    rater = lambda Z: Z[..., 0] + Z[..., 1] - Z[..., 1] ** 2 + like * Z[..., 2]
    later = lambda Z: Z[..., 0] + Z[..., 1] - Z[..., 1] ** 2 - Z[..., 2] ** 2
    A, B = rng.standard_normal((5000, 3)), rng.standard_normal((5000, 3))
    y = (rng.random(5000) < 1 / (1 + np.exp(-(rater(A) - rater(B))))).astype(float)
    w = fit_bradley_terry(feats(A), feats(B), y)
    print("reward model: r = %.2f q + %.2f l %+.2f l^2 %+.2f f" % tuple(w))
    rows = []
    for n in NS:
        Z = rng.standard_normal((4000, n, 3))
        k = None   # TODO: for each of the 4000 prompts, the index of the answer with the largest r (np.argmax over axis 1)
        sel = Z[np.arange(4000), todo(k, "experiment 3, the kept answer")]
        rows.append((n, rater(sel).mean(), later(sel).mean(), sel[:, 2].mean()))
        print("n = %4d   raters' score = %5.2f   users' score = %5.2f   flattery = %4.2f" % rows[-1])
    fig = plt.figure("exp3_flattery", figsize=(8, 4.5))
    plt.plot(NS, [r[1] for r in rows], "o-", label="raters (who picked)")
    plt.plot(NS, [r[2] for r in rows], "s-", label="users (who live with it)")
    plt.xscale("log", base=2); plt.xlabel("n"); plt.ylabel("score"); plt.legend(); show()


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else ""
    {"1": experiment1, "2": experiment2, "3": experiment3}.get(which, lambda: sys.exit(__doc__))()
