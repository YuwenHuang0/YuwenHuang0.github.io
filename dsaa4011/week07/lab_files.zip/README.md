# DSAA 4011 Lab 7 kit: sharing data, not people

A clinic wants others to train models on its records without showing any patient. It releases a Chow–Liu tree of
noisy counts (Lecture 7) and draws fake patients from it: the idea of MST, the maximum spanning tree method for private
synthetic data, simplified.

```
python lab7_explore.py 1     # the clinic: noisy pair tables, the best tree, fake patients
python lab7_explore.py 2     # the two-gene disease: a pattern that no pair can see
python lab7_explore.py 3     # more columns: the full table against a tree
```

Needs Python 3 with numpy and matplotlib. Every run is seeded. With `MPLBACKEND=Agg` the figures are saved as PNG files.

## Before you run

Each experiment has one line marked `TODO`. Complete it first; the program stops with a message until you do.
Experiment 3 also needs the `TODO` of experiment 1.

**Write your prediction down first.**

1. **The clinic.** At privacy level ε = 1 the released tree is 1–2, 2–3, 2–4.
   - Is the tree still right at ε = 0.3?
   - With `N = 10000` patients, is it right at ε = 0.1?
2. **The two-gene disease.** Every pair of columns has information about 0.
   - What share of each gene group gets the disease in fake patients drawn from a tree?
   - What share do they get when drawn from the noisy three-column table?
3. **More columns.** As the number of columns m grows from 4 to 16, which error grows faster: the full table's or the tree's? Why?

## Answers (read after you run)

1. **The clinic.**
   - At ε = 0.3, noise of scale 6/0.15 = 40 sits on counts of about 50 to 450. The tree is right in only about 45% of releases, and most wrong trees misplace the weak link to *chest pain*.
   - With 10 000 patients the counts are ten times larger, but the noise stays the same, so the tree comes back even at ε = 0.1: right in about 92% of releases.
   - Privacy noise acts like a short notebook in Lecture 7.
2. **The two-gene disease.**
   - From a tree, every group gets the disease about half the time: the pattern is lost, because a tree keeps only what pairs can see.
   - The three-column table keeps it (0%, 100%, 100%, 0%), at the price of one larger table. This is why AIM adds such tables.
3. **More columns.**
   - The full table's error grows quickly. Its 2^m cells hold fewer and fewer patients, so the noise on each cell soon exceeds the count.
   - The tree's error stays small, because its m − 1 tables keep about 500 patients per cell.
   - Here the links are given. Experiment 1 shows the cost of choosing them; real MST keeps that cost small with a private greedy rule.

## Further reading

- R. McKenna, G. Miklau and D. Sheldon. Winning the NIST contest: a scalable and general approach to differentially private synthetic data. *Journal of Privacy and Confidentiality* 11(3), 2021.
- R. McKenna, B. Mullins, D. Sheldon and G. Miklau. AIM: an adaptive and iterative mechanism for differentially private synthetic data. *PVLDB* 15(11):2599–2612, 2022.
- MST and AIM are available in OpenDP's SmartNoise Synth library (`pip install smartnoise-synth`).
