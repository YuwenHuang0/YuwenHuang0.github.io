# DSAA 4011 Lab 9 kit: weather on a ring

GraphCast as a toy. Twenty weather stations sit on one circle of latitude. Every 6 hours the true weather mixes each
station with its neighbours: new temperature = 0.5 · west neighbour + 0.3 · own + 0.2 · east neighbour (the wind
blows from west to east). We see only 100 noisy pairs of readings (now, 6 hours later); each reading is off by about
0.2 °C. In this training season the warm patch always sits over stations 4 to 8.

Two forecasters learn from these pairs:

- **plain network**: each of the 20 forecasts is its own weighted sum of all 20 readings (420 numbers);
- **message passing**: each station i hears a message M_θ(h_i, h_j, e_ji) from each linked station j (h: temperature,
  e: where j sits) and adds the messages to its value. M_θ is one small network (81 numbers) used on every link.
  One round of messages is one 6-hour step.

```
python lab9_explore.py 1     # size and renumbering
python lab9_explore.py 2     # rolling out for 10 days
python lab9_explore.py 3     # how far messages reach: a fast wind, then long links
```

Needs Python 3 with numpy and matplotlib only. Every run is seeded. Each network trains in about 10 seconds. With
`MPLBACKEND=Agg` the figures are saved as PNG files.

## Before you run

Each experiment has one line marked `TODO`. Complete it first; the program stops with a message until you do.

**Write your prediction down first.**

1. **Size and renumbering.** Both forecasters are trained on 20 stations.
   - Add 7 to every station number (the same weather, numbered from another station). Does the plain network's error
     change? Does the message-passing error change?
   - Is the message-passing forecast on 40 or 100 stations worse than on 20?
2. **Rolling out.** Feed each forecast back in, 40 times (10 days).
   - How does the error of message passing grow from 6 hours to 10 days?
   - When does the plain network fall clearly behind?
   - The true rule keeps the ring's average temperature. Does the message-passing forecast keep it?
3. **How far messages reach.** Now the wind carries air two stations every 6 hours. Warm station 11 by 1 °C.
   - With links to neighbours only, how much does station 13's 6-hour forecast change? After 12 hours?
   - Add long links (each station also links to the stations two away). What changes?

## Answers (read after you run)

1. **Size and renumbering.**
   - Plain network: 0.05 °C on the training numbers, **1.37 °C** after renumbering, worse than keeping today's values
     (0.25 °C). It learned rules tied to station numbers: each station gives its west neighbour a different weight
     (from −0.09 to 0.31; the truth is 0.5), and it leans on far stations. It cannot run on 100 stations at all.
   - Message passing: 0.030 °C on the training numbers and after renumbering; the two forecasts differ by exactly 0.
     A shift keeps every neighbour and every direction, so every message is the same (permutation equivariance,
     Lecture 9).
   - On 40 and 100 stations: 0.030 °C and 0.033 °C. A rule about neighbours does not depend on how many stations
     there are.
2. **Rolling out.**
   - Message passing: 0.03 °C at 6 hours, 0.10 °C at 1 day, 0.28 °C at 5 days, **0.42 °C at 10 days**. Each step's
     small error becomes part of the next input.
   - Plain network: 0.05, 0.49, 1.23 and 1.33 °C. It is behind already after one day: as the weather moves, the
     warm patch leaves stations 4 to 8, and the plain network has never seen that.
   - No. The learned weights at a calm state are 0.44, 0.36 and 0.20; they sum to 0.99, not 1, so the forecast slowly
     loses heat (ring average 0.89 °C instead of 1.13 °C after 10 days). The noisy readings pull the learned weights
     slightly low. Training on forecasts of several steps, or building "keep the average" into M_θ, are two repairs.
3. **How far messages reach.**
   - Neighbour links: station 13 does not change at all after 6 hours (0.00 °C; the truth changes by 0.30 °C).
     Station 11 is two links away, and one round of messages reaches only one link. After 12 hours the news arrives
     (0.40 °C against the true 0.22 °C), too late and too strong. The 6-hour error is 0.091 °C.
   - Long links: the change after 6 hours is 0.23 °C (true 0.30 °C), and the 6-hour error drops to 0.028 °C.
     GraphCast's mesh does the same at the scale of the globe: links from coarse meshes carry news thousands of
     kilometres in one round (multiscale networks, Lecture 11).

## Going further (no answers given)

- Train M_θ on 2-step forecasts (apply `mp_step` twice inside the loss). Does the 10-day error drop?
- Train 5 message networks on resampled training pairs. Does their spread grow with hours ahead, as the error does?
- Give the fast-wind model two rounds of neighbour messages per 6-hour step instead of long links. Is it as good?

## Further reading

- R. Lam, A. Sanchez-Gonzalez, M. Willson, et al. Learning skillful medium-range global weather forecasting.
  *Science* 382(6677):1416–1421, 2023.
- I. Price, A. Sanchez-Gonzalez, F. Alet, et al. Probabilistic weather forecasting with machine learning.
  *Nature* 637:84–90, 2025.
- D. Kochkov, J. Yuval, I. Langmore, et al. Neural general circulation models for weather and climate.
  *Nature* 632:1060–1066, 2024.
- J. Gilmer, S. S. Schoenholz, P. F. Riley, O. Vinyals and G. E. Dahl. Neural message passing for quantum chemistry.
  *International Conference on Machine Learning (ICML)*, PMLR 70:1263–1272, 2017.
