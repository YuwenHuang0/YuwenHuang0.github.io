Lab 10 — From Pixels to Latents
Friday 13 November 2026, 15:00–15:50, E1-150

Requires Python 3 and numpy. Install numpy if needed: python -m pip install numpy

Predict first, then run:
1. python lab10.py compress
2. python lab10.py attention
3. python lab10.py noise

Open results/compression.svg and results/latent_noise.svg in your browser. Explain why different pictures can share a mean-only code, why a second channel changes entry count but not position count, and why a decoder alone is not a denoiser.

The codec is a hand-written teaching example. Exact reconstruction holds only for its mean-plus-checkerboard family. No VAE, learned encoder or diffusion denoiser is trained. The original Week 10 AMP files are unrelated and are not required.

Checks: python -m unittest discover -p "test*.py"
Inputs must be nonempty finite real matrices. encode requires even image dimensions. SVG display clips brightness to [0,1], but error metrics use unclipped values.
