"""DSAA 4011 Lab 6, explore after class: teaching a model to reason, and five other troubles.

Experiment 1 is the story of Lab 6: Way 2 of Lecture 6 (act it out: walk, keep the walks that match, count) inside a
reasoning model, played on the maze walker. Experiments 2-6 are five other troubles with too many stories to list,
each solved by one of Lecture 6's four ways. Each experiment asks you to PREDICT first, then complete one or two lines
marked TODO, then run.

    python lab6_explore.py 1        # the maze walker: walk, keep, count (Monte Carlo EM, as STaR and ReST-EM)
    python lab6_explore.py 2        # a noisy picture: Gibbs, mean field and loopy belief propagation clean it
    python lab6_explore.py 3        # the bits in your phone: a small LDPC code decoded by messages
    python lab6_explore.py 4        # reading a library: latent Dirichlet allocation by variational EM finds two topics
    python lab6_explore.py 5        # ranking players: expectation propagation one match at a time
    python lab6_explore.py 6        # messages that refuse to converge: the three-coin ring

Needs numpy and matplotlib. Every run is seeded, so you and your neighbour get the same numbers. The figures appear
together when the experiment ends; with MPLBACKEND=Agg (no display) they are saved as PNG files instead.
"""
import sys
import itertools
import math
import numpy as np
import matplotlib
import matplotlib.pyplot as plt


def sigmoid(u):
    return 1 / (1 + np.exp(-u))


def show():
    """Show every figure at the end of an experiment, or save them when there is no display."""
    if matplotlib.get_backend().lower().startswith("agg"):
        for n in plt.get_fignums():
            name = "lab6_%s.png" % plt.figure(n).get_label()
            plt.figure(n).savefig(name, dpi=120, bbox_inches="tight")
            print("figure saved as", name)
    else:
        plt.show()


# ---------------------------------------------------------------------------------------------
# Experiment 1. The maze walker (the story of Lab 6). A maze with L = 6 forks; at fork t the walker turns left with
# chance theta[t] (the habits = the model's weights). At forks 1, 3, 5 (MATTER) a right turn dead-ends; at forks 2, 4, 6
# both corridors rejoin. Hidden: the path (the chain of thought). Seen: did the walk exit (is the answer right).
# The loop (Way 2, Monte Carlo EM; on a language model STaR / ReST-EM): K walks with the current habits, keep the walks
# that exit, count the left turns per fork among the kept walks with one imaginary walk each way, repeat ROUNDS times.
# PREDICT: after 10 rounds, where do the habits of forks 1, 3, 5 end, and where do the habits of forks 2, 4, 6 end?
# ---------------------------------------------------------------------------------------------
L_FORKS, MATTER, K_WALKS, ROUNDS = 6, [0, 2, 4], 16, 10
SHORTCUT = None            # set to 2 to open a loop corridor at fork 3: its right turn then also reaches the exit


def maze_round(rng, theta, k_walks=K_WALKS):
    """One round: walk k_walks times with the habits theta (True = left), keep the walks that exit, count."""
    walks = rng.random((k_walks, len(theta))) < theta
    must = [t for t in MATTER if t != SHORTCUT]
    exits = walks[:, must].all(axis=1)
    kept = walks[exits]
    if len(kept) == 0:                                   # nothing to count: the habits do not move (a cold start)
        return theta, 0
    # TODO (1 line): new_theta = the counted habits, one per fork: (left turns at the fork among the kept walks + 1)
    #                divided by (number of kept walks + 2)   (the count step with one imaginary walk each way)
    raise NotImplementedError("Experiment 1: write the count step with one imaginary walk each way")
    return new_theta, len(kept)


def exact_maze_step(theta):
    """The exact E-step: over all 2^L paths, the chance of a left turn at each fork given that the walk exits."""
    must = [t for t in MATTER if t != SHORTCUT]
    num, total = np.zeros(len(theta)), 0.0
    for path in itertools.product((False, True), repeat=len(theta)):
        if not all(path[t] for t in must):
            continue
        p = np.prod([theta[t] if path[t] else 1 - theta[t] for t in range(len(theta))])
        total += p; num += p * np.array(path)
    return num / total


def experiment1(k_walks=K_WALKS, theta0=None):
    rng = np.random.default_rng(27)
    theta = np.full(L_FORKS, 0.5) if theta0 is None else np.array(theta0, dtype=float)
    print("forks that matter: %s   walks per round: %d   start habits: %s" % ([t + 1 for t in MATTER], k_walks, np.round(theta, 2)))
    print("exact E-step from the start (chance of left given the exit):", np.round(exact_maze_step(theta), 2))
    history, kept_counts = [theta.copy()], []
    for r in range(ROUNDS):
        theta, kept = maze_round(rng, theta, k_walks)
        history.append(theta.copy()); kept_counts.append(kept)
        print("round %2d: kept %2d of %d   habits %s" % (r + 1, kept, k_walks, " ".join("%.2f" % v for v in theta)))
    history = np.array(history)
    plt.figure("experiment1", figsize=(9, 4.5))
    for t in range(L_FORKS):
        plt.plot(range(ROUNDS + 1), history[:, t], "o-" if t in MATTER else "s--", color="#07843a" if t in MATTER else "#56585c",
                 label="fork %d%s" % (t + 1, " (matters)" if t in MATTER else ""))
    plt.xlabel("round"); plt.ylabel("habit: chance of a left turn"); plt.ylim(0, 1); plt.legend(loc="center left", bbox_to_anchor=(1.02, 0.5))
    plt.title("Experiment 1: walk, keep, count; kept per round " + " ".join(str(k) for k in kept_counts)); plt.tight_layout()
    show()
    # TRY: experiment1(k_walks=64): do the free forks wander less?  experiment1(theta0=[0.1, 0.5, 0.5, 0.5, 0.5, 0.5]):
    #      how many rounds until fork 1 is found?  SHORTCUT = 2: what happens to fork 3's habit, and why?

# ---------------------------------------------------------------------------------------------
# Experiment 2. A noisy picture. A 32 x 32 black-and-white image; 15% of its pixels are flipped. The grid model:
# neighbouring pixels like to agree (strength BETA) and every pixel has evidence from its noisy value (flip chance 0.15).
# Three ways to clean it: Gibbs sampling (Way 2), mean field (Way 3), loopy belief propagation (Way 4).
# PREDICT: which of the three ways leaves the fewest wrong pixels? Which is the most "sure" (chances all near 0 or 1)?
# ---------------------------------------------------------------------------------------------
BETA, FLIP = 0.8, 0.15


def clean_image(n=32):
    yy, xx = np.mgrid[:n, :n]
    img = ((yy - 12) ** 2 + (xx - 12) ** 2 <= 7 ** 2).astype(int)     # a filled circle
    img[23:27, 3:29] = 1                                                # a bar
    return img


def neighbour_sums(x):
    """For every pixel: the sum of its 4 neighbours' values and the sum of (1 - value); borders have fewer neighbours."""
    pad = np.pad(x.astype(float), 1)
    n1 = pad[:-2, 1:-1] + pad[2:, 1:-1] + pad[1:-1, :-2] + pad[1:-1, 2:]
    count = np.pad(np.ones(x.shape), 1)
    count = count[:-2, 1:-1] + count[2:, 1:-1] + count[1:-1, :-2] + count[1:-1, 2:]
    return n1, count - n1


def icm_once(y, evidence):
    """The naive fix, iterated conditional modes [Besag, 1986], one sweep: in raster order, each pixel takes the value its own
    evidence and its neighbours' current values make likelier (the sign of BETA (n1 - n0) + evidence), in place."""
    x = y.copy(); n = x.shape[0]
    for i in range(n):
        for j in range(n):
            nb = [x[a, b] for a, b in ((i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1)) if 0 <= a < n and 0 <= b < n]
            n1 = sum(nb); n0 = len(nb) - n1
            x[i, j] = 1 if BETA * (n1 - n0) + evidence[i, j] > 0 else 0
    return x


def gibbs(y, evidence, sweeps=30, average_last=20, seed=6):
    """Way 2: redraw every pixel from its own conditional, sweep after sweep; average the last sweeps."""
    rng = np.random.default_rng(seed)
    x = y.copy()
    total = np.zeros(y.shape)
    colour = np.indices(y.shape).sum(axis=0) % 2        # a chessboard: same-colour pixels share no edge, so one colour is redrawn at once
    for s in range(sweeps):
        for c in (0, 1):
            n1, n0 = neighbour_sums(x)
            # TODO (1 line): log_odds = the log-odds that a pixel is 1 rather than 0, from its n1 neighbours at 1, its n0 neighbours at 0
            #                (each neighbour pulls with strength BETA) and its evidence (the array `evidence`, already in log-odds)
            raise NotImplementedError("Experiment 2: write the one-pixel redraw log-odds")
            draw = rng.random(y.shape) < sigmoid(log_odds)
            x = np.where(colour == c, draw, x).astype(int)
        if s >= sweeps - average_last:
            total += x
    return total / average_last                        # the chance of 1 at every pixel, estimated from the samples


def mean_field(evidence, rounds=30):
    """Way 3: every pixel guesses alone, from the current guesses of its neighbours (Theorem A of Lecture 6)."""
    q = np.full(evidence.shape, 0.5)
    colour = np.indices(evidence.shape).sum(axis=0) % 2
    for _ in range(rounds):
        for c in (0, 1):
            n1, n0 = neighbour_sums(q)                    # the expected number of neighbours at 1 and at 0
            q = np.where(colour == c, sigmoid(BETA * (n1 - n0) + evidence), q)
    return q


def loopy_bp(evidence, rounds=30, damping=0.5):
    """Way 4: messages in log-odds form on the grid, all updated at once, damped. m[d] holds the message INTO every pixel
    from its neighbour in direction d (zero where there is no neighbour)."""
    def pass_through(cavity):                           # the message a pixel sends, from everything it knows except the receiver
        return np.logaddexp(BETA + cavity, 0) - np.logaddexp(cavity, BETA)
    m = {d: np.zeros(evidence.shape) for d in ("up", "down", "left", "right")}
    for _ in range(rounds):
        total = evidence + sum(m.values())
        new = {d: np.zeros(evidence.shape) for d in m}
        new["down"][:-1] = pass_through(total - m["up"])[1:]          # what a pixel sends upward arrives from below
        new["up"][1:] = pass_through(total - m["down"])[:-1]
        new["right"][:, :-1] = pass_through(total - m["left"])[:, 1:]
        new["left"][:, 1:] = pass_through(total - m["right"])[:, :-1]
        m = {d: damping * m[d] + (1 - damping) * new[d] for d in m}
    return sigmoid(evidence + sum(m.values()))


def experiment2():
    rng = np.random.default_rng(6)
    img = clean_image()
    y = img ^ (rng.random(img.shape) < FLIP)
    evidence = (2 * y - 1) * np.log((1 - FLIP) / FLIP)                 # log-odds for 1 from the noisy value alone
    results = [("noisy", y.astype(float)), ("ICM once (naive fix)", icm_once(y, evidence).astype(float)),
               ("Gibbs (Way 2)", gibbs(y, evidence)), ("mean field (Way 3)", mean_field(evidence)),
               ("loopy BP (Way 4)", loopy_bp(evidence))]
    plt.figure("experiment2", figsize=(15, 3.4))
    for k, (name, chance) in enumerate(results):
        wrong = int(np.sum((chance > 0.5) != img))
        sure = np.mean(np.minimum(chance, 1 - chance) < 0.05)
        print("%-20s %4d wrong pixels" % (name, wrong) + ("" if k < 2 else
              "   share of pixels whose chance is within 0.05 of 0 or 1: %.2f" % sure))
        plt.subplot(1, 5, k + 1); plt.imshow(chance, cmap="Greys", vmin=0, vmax=1); plt.axis("off")
        plt.title("%s\n%d wrong" % (name, wrong), fontsize=10)
    plt.suptitle("Experiment 2: cleaning a noisy picture (chance of black at every pixel)")
    show()
    # TRY: raise BETA to 1.5. Which way gains, which loses, and what happens to the thin bar?


# ---------------------------------------------------------------------------------------------
# Experiment 3. The bits in your phone. A low-density parity-check (LDPC) code [Gallager, 1962]: 26 bits, 13 checks,
# every bit in 3 checks, every check over 6 bits, no 4-cycles. The all-zero codeword goes through a channel that flips
# each bit with chance p; the decoder passes messages between bits and checks (sum-product in log-likelihood-ratio form).
# PREDICT: at flip chance 0.05, by what factor do the messages reduce the number of wrong bits?
# ---------------------------------------------------------------------------------------------
def ldpc_matrix():
    """Checks are the 13 points of a cyclic Steiner triple system [Kirkman, 1847]; bit b joins the checks {i, i+1, i+4}
    or {i, i+2, i+7} mod 13. Any two checks share exactly one bit, so the factor graph has no 4-cycles (girth 6)."""
    H = np.zeros((13, 26), dtype=int)
    for i in range(13):
        H[[i, (i + 1) % 13, (i + 4) % 13], i] = 1
        H[[i, (i + 2) % 13, (i + 7) % 13], 13 + i] = 1
    overlap = H @ H.T
    np.fill_diagonal(overlap, 0)
    assert overlap.max() == 1 and (H.sum(0) == 3).all() and (H.sum(1) == 6).all(), "the code is not as described"
    return H


def decode(H, y, p, rounds=20):
    """Sum-product decoding of all trials at once. y: trials x bits (0/1 received). Returns the decoded bits."""
    checks, bits = H.shape
    L = (1 - 2 * y) * np.log((1 - p) / p)              # the channel's log-likelihood ratio for every bit (positive favours 0)
    m_cb = np.zeros((len(y), checks, bits))              # messages from checks to bits
    for _ in range(rounds):
        total = L + m_cb.sum(axis=1)
        m_bc = (total[:, None, :] - m_cb) * H            # bit to check: all the bit knows, except what this check told it
        t = np.tanh(0.5 * np.clip(m_bc, -15, 15))
        for c in range(checks):
            members = np.flatnonzero(H[c])
            for k, b in enumerate(members):
                others = np.delete(t[:, c, members], k, axis=1)     # tanh(m/2) of the other 5 bits of this check, trials x 5
                # TODO (1 line): m_cb[:, c, b] = the check-to-bit message by the tanh rule (the product of `others` along axis 1,
                #                then back from tanh(m/2) to m)
                raise NotImplementedError("Experiment 3: write the check-to-bit message")
    return (L + m_cb.sum(axis=1) < 0).astype(int)


def experiment3():
    rng = np.random.default_rng(6)
    H = ldpc_matrix()
    trials = 300
    ps, before, after = [0.02, 0.05, 0.08, 0.11], [], []
    print("all-zero codeword, %d trials of %d bits per flip chance, 20 rounds of messages" % (trials, H.shape[1]))
    print("flip chance   wrong bits before   wrong bits after   factor")
    for p in ps:
        y = (rng.random((trials, H.shape[1])) < p).astype(int)
        decoded = decode(H, y, p)
        before.append(int(y.sum())); after.append(int(decoded.sum()))
        print("   %.2f            %5d              %5d           %s" % (p, before[-1], after[-1],
              "%.0f x" % (before[-1] / after[-1]) if after[-1] else "all corrected"))
    plt.figure("experiment3")
    plt.plot(ps, before, "o-", color="#c86400", label="without decoding")
    plt.plot(ps, after, "s-", color="#0057e7", label="after 20 rounds of messages")
    plt.xlabel("flip chance p"); plt.ylabel("wrong bits in %d trials" % trials); plt.legend()
    plt.title("Experiment 3: messages between bits and checks correct the channel")
    show()
    # TRY: remove one check (H = H[1:]) and run again. How much does one lost check cost?


# ---------------------------------------------------------------------------------------------
# Experiment 4. Reading a library. Eight documents of eight words from a vocabulary of ten; two topics (sport and
# politics) with known word tables generate them. Latent Dirichlet allocation [Blei et al., 2003]: each document's mix is
# hidden too, with a flat Dirichlet prior (ALPHA = 1). Mean-field variational EM: every word guesses its topic alone (the
# E-step, Way 3) from the document's mix guess, a Dirichlet(gamma_d), and the topic tables; the mix guess is updated,
# gamma_dk = ALPHA + the document's guesses for topic k; then the topic tables are counted (the count step).
# PREDICT: will the learned tables match the true ones exactly? What is the one thing that can go wrong?
# ---------------------------------------------------------------------------------------------
VOCAB = ["goal", "team", "match", "score", "coach", "vote", "party", "law", "senate", "bill"]
TRUE_TABLES = np.array([[0.19] * 5 + [0.01] * 5, [0.01] * 5 + [0.19] * 5])          # sport, politics
ALPHA = 1.0


def digamma(x):
    """psi(x) = d ln Gamma(x) / dx, elementwise (recurrence below 6, then the asymptotic series)."""
    x = np.array(x, dtype=float); r = np.zeros_like(x)
    while np.any(x < 6):
        small = x < 6
        r[small] -= 1 / x[small]; x[small] += 1
    f = 1 / (x * x)
    return r + np.log(x) - 0.5 / x - f * (1 / 12 - f * (1 / 120 - f * (1 / 252 - f * (1 / 240 - f / 132))))


def make_library(rng, docs=8, words=8):
    mix = rng.dirichlet([0.3, 0.3], size=docs)                      # each document's true share of the two topics
    W = np.zeros((docs, words), dtype=int)
    for d in range(docs):
        topic = rng.random(words) < mix[d, 1]
        for n in range(words):
            W[d, n] = rng.choice(len(VOCAB), p=TRUE_TABLES[int(topic[n])])
    return W, mix


def variational_em(W, rounds=10, seed=6):
    rng = np.random.default_rng(seed)
    docs, words = W.shape
    tables = 1 + rng.random((2, len(VOCAB)))                        # the start: flat tables plus noise, to break the tie
    tables /= tables.sum(axis=1, keepdims=True)
    gamma = np.full((docs, 2), ALPHA + words / 2)                    # every document's mix guess: Dirichlet(gamma); every word 1/2
    q = np.zeros((docs, words, 2))
    scores = []
    for _ in range(rounds):
        for d in range(docs):
            e = np.exp(digamma(gamma[d]) - digamma(gamma[d].sum()))     # the mix guess's weight for each topic
            for n in range(words):
                # TODO (1 line): q[d, n] = the chance of each topic for this word: the weight e times each topic's chance
                #                of the word W[d, n], normalized to sum to 1   (the E-step, one word alone)
                raise NotImplementedError("Experiment 4: write the per-word topic guess")
        gamma = ALPHA + q.sum(axis=1)                                   # the document's mix guess, from its words' guesses
        elog = digamma(gamma) - digamma(gamma.sum(axis=1, keepdims=True))        # E[ln theta_dk] under the mix guess
        score = np.sum(q * (elog[:, None, :] + np.log(tables[:, W].transpose(1, 2, 0) + 1e-300) - np.log(q + 1e-300)))
        score += np.sum(math.lgamma(2 * ALPHA) - 2 * math.lgamma(ALPHA) + (ALPHA - 1) * elog.sum(axis=1))   # E ln p(theta)
        score += np.sum(-np.vectorize(math.lgamma)(gamma.sum(axis=1)) + np.vectorize(math.lgamma)(gamma).sum(axis=1)
                        - ((gamma - 1) * elog).sum(axis=1))                                                # - E ln q(theta)
        scores.append(float(score))                                       # the score B(q): the ELBO
        for k in range(2):                                                # the count step
            tables[k] = np.bincount(W.ravel(), weights=q[:, :, k].ravel(), minlength=len(VOCAB))
            tables[k] /= tables[k].sum()
    return tables, gamma / gamma.sum(axis=1, keepdims=True), scores


def experiment4():
    rng = np.random.default_rng(6)
    W, true_mix = make_library(rng)
    for d in range(len(W)):
        print("document %d (sport %.2f): %s" % (d + 1, true_mix[d, 0], " ".join(VOCAB[w] for w in W[d])))
    tables, mix, scores = variational_em(W)
    print("\nscore (ELBO) round by round:", " ".join("%.1f" % s for s in scores))
    print("\n%-8s %-20s %-20s" % ("word", "true: sport  politics", "learned: topic 1  topic 2"))
    for v, word in enumerate(VOCAB):
        print("%-8s   %.2f     %.2f           %.2f     %.2f" % (word, TRUE_TABLES[0, v], TRUE_TABLES[1, v], tables[0, v], tables[1, v]))
    print("\ndocument mixes (mean of the mix guess for topic 1, share of sport true):")
    for d in range(len(W)):
        print("  document %d: learned %.2f   true %.2f" % (d + 1, mix[d, 0], true_mix[d, 0]))
    plt.figure("experiment4")
    plt.plot(range(1, len(scores) + 1), scores, "o-", color="#1a9850")
    plt.xlabel("round"); plt.ylabel("score B(q), the ELBO"); plt.title("Experiment 4: the score never falls")
    show()
    # TRY: variational_em(W, seed=11). Do the two topics swap names? Does the score care?


# ---------------------------------------------------------------------------------------------
# Experiment 5 (Program 4). Ranking players from match results, as TrueSkill does [Herbrich et al., 2007]. Four players
# with hidden skills; the stronger player wins with chance Phi((s_i - s_j) / sqrt 2) (Thurstone's rule). Expectation
# propagation in its simplest Gaussian form: one match at a time, cavity, moment match, update; several passes.
# PREDICT: after 12 matches, can we rank all four players with confidence? Which pair stays uncertain?
# ---------------------------------------------------------------------------------------------
def norm_cdf(t):
    return 0.5 * (1 + math.erf(t / math.sqrt(2)))


def norm_pdf(t):
    return math.exp(-0.5 * t * t) / math.sqrt(2 * math.pi)


def play_matches(rng, skills, repeats=2):
    pairs = [(i, j) for i in range(len(skills)) for j in range(i + 1, len(skills))] * repeats
    rng.shuffle(pairs)
    matches = []
    for i, j in pairs:
        i_wins = rng.random() < norm_cdf((skills[i] - skills[j]) / math.sqrt(2))
        matches.append((i, j) if i_wins else (j, i))             # (winner, loser)
    return matches


def expectation_propagation(matches, players=4, passes=5):
    """Every match factor Phi((s_w - s_l) / sqrt 2) is replaced by a Gaussian site on the winner and one on the loser.
    The posterior is kept as precision tau = 1 / variance and nu = mean / variance; the prior on every skill is N(0, 1)."""
    tau, nu = np.ones(players), np.zeros(players)
    site_tau, site_nu = np.zeros((len(matches), 2)), np.zeros((len(matches), 2))
    history = [(nu / tau, 1 / tau)]
    for _ in range(passes):
        for m, (w, l) in enumerate(matches):
            tc, nc = tau[[w, l]] - site_tau[m], nu[[w, l]] - site_nu[m]      # 1. cavity: the posterior without this match
            (vw, vl), (muw, mul) = 1 / tc, nc / tc
            # 2. moment match. Under the cavity, the skill gap d = s_w - s_l is N(muw - mul, vw + vl); the match says
            #    "d plus noise of variance 2 was positive". Let c = sqrt(vw + vl + 2), t = (muw - mul) / c and
            #    lam = pdf(t) / cdf(t). The exact posterior is not Gaussian; its mean and variance are
            #        winner: mean muw + vw * lam / c,   variance vw - vw**2 * lam * (lam + t) / c**2
            #        loser:  mean mul - vl * lam / c,   variance vl - vl**2 * lam * (lam + t) / c**2
            c = math.sqrt(vw + vl + 2)
            t = (muw - mul) / c
            lam = norm_pdf(t) / norm_cdf(t)
            # TODO (2 lines): new_muw = ... and new_vw = ... for the winner, from the formulas above
            raise NotImplementedError("Experiment 5: write the winner's moment-matching update")
            new_mul, new_vl = mul - vl * lam / c, vl - vl ** 2 * lam * (lam + t) / c ** 2
            # 3. update: the new site is whatever turns the cavity into the matched Gaussian
            site_tau[m] = [1 / new_vw - tc[0], 1 / new_vl - tc[1]]
            site_nu[m] = [new_muw / new_vw - nc[0], new_mul / new_vl - nc[1]]
            tau[[w, l]], nu[[w, l]] = tc + site_tau[m], nc + site_nu[m]
        history.append((nu / tau, 1 / tau))
    return history


def experiment5():
    rng = np.random.default_rng(6)
    skills = rng.standard_normal(4)
    matches = play_matches(rng, skills)
    print("matches (winner beats loser):", ", ".join("%s > %s" % ("ABCD"[w], "ABCD"[l]) for w, l in matches))
    history = expectation_propagation(matches)
    mean, var = history[-1]
    print("\nplayer   true skill   estimated mean +- sd")
    for i in range(4):
        print("  %s        %+.2f          %+.2f +- %.2f" % ("ABCD"[i], skills[i], mean[i], math.sqrt(var[i])))
    print("ranking by estimated mean:", " > ".join("ABCD"[i] for i in np.argsort(-mean)),
          "   true ranking:", " > ".join("ABCD"[i] for i in np.argsort(-skills)))
    plt.figure("experiment5", figsize=(9, 4.5))
    for i, colour in enumerate(["#0057e7", "#c86400", "#1a9850", "#b4007a"]):
        plt.errorbar(np.arange(len(history)) + 0.06 * i, [h[0][i] for h in history], yerr=[math.sqrt(h[1][i]) for h in history],
                     fmt="o-", capsize=3, color=colour, label="player %s (true %+.2f)" % ("ABCD"[i], skills[i]))
    plt.xlabel("pass over the %d matches (0 = prior)" % len(matches)); plt.ylabel("skill: mean +- one standard deviation")
    plt.legend(loc="center left", bbox_to_anchor=(1.02, 0.5)); plt.tight_layout()
    plt.title("Experiment 5: expectation propagation narrows the skills pass by pass")
    show()
    # TRY: play_matches(rng, skills, repeats=4) gives 24 matches. Which uncertainties shrink most?


# ---------------------------------------------------------------------------------------------
# Experiment 6 (Program 5). Messages that refuse to converge: the three-coin ring of Lecture 6. Start 1/2; coin A gives
# heads with chance 3/4, coin B with chance 1/4; the flips are H, H, T; each link keeps the same coin with chance KEEP,
# and the third link closes the ring. Loopy belief propagation with and without damping, against the exact answer.
# PREDICT: for keep = 0.05, does damping change where the messages end up, or only how they get there?
# ---------------------------------------------------------------------------------------------
HEADS = {"A": 0.75, "B": 0.25}
FLIPS = "HHT"


def emission(i):
    return np.array([HEADS["A"], HEADS["B"]]) if FLIPS[i] == "H" else np.array([1 - HEADS["A"], 1 - HEADS["B"]])


def exact_ring(keep):
    """List all 8 stories; coin 1's chance of A is the share of weight of the stories where coin 1 is A."""
    weight_a = total = 0.0
    for story in itertools.product((0, 1), repeat=3):               # 0 = A, 1 = B
        w = 0.5 * np.prod([emission(i)[story[i]] for i in range(3)])
        w *= np.prod([keep if story[i] == story[(i + 1) % 3] else 1 - keep for i in range(3)])
        total += w
        weight_a += w if story[0] == 0 else 0
    return weight_a / total


def loopy_ring(keep, damping, rounds=60):
    """Every message starts at (1/2, 1/2); all six messages are recomputed at once from the old ones."""
    edges = [(i, (i + 1) % 3) for i in range(3)] + [((i + 1) % 3, i) for i in range(3)]
    link = np.array([[keep, 1 - keep], [1 - keep, keep]])
    msg = {e: np.array([0.5, 0.5]) for e in edges}
    trace = []
    for _ in range(rounds):
        new = {}
        for i, j in edges:
            cavity = emission(i) * np.prod([msg[(a, b)] for a, b in edges if b == i and a != j], axis=0)
            computed = cavity @ link
            computed = computed / computed.sum()
            # TODO (1 line): new[(i, j)] = the damped message: `damping` parts the old message msg[(i, j)], (1 - damping) parts `computed`
            raise NotImplementedError("Experiment 6: write the damped message update")
        msg = new
        belief = emission(0) * msg[(1, 0)] * msg[(2, 0)]
        trace.append(belief[0] / belief.sum())
    return trace


def experiment6():
    checkpoints = [1, 2, 3, 5, 10, 20, 60]
    print("coin 1's chance of A after each round of messages")
    print("%-26s" % "" + "".join("round %-3d" % r for r in checkpoints) + "exact")
    plt.figure("experiment6", figsize=(8, 4.5))
    for keep, colour in ((0.75, "#0057e7"), (0.05, "#c86400")):
        exact = exact_ring(keep)
        for damping, style in ((0.0, "-"), (0.5, "--")):
            trace = loopy_ring(keep, damping)
            print("keep %.2f, damping %.1f:    " % (keep, damping) + "".join("%-9.3f" % trace[r - 1] for r in checkpoints) + "%.3f" % exact)
            plt.plot(range(1, len(trace) + 1), trace, style, color=colour, label="keep %.2f, damping %.1f" % (keep, damping))
        plt.axhline(exact, color="#1a9850", ls=":")
    plt.xlabel("round"); plt.ylabel("coin 1's chance of A"); plt.legend()
    plt.title("Experiment 6: messages round a ring (dotted: the exact answer 0.75)")
    show()
    # TRY: keep = 0.02. How many rounds do the plain messages need now, and does damping still help?


if __name__ == "__main__":
    {"1": experiment1, "2": experiment2, "3": experiment3, "4": experiment4, "5": experiment5, "6": experiment6}.get(
        sys.argv[1] if len(sys.argv) > 1 else "1", experiment1)()
