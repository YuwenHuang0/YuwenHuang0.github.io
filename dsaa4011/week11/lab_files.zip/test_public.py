"""Meaningful checks for numerical, alignment and input-contract errors."""
import unittest
import numpy as np
from explore_features import load_example,cosine_similarity,pca_colours,prototype_score

class FeatureChecks(unittest.TestCase):
    def test_cosine_by_hand(self):
        f=np.array([[[4.,0],[2.,0]],[[0.,3],[-2.,0]]])
        np.testing.assert_allclose(cosine_similarity(f,0,0),[[1,1],[0,-1]],atol=1e-12)
    def test_query_validation(self):
        f=np.ones((2,3,4))
        for row,col in [(-1,0),(2,0),(0,3),(0.5,0),(True,0)]:
            with self.assertRaises(ValueError):cosine_similarity(f,row,col)
        with self.assertRaises(ValueError):cosine_similarity(np.zeros((1,1,2)),0,0)
        with self.assertRaises(ValueError):cosine_similarity(np.full((2,2,2),np.nan),0,0)
    def test_rgb_alignment(self):
        for name in ('cats','retina'):
            im,rgb=load_example(name,'rgb')
            expected=im.astype(float).reshape(16,16,16,16,3).transpose(0,2,1,3,4).mean((2,3))/255
            np.testing.assert_allclose(rgb,expected,atol=1e-6)
    def test_real_cache(self):
        for name in ('cats','retina'):
            im,f=load_example(name);self.assertEqual(im.shape,(256,256,3));self.assertEqual(f.shape,(16,16,384))
            s=cosine_similarity(f,6,5);self.assertAlmostEqual(s[6,5],1)
            self.assertTrue(np.all((s>=-1)&(s<=1)))
    def test_pca_and_head(self):
        _,f=load_example();rgb=pca_colours(f)
        self.assertEqual(rgb.shape,(16,16,3));self.assertTrue(np.isfinite(rgb).all())
        self.assertTrue(np.all((rgb>=0)&(rgb<=1)))
        a=prototype_score(f,(6,5),(0,0));self.assertGreaterEqual(a[6,5],0)
        np.testing.assert_allclose(prototype_score(f,(6,5),(6,5)),0,atol=1e-12)

if __name__=='__main__':unittest.main(verbosity=2)
