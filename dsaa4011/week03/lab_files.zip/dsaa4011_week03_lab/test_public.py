"""Public tests. Run with:  python -m pytest -q test_public.py

By default these exercise your ``starter.py``. To run them on the reference
functions of ``ising.py`` instead, set the environment variable
``LAB_MODULE=ising``.

The functions that are not part of the exercise (``all_configurations``,
``ising_energy``, ``boltzmann_distribution``, ...) are taken from
``ising.py``.
"""

import importlib
import math
import os

import numpy as np
import pytest

import ising

M = importlib.import_module(os.environ.get("LAB_MODULE", "starter"))

EDGES = ising.grid_edges(4, 4)
CONFIGS = ising.all_configurations(16)
ENERGIES = ising.ising_energy(CONFIGS, EDGES)


def test_the_boltzmann_distribution_is_normalized():
    p = ising.boltzmann_distribution(ENERGIES, 2.0)
    assert math.isclose(p.sum(), 1.0, abs_tol=1e-12)
    assert (p >= 0).all()


def test_shifting_every_energy_by_a_constant_shifts_ln_z_and_nothing_else():
    """``ln Z`` of ``E + c`` is ``ln Z`` of ``E`` minus ``c / T``; the distribution is unchanged."""
    shift = 7.5
    assert math.isclose(M.log_partition_function(ENERGIES + shift, 2.0),
                        M.log_partition_function(ENERGIES, 2.0) - shift / 2.0, abs_tol=1e-9)
    assert np.allclose(ising.boltzmann_distribution(ENERGIES + shift, 2.0),
                       ising.boltzmann_distribution(ENERGIES, 2.0))


def test_both_temperature_limits():
    """At low T the two ground states share the mass, entropy ln 2; at high T entropy 16 ln 2."""
    cold = ising.boltzmann_distribution(ENERGIES, 0.05)
    assert ising.ground_state_probability(cold, ENERGIES) > 0.999
    assert math.isclose(M.entropy(cold), math.log(2), abs_tol=1e-3)
    hot = ising.boltzmann_distribution(ENERGIES, 1e4)
    assert math.isclose(M.entropy(hot), 16 * math.log(2), abs_tol=1e-3)


def test_the_ground_energy_is_minus_24():
    assert ENERGIES.min() == -24.0
    assert ENERGIES.max() == 24.0


def test_there_are_exactly_two_ground_states_all_up_and_all_down():
    ground = CONFIGS[ENERGIES == ENERGIES.min()]
    assert ground.shape[0] == 2
    assert {int(row.sum()) for row in ground} == {-16, 16}


def test_column_closing_equals_enumeration_at_t_2():
    assert math.isclose(ising.transfer_matrix_log_partition(4, 2.0),
                        M.log_partition_function(ENERGIES, 2.0), abs_tol=1e-9)


def test_the_entropy_of_a_point_mass_is_zero():
    p = np.zeros(8)
    p[3] = 1.0
    assert M.entropy(p) == 0.0


def test_the_kl_divergence_is_never_negative():
    rng = np.random.default_rng(0)
    for _ in range(20):
        p = rng.random(8)
        p /= p.sum()
        q = rng.random(8)
        q /= q.sum()
        assert ising.kl_divergence(p, q) >= 0.0
        assert math.isclose(ising.kl_divergence(p, p), 0.0, abs_tol=1e-12)
