"""DSAA 4011 Lab 9, explore after class: weather on a ring.

GraphCast as a toy. n weather stations sit on a ring (one circle of latitude); u_i is the temperature of station i in
degrees C above normal. Every 6 hours the true weather mixes each station with its neighbours:
    new u_i = 0.5 * u_(i-1) + 0.3 * u_i + 0.2 * u_(i+1)        (the wind blows from west, i-1, to east, i+1)
We only see 100 noisy pairs of readings (now, 6 hours later) on 20 stations, and train two forecasters:
    plain network:    each of the 20 forecasts is its own weighted sum of all 20 readings (420 numbers);
    message passing:  each station i hears a message M_theta(h_i, h_j, e_ji) from each linked station j and adds them,
                      h_i <- h_i + sum_j M_theta(h_i, h_j, e_ji); M_theta is one small network (81 numbers) on every link.
Each experiment asks you to PREDICT first, then complete the line marked TODO, then run.

    python lab9_explore.py 1        # size and renumbering: 20 stations -> 100 stations, and a renumbered ring
    python lab9_explore.py 2        # rolling out: forecast error over 10 days, plain network vs message passing
    python lab9_explore.py 3        # how far messages reach: a fast wind, then long links

Needs numpy and matplotlib only. Every run is seeded, so you and your neighbour get the same numbers. The figures
appear when the experiment ends; with MPLBACKEND=Agg (no display) they are saved as PNG files instead.
Training takes about 10 seconds per network.
"""
import sys
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

D, C = 0.2, 0.3          # spreading and wind of the true weather
NOISE = 0.2              # every reading is off by about 0.2 degrees C
SCALE = 8.0              # temperatures enter M_theta divided by 8, so tanh is not saturated
NEIGH = (1, -1)          # links: +1 = the station one to the west, -1 = one to the east
LONG = (1, -1, 2, -2)    # plus long links: two to the west, two to the east


def show():
    """Show every figure at the end of an experiment, or save them when there is no display."""
    if matplotlib.get_backend().lower().startswith("agg"):
        for n in plt.get_fignums():
            name = "lab9_%s.png" % plt.figure(n).get_label()
            plt.figure(n).savefig(name, dpi=120, bbox_inches="tight")
            print("figure saved as", name)
    else:
        plt.show()


def todo(x, what):
    if x is None:
        sys.exit("Complete the TODO line first: " + what)
    return x


# ---------------------------------------------------------------------------------------------
# The toy weather and the two forecasters (shared by the experiments)
# ---------------------------------------------------------------------------------------------
def true_step(u, fast=False):
    """One 6-hour step of the true weather; u has the stations on its last axis. np.roll(u, 1, -1)[i] = u[i-1].
    fast=True: the wind carries air two stations per step (the wind term uses u[i-2])."""
    west = np.roll(u, 2 if fast else 1, -1)
    return u + D * (np.roll(u, 1, -1) - 2 * u + np.roll(u, -1, -1)) - C * (u - west)


def weather(rng, m, n, patch_at=5.0):
    """m days of weather on n stations: one wave of wavelength 20 stations plus a warm patch per 20 stations.
    In the training season the patch always sits over station index 5 (station 6; stations 4 to 8 are warm).
    patch_at=None puts the patches at random places."""
    i = np.arange(n)
    A, B = rng.standard_normal((m, 1)), rng.standard_normal((m, 1))
    u = A * np.cos(2 * np.pi * i / 20) + B * np.sin(2 * np.pi * i / 20)
    for _ in range(n // 20):
        at = patch_at if patch_at is not None else rng.uniform(0, n, (m, 1))
        d = np.abs(i - at); d = np.minimum(d, n - d)
        u = u + rng.uniform(3, 6, (m, 1)) * np.exp(-d ** 2 / 8)
    return u


def season(rng, m=100, n=20, fast=False):
    """the training data: m noisy pairs (reading now, reading 6 hours later)"""
    U = weather(rng, m, n)
    return U + NOISE * rng.standard_normal(U.shape), true_step(U, fast) + NOISE * rng.standard_normal(U.shape)


def plain_fit(X, Y):
    """plain network: forecast = W^T (reading, 1), fitted by least squares; it only accepts exactly 20 stations"""
    W = np.linalg.lstsq(np.c_[X, np.ones(len(X))], Y, rcond=None)[0]
    return lambda u: np.c_[u, np.ones(len(u))] @ W


def edge_inputs(u, offs):
    """for every station i and every link offset o: the inputs (h_i, h_j, e_ji) of M_theta, j = i - o"""
    hi = np.concatenate([u] * len(offs), -1)
    hj = np.concatenate([np.roll(u, o, -1) for o in offs], -1)
    e = np.concatenate([np.full(u.shape, float(o)) for o in offs], -1)
    return np.stack([hi / SCALE, hj / SCALE, e], -1)


def mp_step(u, P, offs=NEIGH):
    """one round of messages = one 6-hour forecast step, on a ring of any size"""
    W1, b1, w2, b2 = P
    n = u.shape[-1]
    m = SCALE * (np.tanh(edge_inputs(u, offs) @ W1 + b1) @ w2 + b2)        # one message per (station, link)
    return u + sum(m[..., k * n:(k + 1) * n] for k in range(len(offs)))    # h_i <- h_i + sum of its messages


def mp_train(X, Y, offs=NEIGH, hidden=16, iters=6000, lr=0.01, seed=0):
    """M_theta: 3 inputs -> 16 tanh units -> 1 message. Adam on the mean squared error of the 6-hour forecast."""
    r = np.random.default_rng(seed)
    P = [r.standard_normal((3, hidden)) * 0.3, np.zeros(hidden), r.standard_normal(hidden) * 0.1, np.array(0.0)]
    M1 = [np.zeros_like(p) for p in P]; M2 = [np.zeros_like(p) for p in P]
    F, n, L = edge_inputs(X, offs), X.shape[-1], len(offs)
    for t in range(1, iters + 1):
        W1, b1, w2, b2 = P
        Z = np.tanh(F @ W1 + b1)
        m = SCALE * (Z @ w2 + b2)
        R = X + sum(m[..., k * n:(k + 1) * n] for k in range(L)) - Y           # forecast minus reading
        g = np.concatenate([R] * L, -1) * 2 / R.size * SCALE                     # chain rule, back to each message
        gA = g[..., None] * w2 * (1 - Z ** 2)
        G = [np.einsum("mkf,mkh->fh", F, gA), gA.sum((0, 1)), np.einsum("mk,mkh->h", g, Z), g.sum()]
        for k in range(4):                                                        # Adam
            M1[k] = 0.9 * M1[k] + 0.1 * G[k]; M2[k] = 0.999 * M2[k] + 0.001 * G[k] ** 2
            P[k] = P[k] - lr * (M1[k] / (1 - 0.9 ** t)) / (np.sqrt(M2[k] / (1 - 0.999 ** t)) + 1e-8)
    return P


err = lambda a, b: float(np.sqrt(np.mean((a - b) ** 2)))     # root-mean-square error in degrees C


# ---------------------------------------------------------------------------------------------
# Experiment 1: size and renumbering
# ---------------------------------------------------------------------------------------------
def experiment1():
    rt = np.random.default_rng(1)
    T20 = weather(rt, 500, 20)
    R20 = None   # TODO: the same 500 days with every station number increased by 7 (use np.roll along the last axis)
    R20 = todo(R20, "experiment 1, the renumbered ring")
    X, Y = season(np.random.default_rng(9))
    plain = plain_fit(X, Y)
    print("training the message rule ...")
    P = mp_train(X, Y)
    T40, T100 = weather(rt, 500, 40, None), weather(rt, 500, 100, None)
    rows = [("plain, 20 stations", err(plain(T20), true_step(T20))), ("plain, renumbered", err(plain(R20), true_step(R20))),
            ("messages, 20 stations", err(mp_step(T20, P), true_step(T20))), ("messages, renumbered", err(mp_step(R20, P), true_step(R20))),
            ("messages, 40 stations", err(mp_step(T40, P), true_step(T40))), ("messages, 100 stations", err(mp_step(T100, P), true_step(T100))),
            ("keep today's values, 20", err(T20, true_step(T20)))]
    for name, e in rows:
        print("%-26s 6-hour forecast error = %.3f degrees C" % (name, e))
    diff = np.max(np.abs(mp_step(R20, P) - np.roll(mp_step(T20, P), 7, -1)))
    print("messages: forecast of the renumbered ring minus the renumbered forecast, largest difference: %.1e" % diff)
    try:
        plain(T100)
    except ValueError:
        print("plain network on 100 stations: it cannot even run (it has exactly 20 input slots)")
    plt.figure("exp1_size_renumbering", figsize=(8, 4.5))
    plt.barh([r[0] for r in rows][::-1], [r[1] for r in rows][::-1], color=["grey"] + ["m"] * 4 + ["tab:orange"] * 2)
    plt.xlabel("6-hour forecast error (degrees C)"); plt.tight_layout(); show()


# ---------------------------------------------------------------------------------------------
# Experiment 2: rolling out for 10 days
# ---------------------------------------------------------------------------------------------
def experiment2(steps=40):
    X, Y = season(np.random.default_rng(9))
    plain = plain_fit(X, Y)
    print("training the message rule ...")
    P = mp_train(X, Y)
    T20 = weather(np.random.default_rng(1), 500, 20)
    truth, up, um = T20.copy(), T20.copy(), T20.copy()
    hours, ep, em, es = [], [], [], []
    for k in range(1, steps + 1):
        truth = true_step(truth)
        up = plain(up)
        um = None   # TODO: the next message-passing forecast, made from the current forecast um (not from the truth)
        um = todo(um, "experiment 2, feeding the forecast back")
        hours.append(6 * k); ep.append(err(up, truth)); em.append(err(um, truth)); es.append(err(T20, truth))
        if 6 * k in (6, 24, 48, 120, 240):
            print("%3d hours ahead: plain %.2f   messages %.2f   keep today's values %.2f  (degrees C)" % (6 * k, ep[-1], em[-1], es[-1]))
    print("ring average after 10 days, true %.3f, message forecast %.3f" % (truth.mean(), um.mean()))
    plt.figure("exp2_rollout", figsize=(8, 4.5))
    for y, name, col in ((es, "keep today's values", "grey"), (ep, "plain network", "tab:orange"), (em, "message passing", "m")):
        plt.plot(hours, y, color=col); plt.text(hours[-1] + 3, y[-1], name, color=col, va="center")
    plt.xlabel("hours ahead"); plt.ylabel("forecast error (degrees C)"); plt.xlim(0, 300); plt.tight_layout(); show()


# ---------------------------------------------------------------------------------------------
# Experiment 3: how far messages reach
# ---------------------------------------------------------------------------------------------
def experiment3():
    X, Y = season(np.random.default_rng(9), fast=True)            # the fast wind: two stations per 6 hours
    print("training with neighbour links, then with long links ...")
    Pn, Pl = mp_train(X, Y, NEIGH), mp_train(X, Y, LONG)
    T = weather(np.random.default_rng(1), 500, 20)
    print("6-hour forecast error, fast wind: neighbour links %.3f, long links %.3f, keep today's values %.3f (degrees C)" % (
        err(mp_step(T, Pn, NEIGH), true_step(T, True)), err(mp_step(T, Pl, LONG), true_step(T, True)), err(T, true_step(T, True))))
    # warm station 11 (index 10) by 1 degree C on a calm ring; how much does station 13 (index 12) change?
    calm = np.zeros((1, 20)); warm = calm.copy(); warm[0, 10] = 1.0
    rows = []
    for name, f in (("true weather", lambda u: true_step(u, True)), ("neighbour links", lambda u: mp_step(u, Pn, NEIGH)),
                    ("long links", lambda u: mp_step(u, Pl, LONG))):
        a, b, ch = calm.copy(), warm.copy(), []
        for k in range(3):
            a, b = f(a), f(b)
            change = None   # TODO: how much station index 12's forecast changed because of the warm station (b minus a)
            ch.append(todo(change, "experiment 3, the change at station 13"))
        rows.append((name, ch))
        print("%-16s change at station 13 after 6, 12, 18 hours: %s" % (name, "  ".join("%.2f" % c for c in ch)))
    plt.figure("exp3_reach", figsize=(8, 4.5))
    for (name, ch), col in zip(rows, ("k", "tab:orange", "m")):
        plt.plot([6, 12, 18], ch, "o-", color=col); plt.text(18.6, ch[-1], name, color=col, va="center")
    plt.xlabel("hours after warming station 11"); plt.ylabel("change at station 13 (degrees C)"); plt.xlim(4, 24)
    plt.tight_layout(); show()


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else ""
    {"1": experiment1, "2": experiment2, "3": experiment3}.get(which, lambda: sys.exit(__doc__))()
