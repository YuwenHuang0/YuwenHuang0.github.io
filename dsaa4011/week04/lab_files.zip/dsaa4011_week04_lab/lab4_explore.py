"""DSAA 4011 Lab 4, explore after class: sampling what we cannot sum.

Four small experiments with the walker of Lecture 4 (the Metropolis-Hastings sampler).
Each one asks you to PREDICT first, then complete one to three lines marked TODO, then run.

    python lab4_explore.py 1        # the walker: visits follow the fits
    python lab4_explore.py 2        # far-apart hills: how long until the walker crosses?
    python lab4_explore.py 3        # heat a copy: parallel tempering
    python lab4_explore.py 4        # generate from noise: annealed Langevin dynamics

Needs numpy and matplotlib. Every run is seeded, so you and your neighbour get the same numbers.
"""
import sys
import numpy as np
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------------------------
# Experiment 1. The walker: its visits follow the fits, and Z is never computed.
# Three pictures with fits g = [1, 2, 5]. PREDICT: what share of its time will the walker spend
# at each picture? (Hint: the target is p = g / Z.)
# ---------------------------------------------------------------------------------------------
def walker(g, steps=100_000, seed=0):
    rng = np.random.default_rng(seed)
    g = np.asarray(g, dtype=float)
    x, visits = 0, np.zeros(len(g))
    for _ in range(steps):
        y = rng.choice([k for k in range(len(g)) if k != x])     # propose another picture
        # TODO (1 line): the test. Move to y with probability min(1, g[y] / g[x]).
        raise NotImplementedError("Experiment 1: write the test")
        visits[x] += 1
    return visits / steps


def experiment1():
    g = [1, 2, 5]
    share = walker(g)
    print("fits          ", g)
    print("walker's share", np.round(share, 3))
    print("target g / Z  ", np.round(np.array(g) / sum(g), 3), " (Z = %d, never used by the walker)" % sum(g))
    plt.bar(range(len(g)), share, color="#c86400", label="the walker's visits")
    plt.plot(range(len(g)), np.array(g) / sum(g), "o--", color="#0057e7", label="target g / Z")
    plt.xticks(range(len(g)), ["A", "B", "C"]); plt.legend(); plt.title("Experiment 1: visits follow the fits"); plt.show()
    # TRY: change g to [1, 1, 100]. Does the walker still visit A and B? How often?


# ---------------------------------------------------------------------------------------------
# Experiment 2. Far-apart hills trap the walker.
# Two hills at -d and +d (width 0.6). The walker starts on the left hill and takes random steps
# of size 0.5. PREDICT: if you double the distance d, does the waiting time to cross double?
# ---------------------------------------------------------------------------------------------
def g_hills(x, d):
    return np.exp(-(x + d) ** 2 / (2 * 0.6 ** 2)) + np.exp(-(x - d) ** 2 / (2 * 0.6 ** 2))


def first_crossing(d, step=0.5, max_steps=300_000, seed=1):
    """Number of steps until the walker, started at -d, first reaches x > 0 (or max_steps)."""
    rng = np.random.default_rng(seed)
    x = -d
    for t in range(1, max_steps + 1):
        y = x + step * rng.standard_normal()
        # TODO (2 lines): the test, as in experiment 1, with the fit g_hills(., d); then
        #                 return t as soon as x > 0.
        raise NotImplementedError("Experiment 2: write the test and the crossing check")
    return max_steps


def experiment2():
    ds = [1.0, 1.5, 2.0, 2.5]
    waits = [first_crossing(d) for d in ds]
    for d, w in zip(ds, waits):
        print("distance d = %.1f: first crossing after %s steps" % (d, w if w < 300_000 else "> 300,000"))
    plt.semilogy(ds, waits, "o-", color="#c86400"); plt.xlabel("distance d between the hills")
    plt.ylabel("steps until the first crossing (log scale)"); plt.title("Experiment 2: the wait grows very fast"); plt.show()
    # TRY: how does the wait change with a larger step (step=1.5)? Why might large steps not help?


# ---------------------------------------------------------------------------------------------
# Experiment 3. Heat a copy: parallel tempering.
# A hot copy walks on g**(1/T) with the same step size as the walker; every 4 steps the two copies
# propose to swap places. The swap test compares the swapped pair with the current pair:
#     accept with min(1, (g(x_hot) / g(x_cold)) ** (1 - 1/T)).
# PREDICT: with T = 1 (the copy is not hotter), does swapping help at all?
# ---------------------------------------------------------------------------------------------
def tempering(T=10.0, d=3.0, steps=20_000, step=0.6, seed=2):
    rng = np.random.default_rng(seed)
    g = lambda x: g_hills(x, d)
    cold, hot, visits = -d, -d, []
    for t in range(1, steps + 1):
        for which, s, power in (("hot", step, 1 / T), ("cold", step, 1.0)):
            x = hot if which == "hot" else cold
            y = x + s * rng.standard_normal()
            if rng.random() < min(1.0, (g(y) / g(x)) ** power):
                x = y
            if which == "hot":
                hot = x
            else:
                cold = x
        if t % 4 == 0:
            # TODO (2 lines): the swap test above; if accepted, exchange cold and hot.
            raise NotImplementedError("Experiment 3: write the swap test")
        visits.append(cold)
    return np.array(visits)


def experiment3():
    xs = np.linspace(-6, 6, 400)
    for T in (1.0, 10.0):
        v = tempering(T)
        print("T = %4.1f: share of the walker's visits in the right hill = %.2f" % (T, np.mean(v > 0)))
        plt.hist(v, bins=80, density=True, alpha=0.6, label="visits, T = %g" % T)
    plt.plot(xs, g_hills(xs, 3.0) / (2 * np.sqrt(2 * np.pi) * 0.6), color="#0057e7", label="target")
    plt.legend(); plt.title("Experiment 3: a hot copy carries the walker across"); plt.show()
    # TRY: T = 2 and T = 100. Is hotter always better? (Hint: watch how often swaps are accepted.)


# ---------------------------------------------------------------------------------------------
# Experiment 4. Generate from noise: annealed Langevin dynamics.
# The "photos" are 8 small blobs on a circle; the top blob holds 44% of the photos, each other
# blob 8%. With noise sigma, the slope (score) of the blurred data is known exactly here; in a real
# image generator a network learns it.
# Langevin step:  x  <-  x + (eps / 2) * slope(x, sigma) + sqrt(eps) * noise,  eps = 0.2 * sigma**2.
# PREDICT: what goes wrong if you skip the large noise levels and start at sigma = 0.05?
# ---------------------------------------------------------------------------------------------
CENTRES = np.array([[2 * np.cos(np.pi / 2 + 2 * np.pi * k / 8), 2 * np.sin(np.pi / 2 + 2 * np.pi * k / 8)] for k in range(8)])
WEIGHTS = np.array([0.44] + [0.08] * 7)                         # blob 0 (top) is the big one


def slope(x, sigma):
    """Exact score of the 8 weighted blobs (sd 0.1) blurred by noise sigma, for points x of shape (n, 2)."""
    v = 0.01 + sigma ** 2
    diff = CENTRES[None, :, :] - x[:, None, :]                  # (n, 8, 2)
    logw = np.log(WEIGHTS)[None, :] - np.sum(diff ** 2, axis=2) / (2 * v)
    w = np.exp(logw - logw.max(axis=1, keepdims=True)); w /= w.sum(axis=1, keepdims=True)
    return np.sum(w[:, :, None] * diff, axis=1) / v


def generate(sigmas, steps=100, n=400, seed=3):
    rng = np.random.default_rng(seed)
    x = 3.0 * rng.standard_normal((n, 2))                       # pure noise
    for sigma in sigmas:
        eps = 0.2 * sigma ** 2
        for _ in range(steps):
            # TODO (1 line): one Langevin step for all points at once.
            raise NotImplementedError("Experiment 4: write the Langevin step")
    return x


def experiment4():
    schedules = {"shrink slowly (20 levels)": np.geomspace(5, 0.05, 20), "start small (sigma = 0.05 only)": [0.05] * 20}
    fig, axes = plt.subplots(1, 2, figsize=(10, 5))
    for ax, (name, sig) in zip(axes, schedules.items()):
        x = generate(sig)
        dist = np.linalg.norm(x[:, None, :] - CENTRES[None], axis=2)
        near = np.mean(dist.min(axis=1) < 0.4)
        big = np.mean(dist.argmin(axis=1) == 0)
        print("%-32s points near a blob: %3.0f%%   on the big blob: %3.0f%% (data: 44%%)" % (name, 100 * near, 100 * big))
        ax.scatter(*CENTRES.T, s=2500 * WEIGHTS, color="#cfe0ff"); ax.scatter(*x.T, s=6, color="#c86400")
        ax.set_title(name); ax.set_aspect("equal"); ax.set_xlim(-6, 6); ax.set_ylim(-6, 6)
    plt.suptitle("Experiment 4: generating from noise"); plt.show()
    # TRY: 3 levels instead of 10. Why can the small-noise walk not move points between blobs?


if __name__ == "__main__":
    {"1": experiment1, "2": experiment2, "3": experiment3, "4": experiment4}.get(
        sys.argv[1] if len(sys.argv) > 1 else "1", experiment1)()
