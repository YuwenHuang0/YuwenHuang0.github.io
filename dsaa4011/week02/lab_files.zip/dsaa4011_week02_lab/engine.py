"""Model checking and message scheduling. This part is given to you.

The scheduling here is correct and is not what the laboratory is about. What
you complete, and what the five candidate implementations get wrong, are the
two local message rules in ``starter.py``.

A model is ``(domains, local_functions, evidence)``:

``domains``
    ``domains[v]`` is the number of states of variable ``v``.
``local_functions``
    A sequence of ``(scope, table)`` pairs. **The order of ``scope`` fixes the
    order of the table axes**, so ``table.shape == tuple(domains[v] for v in
    scope)``.
``evidence``
    A mapping from variable index to observed state. Each observation is turned
    into a degree-one local function, exactly as in the lecture.
"""

from __future__ import annotations

import numpy as np


def validate(domains, local_functions, evidence):
    """Check a model and return it in canonical form.

    Raises ``ValueError`` with a specific message for every way the declared
    shapes can fail to match the declared scopes.
    """
    domains = tuple(int(d) for d in domains)
    if not domains or any(d <= 0 for d in domains):
        raise ValueError("domains must contain positive state counts")
    checked = []
    for scope, table in local_functions:
        scope = tuple(int(v) for v in scope)
        arr = np.asarray(table, dtype=float)
        if not scope or len(set(scope)) != len(scope):
            raise ValueError("each scope must contain distinct variable indices")
        if any(not 0 <= v < len(domains) for v in scope):
            raise ValueError("a scope names a variable outside the model")
        expected = tuple(domains[v] for v in scope)
        if arr.shape != expected:
            raise ValueError(
                f"table shape {arr.shape} does not match ordered scope {scope}, "
                f"which requires {expected}")
        if np.any(arr < 0) or not np.all(np.isfinite(arr)):
            raise ValueError("local-function values must be finite and nonnegative")
        checked.append((scope, arr))
    ev = {}
    for v, s in dict(evidence).items():
        v, s = int(v), int(s)
        if not 0 <= v < len(domains):
            raise ValueError("evidence names a variable outside the model")
        if not 0 <= s < domains[v]:
            raise ValueError("an observed state lies outside its domain")
        ev[v] = s
    return domains, tuple(checked), ev


def with_evidence(domains, local_functions, evidence):
    """Append one degree-one local function for each observation."""
    extra = []
    for v, s in sorted(evidence.items()):
        indicator = np.zeros(domains[v])
        indicator[s] = 1.0
        extra.append(((v,), indicator))
    return local_functions + tuple(extra)


def neighbours(domains, functions):
    """Map each variable index to the indices of the local functions reading it."""
    at_variable = {i: [] for i in range(len(domains))}
    for fi, (scope, _) in enumerate(functions):
        for v in scope:
            at_variable[v].append(fi)
    return at_variable


def check_tree(domains, functions):
    """Reject a factor graph that is disconnected or contains a cycle.

    The theorem proved in the lecture applies only to trees, so a solver that
    silently accepted a cycle would return a confidently wrong answer.
    """
    n_nodes = len(domains) + len(functions)
    n_edges = sum(len(scope) for scope, _ in functions)
    if n_edges != n_nodes - 1:
        raise ValueError(
            f"the factor graph is not a tree: {n_nodes} nodes and {n_edges} "
            f"edges, but a tree needs exactly {n_nodes - 1}")
    at_variable = neighbours(domains, functions)
    seen_v, seen_f, stack = {0}, set(), [("v", 0)]
    while stack:
        kind, idx = stack.pop()
        if kind == "v":
            for fi in at_variable[idx]:
                if fi not in seen_f:
                    seen_f.add(fi)
                    stack.append(("f", fi))
        else:
            for v in functions[idx][0]:
                if v not in seen_v:
                    seen_v.add(v)
                    stack.append(("v", v))
    if len(seen_v) != len(domains) or len(seen_f) != len(functions):
        raise ValueError("the factor graph is not connected")


def schedule(domains, functions, root):
    """Return ``(inward, outward)`` lists of directed edges in a valid order."""
    at_variable = neighbours(domains, functions)
    order, parent = [], {}
    stack = [("v", root, None)]
    visited = {("v", root)}
    while stack:
        kind, idx, par = stack.pop()
        order.append((kind, idx))
        parent[(kind, idx)] = par
        nbrs = ([("f", fi) for fi in at_variable[idx]] if kind == "v"
                else [("v", v) for v in functions[idx][0]])
        for nb in nbrs:
            if nb not in visited:
                visited.add(nb)
                stack.append((nb[0], nb[1], (kind, idx)))
    inward = [(node, parent[node]) for node in reversed(order) if parent[node]]
    outward = [(par, node) for node in order for par in [parent[node]] if par]
    return inward, outward


def run(domains, local_functions, evidence, root, factor_to_variable,
        variable_to_factor, normalize):
    """Run one inward and one outward pass with the supplied local rules.

    Every candidate implementation differs from the reference in exactly one of
    the three functions passed in here, which is what makes the defects
    diagnosable rather than merely present.
    """
    domains, functions, evidence = validate(domains, local_functions, evidence)
    functions = with_evidence(domains, functions, evidence)
    check_tree(domains, functions)
    at_variable = neighbours(domains, functions)
    messages = {}

    def send(src, dst):
        if src[0] == "v":
            i = src[1]
            others = [messages[(("f", fi), src)] for fi in at_variable[i]
                      if ("f", fi) != dst]
            messages[(src, dst)] = variable_to_factor(
                domains[i], others, arriving_from_destination=messages.get((dst, src)))
        else:
            scope, table = functions[src[1]]
            target = dst[1]
            incoming = {v: messages[(("v", v), src)] for v in scope if v != target}
            messages[(src, dst)] = factor_to_variable(scope, table, target, incoming)

    inward, outward = schedule(domains, functions, root)
    for src, dst in inward:
        send(src, dst)
    for src, dst in outward:
        send(src, dst)

    beliefs = []
    for i in range(len(domains)):
        raw = variable_to_factor(
            domains[i],
            [messages[(("f", fi), ("v", i))] for fi in at_variable[i]],
            arriving_from_destination=None)
        beliefs.append(normalize(raw))
    return beliefs
