"""The running model of the Week 2 lecture, and nothing else.

Every number in this file appears on a lecture slide. The variable names match
the slides exactly, so that ``X1`` in the deck is ``X1`` here and never an
unexplained integer.

Model
-----
Five machines share one supply unit::

    X1 --[f12]-- X2 --[f23]-- X3 --[f3]
                  |
                [f245]
                /     \\
              X4       X5

``X1`` to ``X4`` are binary alert indicators, ``0`` meaning no alert. ``X5`` is
the supply load and has three states, ``LOW``, ``NORMAL`` and ``HIGH``.

Axis-order convention
---------------------
A local function is a pair ``(scope, table)``. The **order of ``scope`` fixes
the order of the table axes**, so ``table[a, b, c]`` is the value at
``scope[0] = a``, ``scope[1] = b``, ``scope[2] = c``. Getting this wrong is the
most common defect in this laboratory, and it does not announce itself: the
result still normalizes to a valid distribution.
"""

from __future__ import annotations

import numpy as np

# Variable indices. Named so that no slide-to-code translation is ever needed.
X1, X2, X3, X4, X5 = 0, 1, 2, 3, 4

# States of the supply variable X5.
LOW, NORMAL, HIGH = 0, 1, 2

DOMAINS = (2, 2, 2, 2, 3)

# f12(x1, x2): rows indexed by x1, columns by x2.
F12 = np.array([[4.0, 1.0],
                [8.0, 5.0]])

# f23(x2, x3): rows indexed by x2, columns by x3.
F23 = np.array([[3.0, 1.0],
                [1.0, 4.0]])

# f245(x2, x4, x5): axes in that order. See the lecture slide "The supply
# table, written out in full".
F245 = np.array([[[4.0, 2.0, 1.0],      # x2 = 0, x4 = 0
                  [1.0, 1.0, 1.0]],     # x2 = 0, x4 = 1
                 [[1.0, 2.0, 3.0],      # x2 = 1, x4 = 0
                  [1.0, 4.0, 9.0]]])    # x2 = 1, x4 = 1

# f45(x4, x5): the extra local function that turns the tree into a graph with a
# cycle. Used only by the final challenge, never by the tree solver.
F45 = np.array([[5.0, 1.0, 1.0],
                [1.0, 1.0, 5.0]])

LOCAL_FUNCTIONS = (
    ((X1, X2), F12),
    ((X2, X3), F23),
    ((X2, X4, X5), F245),
)

EVIDENCE = {X3: 1}


def tree_model():
    """Return the running model as ``(domains, local_functions, evidence)``."""
    return DOMAINS, LOCAL_FUNCTIONS, dict(EVIDENCE)


def cyclic_model():
    """The same model with ``f45`` added, which creates a cycle.

    Included so that a tree solver can be asked to reject it rather than
    quietly return a wrong answer.
    """
    return DOMAINS, LOCAL_FUNCTIONS + (((X4, X5), F45),), dict(EVIDENCE)


def hard_constraint_model():
    """The variant in which the supply cannot be low while both machines alert.

    ``f245(1, 1, LOW)`` is set to zero. Observing ``X2 = 1``, ``X4 = 1`` and
    ``X5 = LOW`` together then has total weight exactly zero, which every
    implementation must report rather than divide by.
    """
    table = F245.copy()
    table[1, 1, LOW] = 0.0
    functions = (((X1, X2), F12), ((X2, X3), F23), ((X2, X4, X5), table))
    return DOMAINS, functions, dict(EVIDENCE)


def heterogeneous_model():
    """A relabelled copy in which the three-state variable is not the last one.

    The tree and the numbers are unchanged; only the variable indices move. A
    solver that assumes a particular ordering, or a binary domain, fails here
    while still passing every test on ``tree_model``.
    """
    #        old: X1 X2 X3 X4 X5          new index of each old variable
    order = {X1: 4, X2: 0, X3: 3, X4: 2, X5: 1}
    domains = [0] * 5
    for old, new in order.items():
        domains[new] = DOMAINS[old]
    functions = tuple(
        (tuple(order[v] for v in scope), table) for scope, table in LOCAL_FUNCTIONS
    )
    evidence = {order[k]: v for k, v in EVIDENCE.items()}
    return tuple(domains), functions, evidence
