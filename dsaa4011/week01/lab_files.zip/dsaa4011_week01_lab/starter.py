import numpy as np

def normalize(weights):
    """Return a normalized copy of a one-dimensional weight vector.

    Parameters
    ----------
    weights : array-like, shape (d,)
        Finite, nonnegative weights with a strictly positive sum.

    Returns
    -------
    probabilities : ndarray, shape (d,)
        Nonnegative values that sum to one.

    Raises
    ------
    ValueError
        If the input is not a vector, contains an invalid value, or has
        zero total weight.
    """
    raise NotImplementedError

def chain_marginal(f12, f23, observed_x3):
    """Return the conditional distribution of the middle machine state.

    The model weight is
        w(x1, x2, x3) = f12[x1, x2] * f23[x2, x3].

    Parameters
    ----------
    f12 : array-like, shape (d1, d2)
        ``f12[i, j]`` is the local weight for x1=i and x2=j.
    f23 : array-like, shape (d2, d3)
        ``f23[j, k]`` is the local weight for x2=j and x3=k.
    observed_x3 : int
        Observed state k of Machine 3, with 0 <= k < d3.

    Returns
    -------
    probabilities : ndarray, shape (d2,)
        ``probabilities[j]`` equals p(x2=j | x3=observed_x3).

    Raises
    ------
    ValueError
        If the factors are invalid, their x2 dimensions disagree, the
        observation is outside its domain, or the query has zero total weight.
    """
    raise NotImplementedError
