"""Optional: download/load a DINOv3 model, then extract a new image's features."""
from pathlib import Path
import argparse,json
import numpy as np
from PIL import Image

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('image');p.add_argument('--output',default='runs/own_image')
    p.add_argument('--checkpoint',help='Optional path to a previously downloaded timm-format checkpoint')
    a=p.parse_args()
    import torch,timm
    model=timm.create_model('vit_small_patch16_dinov3.lvd1689m',pretrained=not bool(a.checkpoint),num_classes=0)
    if a.checkpoint:
        from timm.models import load_checkpoint
        load_checkpoint(model,a.checkpoint)
    model.eval();torch.set_num_threads(4)
    im=Image.open(a.image).convert('RGB');scale=256/min(im.size)
    im=im.resize((round(im.width*scale),round(im.height*scale)),Image.Resampling.BICUBIC)
    x=(im.width-256)//2;y=(im.height-256)//2;im=im.crop((x,y,x+256,y+256))
    arr=np.asarray(im,dtype=np.float32)/255
    norm=(arr-np.array([.485,.456,.406],np.float32))/np.array([.229,.224,.225],np.float32)
    with torch.inference_mode():tokens=model.forward_features(torch.from_numpy(norm.transpose(2,0,1)).unsqueeze(0))
    f=tokens[0,model.num_prefix_tokens:].numpy().reshape(16,16,384)
    dest=Path(a.output);dest.mkdir(parents=True,exist_ok=True)
    im.save(dest/'image.png');np.savez_compressed(dest/'features.npz',features=f)
    print(f'Saved {dest}/image.png and features.npz; shape {f.shape}.')

if __name__=='__main__':main()
