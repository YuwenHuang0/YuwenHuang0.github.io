import unittest
import numpy as np
from lab10 import toy_image,encode,decode,mse
class CodecTests(unittest.TestCase):
 def test_toy_exact(self):
  x=toy_image();m,c=encode(x);np.testing.assert_allclose(decode(m,c),x,atol=1e-12)
 def test_information_collision(self):
  x=toy_image();m,c=encode(x);other=decode(m,-c);self.assertFalse(np.allclose(x,other));np.testing.assert_allclose(encode(other)[0],m)
 def test_mean_loss(self):
  x=toy_image();m,c=encode(x);self.assertAlmostEqual(mse(x,decode(m)),.04)
 def test_invalid_shape(self):
  with self.assertRaises(ValueError):encode(np.zeros((3,4)))
if __name__=='__main__':unittest.main()
