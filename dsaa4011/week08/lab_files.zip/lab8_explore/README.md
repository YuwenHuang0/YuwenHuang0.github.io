# DSAA 4011 Lab 8 kit: when the reward is wrong

A toy world of reward hacking. An answer has quality q and length ℓ. People want g = q + ℓ − ℓ²: a bit longer helps,
much longer hurts. A reward model r = a·q + b·ℓ is fitted to 5000 of people's picks with the Bradley–Terry model.
Best-of-n then keeps the answer with the largest r.

```
python lab8_explore.py 1     # the numbers layer: how many ratings find the best n?
python lab8_explore.py 2     # the question layer: a leash to the base model instead of best-of-n
python lab8_explore.py 3     # a new blind spot: raters who like flattery
```

Needs Python 3 with numpy and matplotlib. Every run is seeded. With `MPLBACKEND=Agg` the figures are saved as PNG files.

## Before you run

Each experiment has one line marked `TODO`. Complete it first; the program stops with a message until you do.

**Write your prediction down first.**

1. **Find the peak.** With 20 ratings per n, which n looks best? Run 5 seeds: does the answer stay the same? Then try
   `experiment1(m=500)`. How many ratings make the choice of n stable?
2. **The leash.** Instead of best-of-n, move the base model towards larger r, with a leash of strength β.
   - Which β is best for people?
   - Is the best leash better or worse than the best n?
3. **Flattery.** Raters enjoy a little flattery f; the users who live with the answers dislike it (− f²). The reward model
   now sees q, ℓ, ℓ² and f.
   - Does the raters' score keep rising with n? The users' score?
   - Which of the five layers is broken here: model, question, algorithm, numbers or evidence?

## Answers (read after you run)

1. **Find the peak.**
   - With 20 ratings the best-looking n jumps between seeds (32, 128, 1024): 2 standard errors are about 1, while the
     whole curve spans about 1.7.
   - With 500 ratings the error bar shrinks by √25 = 5, and the peak near n = 32 shows in every seed.
2. **The leash.**
   - People's score rises, then falls, as β gets smaller: β ≈ 0.5 is best (a gain of about 1.4 over the base model).
   - A small β is a long leash. It moves the whole base model far into lengths r never saw, so people's score collapses.
   - The best leash is a little worse than the best n here. Either way, the leash length must be chosen by people's
     ratings, not by r.
3. **Flattery.**
   - The raters' score keeps rising. The users' score stops rising after n ≈ 64, while flattery keeps growing.
   - The model layer is fine: r fits the picks well. The **question** layer is broken: we asked raters which answer they
     prefer now, not which answer serves users.
   - The **evidence** layer hides it too: checking with the same raters would say "better". Only the users' outcomes
     show the problem.

## Further reading

- L. Gao, J. Schulman and J. Hilton. Scaling laws for reward model overoptimization. *ICML* 2023, PMLR 202:10835–10866.
- P. Singhal, T. Goyal, J. Xu and G. Durrett. A long way to go: investigating length correlations in RLHF. *COLM* 2024.
- Y. Dubois, B. Galambosi, P. Liang and T. B. Hashimoto. Length-controlled AlpacaEval: a simple way to debias automatic
  evaluators. *COLM* 2024.
- T. Coste, U. Anwar, R. Kirk and D. Krueger. Reward model ensembles help mitigate overoptimization. *ICLR* 2024.
