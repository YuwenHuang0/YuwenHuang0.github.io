"""Two chain factor graphs for the Week 2 laboratory.

This module contains the code behind Laboratory Slides 2. Every function is
named as on the slides, and every quantity that the slides quote is printed
by ``python chains.py``. The command ``python chains.py --check`` compares
every message-passing result with brute-force enumeration, which shares no
code with the message-passing functions.

Part A. A diffusion model is a chain factor graph::

    [q_0]-- X_0 --[Q_1]-- X_1 --[Q_2]-- X_2 --[Q_3]-- X_3 --[Q_4]-- X_4

Here ``q_0`` is the data distribution of the clean picture ``X_0``, and
``Q_t`` is the transition matrix of noise step ``t``: ``Q_t[a, b]`` is the
probability that picture ``a`` becomes picture ``b``. The forward messages of
the sum-product algorithm are the marginal distributions ``q(x_t)``. The
reverse transition ``p(x_{t-1} | x_t)``, which a diffusion model learns, is a
ratio of forward messages.

Part B. A chain of reasoning steps is a chain factor graph::

    [s_1]-- Y_1 --[C_1]-- Y_2 --[C_2]-- Y_3 --[C_3]-- Y_4 --[s_4]

Here ``Y_t`` is the candidate chosen at reasoning step ``t``, ``s_t`` holds
the verifier's score of each candidate, and ``C_t`` is the consistency
factor: it is 1 when the candidate at step ``t+1`` follows from the candidate
at step ``t`` by the stated operation, and a small constant otherwise.
Greedy decoding chooses the best-scored candidate at every step; MAP
decoding (the max-product algorithm) chooses the chain of largest weight;
marginal decoding (the sum-product algorithm) computes a belief for every
step.

Terminology follows the papers cited in the docstrings: the forward process,
the reverse process, the transition matrix and the noise schedule are the
words of Sohl-Dickstein et al. (2015), Ho et al. (2020) and Austin et al.
(2021); the verifier and the step-level scores are the words of Lightman et
al. (2024).
"""

from __future__ import annotations

from itertools import product

import numpy as np

# ==========================================================================
# Section 1. The sum-product and the max-product algorithm on a chain
# ==========================================================================


def chain_messages(unary, pairwise, mode="sum"):
    """Run the forward and the backward sweep of message passing on a chain.

    Parameters
    ----------
    unary : list of L arrays
        ``unary[t]`` is the product of all degree-one local functions at the
        variable ``X_t`` (a vector of ones if there are none). Its length is
        the number of values that ``X_t`` can take.
    pairwise : list of L-1 arrays
        ``pairwise[t]`` is the table of the local function between ``X_t``
        and ``X_{t+1}``. Its rows are indexed by the value of ``X_t`` and its
        columns by the value of ``X_{t+1}``.
    mode : "sum" or "max"
        With ``"sum"`` the function computes marginals (the sum-product
        algorithm, Theorem 1 of the lecture). With ``"max"`` it computes
        max-marginals and the assignment of largest weight (the max-product
        algorithm, Theorem 2 of the lecture).

    Returns
    -------
    dict with the following entries.
        ``left[t]``: the message that arrives at ``X_t`` from the left. It is
        a vector of ones at ``t = 0``.
        ``right[t]``: the message that arrives at ``X_t`` from the right. It
        is a vector of ones at ``t = L - 1``.
        ``belief[t]``: the normalized product ``unary[t] * left[t] *
        right[t]`` (Definition 5 of the lecture).
        ``total``: the partition function ``Z`` in mode ``"sum"``, or the
        largest weight in mode ``"max"``.
        ``choice``: in mode ``"max"`` only, the assignment that attains the
        largest weight, obtained by backtracking the stored choices.
    """
    aggregate = np.sum if mode == "sum" else np.max
    L = len(unary)
    unary = [np.asarray(u, dtype=float) for u in unary]
    pairwise = [np.asarray(p, dtype=float) for p in pairwise]
    if len(pairwise) != L - 1:
        raise ValueError("a chain of L variables has L - 1 pairwise tables")

    # Forward sweep, from left to right. The variable-to-function message is
    # m_{t -> f_{t+1}} = unary[t] * left[t]; this is the variable rule (the
    # product of everything that arrives, except from the destination). The
    # function-to-variable message is m_{f_{t+1} -> t+1}(x_{t+1}) = aggregate
    # over x_t of f_{t+1}(x_t, x_{t+1}) * m_{t -> f_{t+1}}(x_t); this is the
    # function rule.
    left = [np.ones(len(unary[0]))]
    stored = []          # in mode "max": which x_t attains the maximum, per x_{t+1}
    for t in range(L - 1):
        to_function = unary[t] * left[t]
        products = pairwise[t] * to_function[:, None]   # rows x_t, columns x_{t+1}
        left.append(aggregate(products, axis=0))
        stored.append(np.argmax(products, axis=0))

    # Backward sweep, from right to left, with the same two rules mirrored.
    right = [None] * L
    right[L - 1] = np.ones(len(unary[L - 1]))
    for t in range(L - 2, -1, -1):
        to_function = unary[t + 1] * right[t + 1]
        products = pairwise[t] * to_function[None, :]
        right[t] = aggregate(products, axis=1)

    raw = [unary[t] * left[t] * right[t] for t in range(L)]
    totals = [aggregate(r) for r in raw]
    total = float(totals[0])
    belief = [r / r.sum() for r in raw]

    out = {"left": left, "right": right, "belief": belief, "total": total,
           "totals": [float(x) for x in totals]}
    if mode == "max":
        # The last variable chooses first; the stored choices are then read
        # backwards. This is the backtracking step of the lecture.
        choice = [0] * L
        choice[L - 1] = int(np.argmax(raw[L - 1]))
        for t in range(L - 2, -1, -1):
            choice[t] = int(stored[t][choice[t + 1]])
        out["choice"] = choice
    return out


def enumerate_chain(unary, pairwise, mode="sum"):
    """Compute the same quantities as ``chain_messages`` by listing every
    assignment of the chain. This is the reference against which message
    passing is checked; it shares no code with ``chain_messages``."""
    L = len(unary)
    sizes = [len(u) for u in unary]
    totals = [np.zeros(k) for k in sizes]
    best, best_assignment, total = -1.0, None, 0.0
    for assignment in product(*(range(k) for k in sizes)):
        w = 1.0
        for t in range(L):
            w *= unary[t][assignment[t]]
        for t in range(L - 1):
            w *= pairwise[t][assignment[t], assignment[t + 1]]
        total += w
        if w > best:
            best, best_assignment = w, assignment
        for t in range(L):
            totals[t][assignment[t]] += w
    if mode == "sum":
        return {"belief": [x / x.sum() for x in totals], "total": total}
    return {"total": best, "choice": list(best_assignment)}


# ==========================================================================
# Section 2. Part A: a diffusion model is a chain factor graph
# ==========================================================================

# A picture has two pixels. Each pixel is either dark (written ".") or
# bright (written "#"), so there are four pictures. Picture ``a`` is the
# integer whose bit ``k`` is the value of pixel ``k``.
PICTURES = ("..", ".#", "#.", "##")

# The data distribution q_0(x_0). Most clean pictures are all-dark or
# all-bright; the two mixed pictures are rare.
DATA_DISTRIBUTION = np.array([0.55, 0.05, 0.05, 0.35])

# The noise schedule (beta_1, ..., beta_T). At noise step t every pixel is
# flipped independently with probability beta_t.
NOISE_SCHEDULE = (0.10, 0.20, 0.30, 0.40)


def picture_names(pixels=2):
    """Return the names of the ``2 ** pixels`` pictures. Bit ``k`` of the
    picture index is the value of pixel ``k``."""
    return tuple("".join("#" if (a >> k) & 1 else "." for k in range(pixels))
                 for a in range(2 ** pixels))


def transition_matrix(beta, pixels=2):
    """Return the transition matrix ``Q`` of one noise step.

    ``Q[a, b]`` is the probability that picture ``a`` becomes picture ``b``
    when each of the ``pixels`` pixels is flipped independently with
    probability ``beta``. In the words of Austin et al. (2021), ``Q`` is the
    transition matrix of the forward process, ``q(x_t = b | x_{t-1} = a)``.
    """
    n = 2 ** pixels
    Q = np.empty((n, n))
    for a in range(n):
        for b in range(n):
            same = [((a >> k) & 1) == ((b >> k) & 1) for k in range(pixels)]
            Q[a, b] = np.prod([1 - beta if same_k else beta for same_k in same])
    return Q


def diffusion_factor_graph(data=DATA_DISTRIBUTION, schedule=NOISE_SCHEDULE,
                           observed=None, step=None, pixels=2):
    """Return the diffusion chain as ``(domains, local_functions, evidence)``,
    the convention of ``model.py``, so that ``starter.enumerate_marginals``
    can serve as the reference. ``observed`` is a picture that has been seen
    at noise step ``step`` (the last step by default)."""
    T = len(schedule)
    n = 2 ** pixels
    domains = (n,) * (T + 1)
    functions = [((0,), np.asarray(data, dtype=float))]
    for t, beta in enumerate(schedule, start=1):
        functions.append(((t - 1, t), transition_matrix(beta, pixels)))
    step = T if step is None else int(step)
    evidence = {} if observed is None else {step: int(observed)}
    return domains, tuple(functions), evidence


def forward_marginals(data=DATA_DISTRIBUTION, schedule=NOISE_SCHEDULE, pixels=2):
    """Return the list ``[q(x_0), q(x_1), ..., q(x_T)]``.

    ``q(x_t)`` is the distribution of the picture after ``t`` noise steps. On
    the chain factor graph it is exactly the message that the function node
    ``Q_t`` sends to the variable node ``X_t`` in the forward sweep, so the
    noise schedule of a diffusion model is a sequence of forward messages.
    """
    marginals = [np.asarray(data, dtype=float)]
    for beta in schedule:
        marginals.append(marginals[-1] @ transition_matrix(beta, pixels))
    return marginals


def reverse_transition(t, data=DATA_DISTRIBUTION, schedule=NOISE_SCHEDULE, pixels=2):
    """Return the exact reverse transition of noise step ``t``.

    The returned matrix ``R`` has ``R[b, a] = p(x_{t-1} = a | x_t = b)``:
    rows are indexed by the noisy picture ``x_t`` and columns by the cleaner
    picture ``x_{t-1}``, so every row sums to one. By Bayes' rule,

        p(x_{t-1} | x_t) = Q_t[x_{t-1}, x_t] * q(x_{t-1}) / q(x_t),

    that is, the transition matrix times the forward message at ``x_{t-1}``,
    divided by the forward message at ``x_t``. This is the table that the
    reverse process of a diffusion model has to represent. It is kept here as
    the reference for the version that you write yourself in the notebook.
    """
    marginals = forward_marginals(data, schedule, pixels)
    Q = transition_matrix(schedule[t - 1], pixels)
    joint = Q * marginals[t - 1][:, None]        # q(x_{t-1} = a, x_t = b)
    return (joint / joint.sum(axis=0, keepdims=True)).T


def ancestral_sample(n, rng, data=DATA_DISTRIBUTION, schedule=NOISE_SCHEDULE,
                     reverse_fn=None, pixels=2):
    """Draw ``n`` pictures by ancestral sampling of the reverse process.

    The sampler starts from ``x_T ~ q(x_T)`` and applies the reverse
    transitions of steps ``T, T-1, ..., 1`` in turn. ``reverse_fn(t)`` must
    return the reverse transition of step ``t`` as a matrix with rows indexed
    by ``x_t`` and columns by ``x_{t-1}``; by default the exact one is used.
    The function returns the array of the ``n`` sampled clean pictures.
    """
    T = len(schedule)
    marginals = forward_marginals(data, schedule, pixels)
    x = rng.choice(2 ** pixels, size=n, p=marginals[T])
    for t in range(T, 0, -1):
        if reverse_fn is not None:
            R = np.asarray(reverse_fn(t), dtype=float)
        else:
            R = reverse_transition(t, data, schedule, pixels)
        cumulative = np.cumsum(R[x], axis=1)
        u = rng.random(n)[:, None]
        x = np.minimum((u > cumulative).sum(axis=1), 2 ** pixels - 1)
    return x


def denoising_posterior(observed, data=DATA_DISTRIBUTION, schedule=NOISE_SCHEDULE,
                        step=None, pixels=2):
    """Return ``p(x_0 | x_step = observed)``, the posterior distribution of the
    clean picture given a noisy picture, computed by the two sweeps of the
    sum-product algorithm on the chain. By default the picture is observed at
    the last noise step."""
    T = len(schedule)
    n = 2 ** pixels
    step = T if step is None else int(step)
    unary = [np.asarray(data, dtype=float)] + [np.ones(n) for _ in range(T)]
    indicator = np.zeros(n)
    indicator[observed] = 1.0
    unary[step] = unary[step] * indicator
    pairwise = [transition_matrix(b, pixels) for b in schedule]
    return chain_messages(unary, pairwise)["belief"][0]


def steps_until_noise(schedule, data=DATA_DISTRIBUTION, pixels=2, tolerance=0.01):
    """Return the number of noise steps after which every entry of ``q(x_t)``
    is within ``tolerance`` of the uniform distribution, or ``None`` if this
    never happens within the schedule."""
    for t, marginal in enumerate(forward_marginals(data, schedule, pixels)):
        if np.max(np.abs(marginal - 1.0 / len(marginal))) < tolerance:
            return t
    return None


# --------------------------------------------------------------------------
# Research track of Part A: the factorized reverse transition
# --------------------------------------------------------------------------
# A denoising network for pictures with many pixels does not output the
# joint table p(x_{t-1} | x_t). It outputs one distribution per pixel of
# x_{t-1}, each conditioned on the whole noisy picture x_t, and the reverse
# transition is the product of these per-pixel distributions: a Gaussian with
# covariance sigma_t^2 I in Ho, Jain and Abbeel (2020, equation 1), and a
# product of one categorical distribution per position in Austin et al.
# (2021, section 3) and in the masked diffusion language models of Sahoo et
# al. (2024) and Nie et al. (2025). In the words of this week, the network
# learns the product of the per-pixel marginals of the exact reverse
# transition; we call this the factorized reverse transition. The functions
# below measure the error that this factorization causes on the two-pixel
# chain.


def pixel_value(a, k):
    """Return pixel ``k`` of picture ``a``: 0 for dark and 1 for bright."""
    return (a >> k) & 1


def factorized_reverse_transition(t, data=DATA_DISTRIBUTION, schedule=NOISE_SCHEDULE,
                                  pixels=2):
    """Return the factorized reverse transition of noise step ``t``.

    The returned matrix ``F`` has the same shape as ``reverse_transition(t)``.
    Row ``b`` of ``F`` is the product over the pixels ``k`` of the marginal
    distribution ``p(x_{t-1}^k | x_t = b)`` of pixel ``k`` under the exact
    reverse transition. Every row sums to one and every per-pixel marginal
    equals the exact one; only the dependence between the pixels is lost.
    """
    R = reverse_transition(t, data, schedule, pixels)
    n = 2 ** pixels
    F = np.ones((n, n))
    for b in range(n):
        for k in range(pixels):
            bright = sum(R[b, a] for a in range(n) if pixel_value(a, k) == 1)
            for a in range(n):
                F[b, a] *= bright if pixel_value(a, k) == 1 else 1.0 - bright
    return F


def pairwise_correction(data=DATA_DISTRIBUTION, pixels=2):
    """Return the vector ``phi`` with ``phi[x] = q_0(x) / prod_k q_0(x^k)``,
    the ratio of the data distribution to the product of its per-pixel
    marginals. It measures how strongly the data couple the pixels beyond
    their marginals, and it equals one everywhere when the pixels are
    independent under the data distribution."""
    n = 2 ** pixels
    data = np.asarray(data, dtype=float)
    marginal = [np.array([data[[a for a in range(n) if pixel_value(a, k) == v]].sum()
                          for v in (0, 1)]) for k in range(pixels)]
    return np.array([data[a] / np.prod([marginal[k][pixel_value(a, k)] for k in range(pixels)])
                     for a in range(n)])


def normalize_rows(table):
    """Divide every row of ``table`` by its sum."""
    table = np.asarray(table, dtype=float)
    return table / table.sum(axis=1, keepdims=True)


def sampling_error(schedule=NOISE_SCHEDULE, reverse_fn=None, data=DATA_DISTRIBUTION,
                   pixels=2, n=100_000, seed=0):
    """Draw ``n`` pictures with ``ancestral_sample`` and compare them with the
    data distribution. Returns ``(frequencies, error)``, where ``error`` is the
    maximum absolute difference between the empirical frequencies and the data
    distribution."""
    rng = np.random.default_rng(seed)
    x = ancestral_sample(n, rng, data=data, schedule=schedule, reverse_fn=reverse_fn,
                         pixels=pixels)
    frequencies = np.bincount(x, minlength=2 ** pixels) / n
    return frequencies, float(np.max(np.abs(frequencies - np.asarray(data, dtype=float))))


def factorization_error(t, data=DATA_DISTRIBUTION, schedule=NOISE_SCHEDULE, pixels=2):
    """Return the maximum absolute difference between the exact and the
    factorized reverse transition of noise step ``t``. This is the right
    measure of "nearly equal": a ratio of two very small entries can be large
    while the two tables agree to three decimal places."""
    R = reverse_transition(t, data, schedule, pixels)
    F = factorized_reverse_transition(t, data, schedule, pixels)
    return float(np.max(np.abs(R - F)))


def factorization_ratio_range(t, data=DATA_DISTRIBUTION, schedule=NOISE_SCHEDULE, pixels=2):
    """Return the smallest and the largest entry of the entrywise ratio
    (exact reverse transition) / (factorized reverse transition) at noise
    step ``t``. The range says how strong a correction between the pixels
    that step would need."""
    ratio = (reverse_transition(t, data, schedule, pixels)
             / factorized_reverse_transition(t, data, schedule, pixels))
    return float(ratio.min()), float(ratio.max())


def equal_step_schedule(k, schedule=NOISE_SCHEDULE):
    """Return a schedule of ``k`` equal flip probabilities with the same total
    amount of noise as ``schedule``. The total amount of noise is measured by
    the product of ``1 - 2 * beta_t`` over the steps, which is preserved."""
    total = float(np.prod([1.0 - 2.0 * b for b in schedule]))
    return (0.5 * (1.0 - total ** (1.0 / k)),) * k


# ==========================================================================
# Section 3. Part B: a chain of reasoning steps is a chain factor graph
# ==========================================================================

# The word problems are about a shop that sells, receives and doubles its
# stock of apples. An operation is a pair (name, amount).
OPERATIONS = (("sells", -1), ("receives", +1), ("doubles", 0))


def apply_operation(operation, value):
    """Apply one operation to the current number of apples."""
    name, amount = operation
    if name == "doubles":
        return 2 * value
    if name == "receives":
        return value + amount
    return value - amount


def problem_text(start, operations):
    """Return the word problem as one English paragraph."""
    parts = [f"A shop starts with {start} apples."]
    for name, amount in operations:
        if name == "sells":
            parts.append(f"It sells {amount}.")
        elif name == "receives":
            parts.append(f"It receives {amount} more.")
        else:
            parts.append("A delivery doubles the stock.")
    parts.append("How many apples are there now?")
    return " ".join(parts)


def build_problem(start, operations, candidates, scores, truth, eps=0.05,
                  misspecification=0):
    """Assemble the unary and the pairwise tables of a reasoning chain.

    Parameters
    ----------
    start : int
        The number of apples at the beginning.
    operations : list of L pairs (name, amount)
        The operation of every step.
    candidates : list of L lists
        ``candidates[t]`` holds the candidate values proposed for step ``t``.
    scores : array of shape (L, K)
        ``scores[t, k]`` is the verifier's score of candidate ``k`` at step
        ``t``, a number in (0, 1).
    truth : list of L indices
        The index of the correct candidate at every step.
    eps : float
        The value of the consistency factor for a candidate that does not
        follow from the previous one. With ``eps = 1`` the consistency factors
        carry no information.
    misspecification : int
        Shifts the rule that the consistency factors encode by this many
        apples. With a nonzero value the factor graph describes a slightly
        different problem from the one that was posed: a misspecified model.

    Returns
    -------
    dict with the tables ``unary`` (the verifier's scores) and ``pairwise``
    (the consistency factors) and with the data of the problem.
    """
    L = len(candidates)
    unary = [np.asarray(scores[t], dtype=float).copy() for t in range(L)]
    pairwise = []
    for t in range(L - 1):
        C = np.full((len(candidates[t]), len(candidates[t + 1])), eps)
        for j, cj in enumerate(candidates[t]):
            for k, ck in enumerate(candidates[t + 1]):
                if apply_operation(operations[t + 1], cj) + misspecification == ck:
                    C[j, k] = 1.0
        pairwise.append(C)
    return {"start": start, "operations": operations, "candidates": candidates,
            "scores": np.asarray(scores, dtype=float), "truth": list(truth),
            "unary": unary, "pairwise": pairwise,
            "question": problem_text(start, operations)}


def example_problem():
    """Return the example of the laboratory slides: four steps, three
    candidates per step, and verifier scores chosen by hand so that greedy
    decoding and MAP decoding disagree."""
    start = 20
    operations = [("sells", 7), ("doubles", 0), ("sells", 5), ("receives", 4)]
    candidates = [[13, 14, 12], [26, 28, 24], [21, 23, 19], [25, 27, 23]]
    scores = np.array([[0.70, 0.50, 0.20],
                       [0.45, 0.50, 0.30],
                       [0.65, 0.40, 0.20],
                       [0.40, 0.50, 0.10]])
    return build_problem(start, operations, candidates, scores, truth=[0, 0, 0, 0])


def random_problem(rng, L=4, K=3, verifier_accuracy=0.65, eps=0.05,
                   chain_distractors=0.7, misspecification=0):
    """Return a random word problem with a hidden correct chain and a noisy
    verifier.

    ``verifier_accuracy`` is the mean score that the verifier gives to a
    correct candidate; a wrong candidate receives the mean score
    ``1 - verifier_accuracy``. Scores are drawn from Beta distributions with
    these means. With probability ``chain_distractors`` a wrong candidate at
    step ``t + 1`` is the correct continuation of a wrong candidate at step
    ``t``, so that a wrong chain can be internally consistent; otherwise the
    wrong candidate follows from nothing. ``misspecification`` is passed to
    ``build_problem``.
    """
    start = int(rng.integers(10, 40))
    operations = []
    for _ in range(L):
        name = OPERATIONS[rng.integers(0, 3)][0]
        amount = int(rng.integers(2, 9)) if name != "doubles" else 0
        operations.append((name, amount))
    values, v = [], start
    for operation in operations:
        v = apply_operation(operation, v)
        values.append(v)
    candidates, truth = [], []
    for t in range(L):
        cands = [values[t]]
        # Wrong candidates that continue the wrong candidates of the previous step.
        pool = []
        if t > 0:
            pool = [apply_operation(operations[t], c)
                    for k, c in enumerate(candidates[t - 1]) if k != truth[t - 1]]
            rng.shuffle(pool)
        while len(cands) < K:
            c = None
            if pool and rng.random() < chain_distractors:
                c = pool.pop()
            if c is None or c in cands:
                c = values[t] + int(rng.choice([-3, -2, -1, 1, 2, 3]))
            if c not in cands:
                cands.append(c)
        order = rng.permutation(K)
        cands = [cands[i] for i in order]
        candidates.append(cands)
        truth.append(int(np.where(order == 0)[0][0]))
    concentration = 6.0
    scores = np.empty((L, K))
    for t in range(L):
        for k in range(K):
            mean = verifier_accuracy if k == truth[t] else 1 - verifier_accuracy
            scores[t, k] = rng.beta(mean * concentration, (1 - mean) * concentration)
    problem = build_problem(start, operations, candidates, scores, truth, eps=eps,
                            misspecification=misspecification)
    problem["values"] = values
    return problem


def greedy_decoding(problem):
    """Return the chain obtained by choosing, at every step, the candidate
    with the largest verifier score. This is how a chain of thought is
    usually read: one step at a time."""
    return [int(np.argmax(s)) for s in problem["scores"]]


def map_decoding(problem):
    """Return the result of the max-product algorithm on the chain: the chain
    of largest weight (the maximum a posteriori chain), with the stored
    choices. On a chain the max-product algorithm is the Viterbi algorithm."""
    return chain_messages(problem["unary"], problem["pairwise"], mode="max")


def marginal_decoding(problem):
    """Return the result of the sum-product algorithm on the chain: a belief
    for every step, and the partition function."""
    return chain_messages(problem["unary"], problem["pairwise"], mode="sum")


def final_step_confidence(problem, chain):
    """Return the confidence in the final answer of ``chain`` when the final
    step is read on its own: its verifier score divided by the sum of the
    scores of the final step."""
    s = problem["scores"][-1]
    return float(s[chain[-1]] / s.sum())


def run_experiment(n=2000, verifier_accuracy=0.65, seed=0, eps=0.05,
                   misspecification=0, L=4, K=3):
    """Compare greedy, MAP and marginal decoding on ``n`` random problems.

    Returns a dict with ``accuracy`` (the fraction of problems on which each
    decoding rule finds the correct final answer, and the fraction on which
    greedy and MAP decoding find the whole correct chain), ``calibration``
    (how often a stated confidence was right), ``n`` and ``verifier``.
    """
    rng = np.random.default_rng(seed)
    hits = {"greedy final": 0, "greedy chain": 0, "MAP final": 0,
            "MAP chain": 0, "marginal final": 0}
    conf_greedy, conf_marginal, right_greedy, right_marginal = [], [], [], []
    for _ in range(n):
        p = random_problem(rng, L=L, K=K, verifier_accuracy=verifier_accuracy,
                           eps=eps, misspecification=misspecification)
        truth = p["truth"]
        g = greedy_decoding(p)
        m = map_decoding(p)["choice"]
        b = marginal_decoding(p)["belief"]
        s = [int(np.argmax(x)) for x in b]
        hits["greedy final"] += g[-1] == truth[-1]
        hits["greedy chain"] += g == truth
        hits["MAP final"] += m[-1] == truth[-1]
        hits["MAP chain"] += m == truth
        hits["marginal final"] += s[-1] == truth[-1]
        conf_greedy.append(final_step_confidence(p, g))
        right_greedy.append(g[-1] == truth[-1])
        conf_marginal.append(float(b[-1][s[-1]]))
        right_marginal.append(s[-1] == truth[-1])
    accuracy = {k: v / n for k, v in hits.items()}
    calib = {"greedy": calibration(conf_greedy, right_greedy),
             "marginal": calibration(conf_marginal, right_marginal)}
    return {"accuracy": accuracy, "calibration": calib, "n": n,
            "verifier": verifier_accuracy}


def calibration(confidence, right, edges=(0.0, 0.5, 0.7, 0.9, 1.0001)):
    """Return rows ``(low, high, fraction right, count)``: for the answers
    whose stated confidence lies in ``[low, high)``, the fraction that were
    right and how many there were."""
    confidence, right = np.asarray(confidence), np.asarray(right, dtype=float)
    rows = []
    for lo, hi in zip(edges[:-1], edges[1:]):
        mask = (confidence >= lo) & (confidence < hi)
        if mask.any():
            rows.append((lo, min(hi, 1.0), float(right[mask].mean()), int(mask.sum())))
    return rows


def sweep(values=(0.55, 0.65, 0.75, 0.85, 0.95), parameter="verifier_accuracy",
          n=1000, seed=1, **fixed):
    """Vary one parameter of ``run_experiment`` and record the accuracy of
    greedy and MAP decoding.

    ``parameter`` is one of ``"verifier_accuracy"``, ``"L"``, ``"K"``,
    ``"eps"`` and ``"misspecification"``; the other parameters keep their
    default values unless given in ``fixed``. Returns one row ``(value,
    greedy final-answer accuracy, MAP final-answer accuracy, gain of MAP over
    greedy)`` per value.
    """
    rows = []
    for v in values:
        kw = dict(fixed)
        kw[parameter] = v
        r = run_experiment(n=n, seed=seed, **kw)["accuracy"]
        rows.append((v, r["greedy final"], r["MAP final"],
                     r["MAP final"] - r["greedy final"]))
    return rows


# --------------------------------------------------------------------------
# Research track of Part B: the decoding order
# --------------------------------------------------------------------------
# A masked diffusion language model generates a sequence by unmasking its
# positions in some order; each position is drawn from a predictive
# distribution given the positions that are already unmasked. Ni et al.
# (2026) report that unmasking the most confident position first skips the
# positions of high uncertainty and reduces the number of distinct solutions
# that are found. On a chain both parts of that claim can be tested exactly.
# With the exact conditional distribution (the sum-product algorithm with the
# unmasked positions clamped) every order samples the same joint
# distribution. With an approximate conditional distribution the order
# matters.


def order_conditional(problem, revealed, i, kind="exact", gamma=1.0):
    """Return the predictive distribution of step ``i`` given the steps in
    ``revealed`` (a dict from step index to chosen candidate index).

    With ``kind="exact"`` the distribution is the belief at step ``i`` of the
    sum-product algorithm with the revealed steps clamped to their values.
    With ``kind="factorized"`` it is the verifier's score times the
    consistency factors with the revealed neighbours only; no message passes
    through a masked step. This is what a predictor that outputs one
    distribution per position sees. ``gamma`` raises the distribution to a
    power and renormalizes; ``gamma > 1`` models an over-confident predictor.
    """
    unary, pairwise = problem["unary"], problem["pairwise"]
    if kind == "exact":
        u = [x.copy() for x in unary]
        for j, v in revealed.items():
            keep = np.zeros_like(u[j])
            keep[v] = 1.0
            u[j] = u[j] * keep
        p = chain_messages(u, pairwise)["belief"][i]
    else:
        p = unary[i].copy()
        if i - 1 in revealed:
            p = p * pairwise[i - 1][revealed[i - 1], :]
        if i + 1 in revealed:
            p = p * pairwise[i][:, revealed[i + 1]]
        p = p / p.sum()
    p = p ** gamma
    return p / p.sum()


def next_position(problem, revealed, order, kind, gamma):
    """Return the next step to reveal under ``order``: the leftmost masked
    step for ``"left"``, or the masked step whose predictive distribution has
    the largest maximum for ``"confidence"``."""
    L = len(problem["unary"])
    masked = [i for i in range(L) if i not in revealed]
    if order == "left":
        return min(masked), None
    conditionals = {i: order_conditional(problem, revealed, i, kind, gamma) for i in masked}
    return max(masked, key=lambda j: conditionals[j].max()), conditionals


def decode_in_order(problem, rng, order="left", kind="exact", gamma=1.0):
    """Reveal the steps one at a time in the given order (``"left"`` or
    ``"confidence"``). Returns the sampled chain and the rank (0 for first)
    at which the fork was decided; the fork is the step whose exact belief
    has the largest entropy."""
    L = len(problem["unary"])
    exact = marginal_decoding(problem)["belief"]
    fork = int(np.argmax([-(b * np.log(b + 1e-12)).sum() for b in exact]))
    revealed, fork_rank = {}, None
    for rank in range(L):
        i, _ = next_position(problem, revealed, order, kind, gamma)
        p = order_conditional(problem, revealed, i, kind, gamma)
        if i == fork:
            fork_rank = rank
        revealed[i] = int(rng.choice(len(p), p=p))
    return [revealed[i] for i in range(L)], fork_rank


def joint_under_order(problem, order="left", kind="exact", gamma=1.0):
    """Return the probability of every chain under a reveal order, computed
    exactly by enumerating every sequence of reveal outcomes. With
    ``kind="exact"`` the result equals the true joint distribution of the
    chain for every order; with ``kind="factorized"`` it does not."""
    L = len(problem["unary"])
    K = len(problem["unary"][0])
    probabilities = {}

    def recurse(revealed, prob):
        if len(revealed) == L:
            key = tuple(revealed[i] for i in range(L))
            probabilities[key] = probabilities.get(key, 0.0) + prob
            return
        i, _ = next_position(problem, revealed, order, kind, gamma)
        p = order_conditional(problem, revealed, i, kind, gamma)
        for v in range(K):
            if p[v] > 0:
                r = dict(revealed)
                r[i] = v
                recurse(r, prob * p[v])

    recurse({}, 1.0)
    return probabilities


def order_experiment(n=200, verifier_accuracy=0.65, kind="factorized", gamma=1.0,
                     k=8, seed=0, chain_distractors=0.7):
    """Compare left-to-right decoding with confidence-first decoding on ``n``
    random problems, using the exact distribution over chains of each order.

    For each order the function reports the accuracy of the final answer
    (pass@1), the probability that the correct chain is among ``k``
    independent samples (pass@k), the entropy of the distribution of the
    final answer, and the mean rank at which the fork is decided.
    """
    rng = np.random.default_rng(seed)
    problems = [random_problem(rng, verifier_accuracy=verifier_accuracy,
                               chain_distractors=chain_distractors)
                for _ in range(n)]
    out = {}
    for order in ("left", "confidence"):
        pass1 = passk = 0.0
        entropies, ranks = [], []
        for p in problems:
            joint = joint_under_order(p, order, kind, gamma)
            truth = tuple(p["truth"])
            passk += 1.0 - (1.0 - joint.get(truth, 0.0)) ** k
            finals = np.zeros(len(p["unary"][-1]))
            for chain, pr in joint.items():
                finals[chain[-1]] += pr
            pass1 += finals[truth[-1]]
            entropies.append(-(finals * np.log(finals + 1e-12)).sum())
            ranks.append(decode_in_order(p, rng, order, kind, gamma)[1])
        out[order] = {"pass@1": pass1 / n, f"pass@{k}": passk / n,
                      "final-answer entropy": float(np.mean(entropies)),
                      "fork decided at rank": float(np.mean(ranks))}
    return out


# ==========================================================================
# Section 4. Printing helpers used by the notebook
# ==========================================================================


def show_vector(v, labels=None, digits=4):
    """Return a one-line string ``label: value`` for every entry of ``v``."""
    labels = labels or [str(i) for i in range(len(v))]
    return "  ".join(f"{lab}: {x:.{digits}f}" for lab, x in zip(labels, v))


def show_lattice(problem, chosen=None, mark="*"):
    """Return the candidates of every step with their verifier scores, one
    line per step. The candidates of a chosen chain are marked."""
    lines = []
    for t, (cands, sc) in enumerate(zip(problem["candidates"], problem["scores"])):
        cells = []
        for k, (c, s) in enumerate(zip(cands, sc)):
            flag = mark if chosen is not None and chosen[t] == k else " "
            cells.append(f"{flag}{c:>4} ({s:.2f})")
        lines.append(f"step {t + 1}: " + "   ".join(cells))
    return "\n".join(lines)


def chain_values(problem, chain):
    """Return the candidate values of a chain of candidate indices."""
    return [problem["candidates"][t][k] for t, k in enumerate(chain)]


# ==========================================================================
# Section 5. Self-check: message passing against enumeration
# ==========================================================================


def check(verbose=True):
    """Compare every message-passing result with brute-force enumeration."""
    rng = np.random.default_rng(2026)
    # Part A: the denoising posterior against the enumeration of 4^4 completions.
    import starter  # the laboratory's own enumerate_marginals, already written
    for observed in range(4):
        for step in (2, 4):
            d, lf, ev = diffusion_factor_graph(observed=observed, step=step)
            reference = starter.enumerate_marginals(d, lf, ev)[0]
            got = denoising_posterior(observed, step=step)
            assert np.allclose(reference, got), ("posterior", observed, step, reference, got)
    data3 = np.array([0.4, 0.05, 0.05, 0.1, 0.05, 0.1, 0.05, 0.2])
    d, lf, ev = diffusion_factor_graph(data=data3, schedule=(0.2, 0.3), observed=5, pixels=3)
    reference = starter.enumerate_marginals(d, lf, ev)[0]
    got = denoising_posterior(5, data=data3, schedule=(0.2, 0.3), pixels=3)
    assert np.allclose(reference, got), ("posterior, three pixels", reference, got)
    # The factorized reverse transition has normalized rows and, with one
    # pixel, equals the exact reverse transition.
    for t in (1, 2, 3, 4):
        F = factorized_reverse_transition(t)
        assert np.allclose(F.sum(axis=1), 1.0)
    one = np.array([0.7, 0.3])
    assert np.allclose(factorized_reverse_transition(1, one, (0.2,), pixels=1),
                       reverse_transition(1, one, (0.2,), pixels=1))
    assert np.allclose(pairwise_correction(np.array([0.25, 0.25, 0.25, 0.25])), 1.0)
    # Ancestral sampling with the exact reverse transitions recovers the data
    # distribution.
    x = ancestral_sample(200_000, rng)
    frequencies = np.bincount(x, minlength=4) / len(x)
    assert np.max(np.abs(frequencies - DATA_DISTRIBUTION)) < 0.01, frequencies
    # Part B: beliefs and the MAP chain against enumeration on random problems.
    for _ in range(50):
        p = random_problem(rng, verifier_accuracy=float(rng.uniform(0.5, 0.95)))
        sp, mp = marginal_decoding(p), map_decoding(p)
        e_sum = enumerate_chain(p["unary"], p["pairwise"], "sum")
        e_max = enumerate_chain(p["unary"], p["pairwise"], "max")
        for a, b in zip(sp["belief"], e_sum["belief"]):
            assert np.allclose(a, b), (a, b)
        assert np.isclose(sp["total"], e_sum["total"])
        assert np.isclose(mp["total"], e_max["total"])
        assert mp["choice"] == e_max["choice"], (mp["choice"], e_max["choice"])
    # Decoding order: with exact conditionals every order gives the true joint.
    for _ in range(5):
        p = random_problem(rng, verifier_accuracy=0.6)
        Z = enumerate_chain(p["unary"], p["pairwise"], "sum")["total"]
        for order in ("left", "confidence"):
            joint = joint_under_order(p, order, "exact")
            for chain, pr in joint.items():
                w = np.prod([p["unary"][t][chain[t]] for t in range(4)])
                w *= np.prod([p["pairwise"][t][chain[t], chain[t + 1]] for t in range(3)])
                assert np.isclose(pr, w / Z), (order, chain, pr, w / Z)
    if verbose:
        print("chains.py: every message-passing result agrees with enumeration "
              "on both chains.")
    return True


if __name__ == "__main__":
    import sys

    if "--check" in sys.argv:
        check()
    else:
        print("Part A. The forward marginals q(x_t), which are the forward messages:")
        for t, q in enumerate(forward_marginals()):
            print(f"  q(x_{t}):", show_vector(q, PICTURES))
        rng = np.random.default_rng(0)
        x = ancestral_sample(5000, rng)
        print("  5000 pictures sampled with the exact reverse transitions:",
              show_vector(np.bincount(x, minlength=4) / 5000, PICTURES, 3))

        def without_forward_message(t):
            Q = transition_matrix(NOISE_SCHEDULE[t - 1])
            return (Q / Q.sum(axis=0, keepdims=True)).T

        x = ancestral_sample(5000, rng, reverse_fn=without_forward_message)
        print("  5000 pictures sampled without the forward message q(x_{t-1}):",
              show_vector(np.bincount(x, minlength=4) / 5000, PICTURES, 3))
        print("Part A, research track. The factorized reverse transition:")
        for t in range(1, 5):
            lo, hi = factorization_ratio_range(t)
            print(f"  step {t}: the ratio exact / factorized ranges from {lo:.2f} to {hi:.2f};"
                  f" the maximum absolute difference is {factorization_error(t):.3f}")
        print(f"  with every beta = 0.02, the maximum absolute difference at step 1 is "
              f"{factorization_error(1, schedule=(0.02,) * 4):.3f}")
        phi = pairwise_correction()
        print("  pairwise correction phi:", show_vector(phi, PICTURES, 2))
        print("  100000 pictures sampled with each reverse transition; error = maximum "
              "absolute difference from the data distribution:")
        for name, fn in (("exact", None),
                         ("factorized", lambda t: factorized_reverse_transition(t)),
                         ("factorized, phi at the last step only",
                          lambda t: normalize_rows(factorized_reverse_transition(t) * phi[None, :])
                          if t == 1 else factorized_reverse_transition(t)),
                         ("factorized, phi^0.25 at every step",
                          lambda t: normalize_rows(factorized_reverse_transition(t) * (phi ** 0.25)[None, :])),
                         ("factorized, phi at every step",
                          lambda t: normalize_rows(factorized_reverse_transition(t) * phi[None, :]))):
            f, err = sampling_error(reverse_fn=fn)
            print(f"    {name:<40} {np.round(f, 3)}  error {err:.3f}")
        for k in (4, 8, 16, 32, 64):
            schedule = equal_step_schedule(k)
            f, err = sampling_error(schedule=schedule,
                                    reverse_fn=lambda t, s=schedule: factorized_reverse_transition(t, schedule=s))
            print(f"    factorized, {k:>2} equal steps of the same total noise: error {err:.3f}")
        print("Part B. The example problem:")
        p = example_problem()
        print("  " + p["question"])
        print(show_lattice(p, greedy_decoding(p)))
        m = map_decoding(p)
        print("  greedy decoding:  ", chain_values(p, greedy_decoding(p)))
        print("  MAP decoding:     ", chain_values(p, m["choice"]), f"(weight {m['total']:.4f})")
        b = marginal_decoding(p)
        print("  belief at step 4: ", show_vector(b["belief"][-1], p["candidates"][-1]),
              f"(partition function Z = {b['total']:.4f})")
        r = run_experiment()
        print("Part B. 2000 random problems with verifier accuracy 0.65; fraction correct:")
        for k, v in r["accuracy"].items():
            print(f"  {k:<16} {v:.3f}")
        for name, rows in r["calibration"].items():
            print(f"  calibration of {name} decoding:")
            for lo, hi, acc, cnt in rows:
                print(f"    stated confidence {lo:.1f} to {hi:.1f}: correct {acc:.2f} of the time ({cnt} problems)")
        print("Part B. Sweep over the verifier accuracy (greedy, MAP, gain of MAP over greedy):")
        for a, g, mm, gain in sweep():
            print(f"  {a:.2f}: {g:.3f}  {mm:.3f}  {gain:+.3f}")
        w = run_experiment(misspecification=1)["accuracy"]
        print("Part B. A misspecified model: the consistency factors encode a rule that is "
              "off by one apple.")
        print(f"  greedy final {w['greedy final']:.3f}, MAP final {w['MAP final']:.3f}")
        print("Part B, research track. Decoding order with the factorized conditional:")
        for gamma in (1.0, 3.0):
            res = order_experiment(n=300, kind="factorized", gamma=gamma)
            for order, mm in res.items():
                print(f"  gamma {gamma:.0f}, {order:<11}",
                      "  ".join(f"{k} {v:.2f}" for k, v in mm.items()))
        res = order_experiment(n=300, kind="exact")
        for order, mm in res.items():
            print(f"  exact,   {order:<11}", "  ".join(f"{k} {v:.2f}" for k, v in mm.items()))
