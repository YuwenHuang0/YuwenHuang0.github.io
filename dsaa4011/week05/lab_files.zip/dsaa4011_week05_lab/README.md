# DSAA 4011 Lab 5 · Explore after class

Five small experiments with expectation–maximization (EM) from Lecture 5: guess the hidden labels softly (E-step), count with them (M-step), and repeat. They match the slides of Lab 5; experiments 4 and 5 are Programs 4 and 5 (Troubles 4 and 5).

| Run | Experiment | You write | First predict |
|---|---|---|---|
| `python lab5_explore.py 1` | Two coins: EM rounds | the soft label (1 line) | Starting from (0.6, 0.6), where does EM go, and why? |
| `python lab5_explore.py 2` | Crowd labelling: whom to trust? | the M-step (1 line) | Person 3 disagrees on 3 photos. What accuracy will EM give them? |
| `python lab5_explore.py 3` | k-means cells for search | the nearest-centre step (1 line) | With more cells, how much faster is search, and how often is the nearest text missed? |
| `python lab5_explore.py 4` | Program 4: a word cutter | the share of each cut (1 line) | With all pieces equal, which cut of “noon” wins? |
| `python lab5_explore.py 5` | Program 5: a tiny reasoner | keep, then retrain (2 lines) | Keeping only right answers, how fast does careful reasoning grow? |

Each section ends with a **TRY** line: one more change to explore.

Setup: Python 3 with `numpy` and `matplotlib`. Every run is seeded, so you and your neighbour see the same numbers. Until you fill in a TODO, that experiment stops with a short message telling you what to write.
