"""Week 2 starter: the two local message rules, and the operations around them.

Complete the three functions marked ``TODO``. Everything else is given.

Names here match the lecture slides exactly:

===========================  ==================================================
slide                        code
===========================  ==================================================
``m_{f -> i}``               ``factor_to_variable(scope, table, target, incoming)``
``m_{i -> f}``               ``variable_to_factor(domain_size, incoming)``
unnormalized belief          the product returned by ``variable_to_factor``
normalized belief            ``normalize(...)`` of that product
===========================  ==================================================

Axis-order convention, which the whole week depends on: a local function is a
pair ``(scope, table)`` and **the order of ``scope`` fixes the order of the
table axes**. If ``scope == (X2, X4, X5)`` then ``table[a, b, c]`` is the value
at ``x2 = a``, ``x4 = b``, ``x5 = c``.
"""

from __future__ import annotations

from itertools import product

import numpy as np

import engine


# --------------------------------------------------------------------------
# Given. Do not change these two; the public tests pin their behaviour.
# --------------------------------------------------------------------------
def factor_message(factor, incoming):
    """Degree-two warm-up, matching the hand calculation on the slides.

    ``factor`` has shape ``(d_i, d_j)``, rows indexed by the sending variable
    and columns by the receiving variable; ``incoming`` has length ``d_i``; the
    result has length ``d_j``.

    >>> factor_message([[1, 2], [3, 4]], [2, 1])
    array([5., 8.])
    """
    f = np.asarray(factor, dtype=float)
    m = np.asarray(incoming, dtype=float)
    if f.ndim != 2:
        raise ValueError("factor must be two-dimensional")
    if m.shape != (f.shape[0],):
        raise ValueError(f"incoming has shape {m.shape}, expected {(f.shape[0],)}")
    return m @ f


def variable_belief(left, right):
    """Multiply two equal-length non-negative vectors and normalize."""
    a = np.asarray(left, dtype=float)
    b = np.asarray(right, dtype=float)
    if a.shape != b.shape:
        raise ValueError(f"shapes {a.shape} and {b.shape} do not match")
    return normalize(a * b)


def enumerate_marginals(domains, local_functions, evidence):
    """Exact marginals by summing over every complete assignment.

    Given, because it is your reference and must not be the thing under test.
    On the Week 2 model this visits 48 assignments.
    """
    domains, functions, evidence = engine.validate(domains, local_functions, evidence)
    functions = engine.with_evidence(domains, functions, evidence)
    totals = [np.zeros(d) for d in domains]
    partition = 0.0
    for assignment in product(*(range(d) for d in domains)):
        weight = 1.0
        for scope, table in functions:
            weight *= table[tuple(assignment[v] for v in scope)]
        if weight == 0.0:
            continue
        partition += weight
        for i, s in enumerate(assignment):
            totals[i][s] += weight
    if partition <= 0:
        raise ValueError("total weight is zero: the observation is impossible "
                         "under this model")
    return [t / partition for t in totals]


# --------------------------------------------------------------------------
# TODO 1
# --------------------------------------------------------------------------
def normalize(weights):
    """Scale a finite, non-negative vector so that its entries sum to one.

    Parameters
    ----------
    weights : one-dimensional array of non-negative finite numbers

    Returns
    -------
    ndarray
        The same length, summing to one.

    Raises
    ------
    ValueError
        If the vector is empty, negative, not finite, or has **zero total
        weight**. Zero total weight means the evidence is impossible under the
        model. It must be reported, never divided by, and never quietly
        returned as ``nan``.
    """
    raise NotImplementedError("TODO 1: complete normalize")


# --------------------------------------------------------------------------
# TODO 2
# --------------------------------------------------------------------------
def factor_to_variable(scope, table, target, incoming):
    """Message from a local function to one of the variables it reads.

    On the slides::

        m_{f->i}(x_i) = sum over the other variables of f  of
                        f(x_scope) * product of m_{j->f}(x_j) for j != i

    Parameters
    ----------
    scope : tuple of int
        Ordered variable indices. ``scope[k]`` labels axis ``k`` of ``table``.
    table : ndarray
        Shape ``tuple(domains[v] for v in scope)``.
    target : int
        The receiving variable. Must appear in ``scope``.
    incoming : mapping
        ``incoming[v]`` is the message arriving from variable ``v``, for every
        ``v`` in ``scope`` except ``target``.

    Returns
    -------
    ndarray
        Length equal to the domain size of ``target``. Not the size of the
        table, and not the size of the sender: on the Week 2 model the same
        12-entry table sends 2 numbers to ``X4`` and 3 numbers to ``X5``.

    Notes
    -----
    Multiply each incoming message into the correct axis before summing. A
    message of length ``d`` must be reshaped so that its ``d`` sits on the axis
    belonging to its own variable; broadcasting it onto the wrong axis is one
    of the defects you will be asked to diagnose.
    """
    raise NotImplementedError("TODO 2: complete factor_to_variable")


# --------------------------------------------------------------------------
# TODO 3
# --------------------------------------------------------------------------
def variable_to_factor(domain_size, incoming, arriving_from_destination=None):
    """Message from a variable to one of its local functions.

    On the slides::

        m_{i->f}(x_i) = product of m_{h->i}(x_i) over h in N(i) \\ {f}

    Parameters
    ----------
    domain_size : int
        Number of states of the sending variable, which is also the length of
        the result.
    incoming : sequence of arrays
        The messages arriving from the variable's **other** neighbours. The
        caller has already excluded the destination.
    arriving_from_destination : array or None
        Supplied only so that a defective implementation can be written that
        wrongly uses it. A correct implementation ignores this argument.

    Returns
    -------
    ndarray
        Length ``domain_size``. With no incoming messages the result is all
        ones, because an empty product is one -- it is not zero.
    """
    raise NotImplementedError("TODO 3: complete variable_to_factor")


# --------------------------------------------------------------------------
# Given: the driver. It calls your three functions and nothing else.
# --------------------------------------------------------------------------
def sum_product(domains, local_functions, evidence, root=0):
    """Exact marginals on a tree, by one inward and one outward pass."""
    return engine.run(domains, local_functions, evidence, root,
                      factor_to_variable, variable_to_factor, normalize)
