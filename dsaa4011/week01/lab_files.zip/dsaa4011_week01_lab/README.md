# Week 1: Factor-graph audit

## Problem

Three neighboring machines have binary states: 0 means normal, and 1 means
alert. Machine 3 is observed in state 1. Compute the conditional distribution
of the middle state, `p(x2 | x3=1)`.

The local factor tables are

```text
f12 = [[4, 1],       f23 = [[3, 1],
       [2, 5]]              [1, 4]]
```

Rows index the first factor argument; columns index the second. The model
weight is `f12[x1, x2] * f23[x2, x3]`.

## Files

- `starter.py`: implement `normalize` and `chain_marginal`.
- `test_public.py`: public tests that may be extended.
- `lab.ipynb`: the 50-minute activity.
- `evidence_card.md`: the short reflection submitted after the laboratory.

## Required sequence

1. Compute the two unnormalized weights and their normalized vector by hand.
2. Save a test plan before asking a language model or coding agent for code.
3. Implement the two functions according to their docstrings.
4. Run `python -m pytest -q test_public.py`.
5. Diagnose the first failing requirement, repair it, and add a regression test.
6. Complete `evidence_card.md`.

This laboratory is formative practice for Coursework 1. It is not a separate
assessment. Any later private cases will test only the published categories:
input validation, factor-shape agreement, observation range, output shape,
normalization, and the declared axis order.

Requirements: Python 3 with `numpy` and `pytest` (`pip install numpy pytest`).
