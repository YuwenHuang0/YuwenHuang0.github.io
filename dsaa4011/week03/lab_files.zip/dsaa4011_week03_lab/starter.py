"""The five functions that you write in Laboratory 3.

Each function below has the same name, the same arguments and the same
meaning as in ``ising.py``; the module docstring of ``ising.py`` states the
conventions (a configuration is a vector of spins in ``{-1, +1}``; a
distribution is an array of ``2**n`` probabilities in the order of
``ising.all_configurations(n)``; logarithms are natural). Replace every
``raise NotImplementedError`` by your code, then check yourself with::

    LAB_MODULE=starter python -m pytest -q test_public.py

The notebook ``lab.ipynb`` compares your functions with those of ``ising.py``
in Tasks 3 to 6 once they no longer raise.
"""

from __future__ import annotations

import math

import numpy as np


def log_partition_function(energies, temperature):
    """Return ``ln Z_T = ln sum_s exp(-E(s)/T)`` without overflow (Task 3).

    Use the log-sum-exp identity: with ``m`` the largest value of ``-E/T``,
    ``ln sum exp(-E/T) = m + ln sum exp(-E/T - m)``. Every exponent on the
    right is at most zero.
    """
    raise NotImplementedError("Task 3: write log_partition_function with the log-sum-exp identity")


def entropy(p):
    """Return ``H(p) = -sum p ln p`` in nats, with ``0 ln 0 = 0`` (Task 4)."""
    raise NotImplementedError("Task 4: write entropy; skip the entries where p is zero")


def magnetization_distribution(p, configs):
    """Return ``(values, probabilities)`` of ``M = sum_i s_i`` under ``p`` (Task 5).

    ``values`` runs from ``-n`` to ``n`` in steps of two, and
    ``probabilities[k]`` is the total probability of the configurations
    whose spins sum to ``values[k]``.
    """
    raise NotImplementedError("Task 5: write magnetization_distribution from configs.sum(axis=1)")


def spin_correlation(p, configs, i, j):
    """Return ``E_p[s_i s_j]`` (Task 6)."""
    raise NotImplementedError("Task 6: write spin_correlation as a weighted sum of s_i s_j")


def mutual_information(p, configs, i, j):
    """Return ``I(s_i; s_j) = sum p(a, b) ln ( p(a, b) / (p(a) p(b)) )`` in nats (Task 6).

    Build the ``2 x 2`` marginal of the two spins first, then its row and
    column sums.
    """
    raise NotImplementedError("Task 6: write mutual_information from the 2 x 2 pair marginal")
