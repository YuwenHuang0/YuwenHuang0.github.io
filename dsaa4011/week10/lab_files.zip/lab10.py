"""Lab 10: transparent image-code experiments, not a trained VAE or diffusion model."""
import argparse
from html import escape
from pathlib import Path
import numpy as np

PATTERN=np.array([[1.,-1.],[-1.,1.]])
def matrix(value, label):
    raw=np.asarray(value)
    if np.iscomplexobj(raw):raise ValueError(label+' must be real-valued')
    try: arr=np.asarray(value,dtype=float)
    except (TypeError,ValueError) as exc:raise ValueError(label+' must be numeric') from exc
    if arr.ndim!=2 or not arr.size or not np.isfinite(arr).all():raise ValueError(label+' must be a nonempty finite 2D matrix')
    return arr

def toy_image():
    mean=np.linspace(.35,.65,16).reshape(4,4)
    contrast=np.full((4,4),.2)
    return decode(mean,contrast)
def encode(image):
    image=matrix(image,"image")
    if image.ndim!=2 or any(n%2 for n in image.shape):raise ValueError('Expected an even-sized grayscale matrix')
    blocks=image.reshape(image.shape[0]//2,2,image.shape[1]//2,2).transpose(0,2,1,3)
    return blocks.mean(axis=(2,3)),(blocks*PATTERN).mean(axis=(2,3))
def decode(mean,contrast=None):
    mean=matrix(mean,"mean")
    contrast=np.zeros_like(mean) if contrast is None else matrix(contrast,"contrast")
    if contrast.shape!=mean.shape:raise ValueError('Coefficient shapes must match')
    blocks=mean[:,:,None,None]+contrast[:,:,None,None]*PATTERN
    return blocks.transpose(0,2,1,3).reshape(mean.shape[0]*2,mean.shape[1]*2)
def mse(x,y):
    x=matrix(x,"x");y=matrix(y,"y")
    if x.shape!=y.shape:raise ValueError("MSE inputs must have identical shapes; broadcasting is not allowed")
    with np.errstate(over='raise',invalid='raise'):
        return float(np.mean((x-y)**2))
def svg(images,names,path):
    if not images or len(images)!=len(names):raise ValueError("Supply one label per image")
    images=[matrix(im,"image") for im in images]
    cell=26;panel=max(260,max(im.shape[1] for im in images)*cell+30)
    width=len(images)*panel;height=max(280,max(im.shape[0] for im in images)*cell+65)
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}"><rect width="100%" height="100%" fill="white"/>']
    for k,(im,name) in enumerate(zip(images,names)):
        parts.append(f'<text x="{k*panel+15}" y="25" font-family="sans-serif" font-size="17">{escape(str(name))}</text>')
        for r in range(im.shape[0]):
            for c in range(im.shape[1]):
                v=round(255*float(np.clip(im[r,c],0,1)))
                parts.append(f'<rect x="{k*panel+15+c*cell}" y="{45+r*cell}" width="25" height="25" fill="rgb({v},{v},{v})"/>')
    parts.append('</svg>');path.write_text(''.join(parts),encoding='utf-8')
def run(name,out):
    if name not in {"compress","attention","noise"}:raise ValueError("Unknown experiment: "+str(name))
    out=Path(out);out.mkdir(parents=True,exist_ok=True);im=toy_image();m,c=encode(im)
    if name=='compress':
        flipped=decode(m,-c);mean_only=decode(m);exact=decode(m,c)
        assert np.allclose(encode(im)[0],encode(flipped)[0])
        print('mean-only MSE:',mse(im,mean_only));print('two-channel MSE:',mse(im,exact));print('different pictures have identical means:',np.allclose(encode(im)[0],encode(flipped)[0]))
        svg([im,flipped,mean_only,exact],['Original','Reversed detail','Mean-only decode','Two-channel decode'],out/'compression.svg')
    elif name=='attention':
        for label,h,w,ch in [('pixels',8,8,1),('mean code',4,4,1),('two-channel code',4,4,2)]:
            n=h*w;print(label,': entries =',n*ch,', positions =',n,', full-attention pairs =',n*n)
        print('Pair counts are not measured total running times.')
    else:
        rng=np.random.default_rng(10);nm=rng.normal(size=m.shape);nc=rng.normal(size=c.shape)
        images=[];names=[]
        for sigma in [0.,.05,.15]:
            decoded=decode(m+sigma*nm,c+sigma*nc);images.append(decoded);names.append('Noise '+str(sigma));print('noise',sigma,'MSE',mse(im,decoded))
        svg(images,names,out/'latent_noise.svg');print('No denoiser is trained here; noise injection is not diffusion sampling. SVG display clips values to [0,1]; MSE uses unclipped values.')
def main():
    parser=argparse.ArgumentParser();parser.add_argument('experiment',choices=['compress','attention','noise']);parser.add_argument('--out',type=Path,default=Path('results'));args=parser.parse_args();run(args.experiment,args.out)
if __name__=='__main__':main()
