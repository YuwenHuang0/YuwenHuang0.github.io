# DSAA 4011 Lab 4 · Explore after class

Four small experiments with the walker of Lecture 4, the Metropolis–Hastings sampler that never computes the impossible sum Z. They match the slides of Lab 4, *Sampling What We Cannot Sum*.

| Run | Experiment | You write | First predict |
|---|---|---|---|
| `python lab4_explore.py 1` | The walker: its visits follow the fits | the test (1 line) | With fits 1, 2, 5, what share of its time does the walker spend at each picture? |
| `python lab4_explore.py 2` | Far-apart hills trap the walker | the test and a crossing check (2 lines) | If the hills move twice as far apart, does the waiting time double? |
| `python lab4_explore.py 3` | Heat a copy: parallel tempering | the swap test (2 lines) | With T = 1 (the copy is not hotter), does swapping help at all? |
| `python lab4_explore.py 4` | Generate from noise: annealed Langevin dynamics | one Langevin step (1 line) | What goes wrong if you skip the large noise levels? |

Each file section ends with a **TRY** line: one more change to explore.

**Setup.** Python 3 with `numpy` and `matplotlib`. Every run is seeded, so you and your neighbour see the same numbers. Until you fill in a TODO, that experiment stops with a short message telling you what to write.

**Going further.** Each experiment is a toy version of a frontier result in the lab:
- Experiment 3 is the trick that weighed the black holes of GW150914.
- Experiment 4 is the idea behind diffusion image generators.

The references on the slides are good starting points for a course project.
