# Evidence card - Week 1: Factor-graph audit

## Hand prediction
Record the two unnormalized weights and the normalized vector.

## Test purpose
Name the plausible error that your strongest test can reveal.

## First violated requirement
State the function contract or mathematical operation that failed.

## Minimal repair
State what changed and why the change implements the declared formula.

## Evidence
Record the failing result before repair and the passing result after repair.

## Remaining limitation
Name one relevant case that your evidence does not cover.

## AI decision record, if applicable
Record the tool, the suggestion that changed a modeling, coding, or evaluation
decision, your decision, and the test or calculation used to check it. Do not
submit a complete private chat history.
