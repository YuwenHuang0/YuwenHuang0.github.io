import importlib
import os
import numpy as np
import pytest

M = importlib.import_module(os.environ.get("LAB_MODULE", "starter"))

def test_normalize():
    assert np.allclose(M.normalize([1, 3]), [.25, .75])

def test_asymmetric_chain():
    f12 = np.array([[4., 1.], [2., 5.]])
    f23 = np.array([[3., 1.], [1., 4.]])
    expected = np.array([1 / 5, 4 / 5])
    assert np.allclose(M.chain_marginal(f12, f23, 1), expected)
