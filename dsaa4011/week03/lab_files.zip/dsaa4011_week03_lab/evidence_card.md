# Week 3 evidence card

Name: ______________________    Date: ______________

This card records what you predicted and what you found while working
through the notebook `lab.ipynb`. Write every prediction **before** the
run. A prediction that turned out wrong, followed by the reason, is worth
more than a right one without a reason. The task numbers are those of the
slides and of the notebook.

## The small Ising model

Task 3. Your prediction of what the direct sum $\sum_s \exp(-E(s)/T)$
returns at $T = 0.01$, written before the run, and then the result:

Task 4. Your predicted limit of the entropy $H(p_T)$ as $T \to 0$, the
value that the sweep gave at $T = 0.25$, and one sentence linking the two
to Proposition 22 of Lecture Slides 3:

Task 5. What $E[s_i] = 0$ hides, and which quantity shows the two modes:

Task 6. Your prediction of the corner correlation $E[s_0 s_{15}]$ on the
grid against the chain value $\tanh(1/2)^6 = 0.0097$ at distance six,
written before the run, and then the result:

Task 7. The exploration you chose (E1 to E4):

| exploration | hypothesis | prediction | result | explanation |
|---|---|---|---|---|
|  |  |  |  |  |

## Task 8, the research track (if done): pre-registration and verdict

Fill in the first five lines before running, the last three after. Do not
change the first five once the numbers are in.

| | your entry |
|---|---|
| Question that a number can answer |  |
| Hypothesis |  |
| Prediction, with a threshold |  |
| Baseline it must beat |  |
| What result would refute it |  |
| Result against the threshold | supported / refuted / unclear |
| Where the trend stops or slows |  |
| What I would try next, and why |  |

## Reproducibility record

| | your entry |
|---|---|
| NumPy version |  |
| Float dtype of the energies |  |
| Temperature grid of the sweep |  |
| Finite-difference step (Task 8) |  |
| Which numbers you checked against enumeration |  |

## Task 9. One claim, one test, one limit

Claim I am willing to defend:

The single test that supports it most strongly:

One condition I did **not** test:
