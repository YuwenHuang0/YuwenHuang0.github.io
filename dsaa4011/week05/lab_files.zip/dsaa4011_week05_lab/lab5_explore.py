"""DSAA 4011 Lab 5, explore after class: learning what we never see.

Five small experiments with expectation-maximization (EM) from Lecture 5: guess the hidden labels softly (E-step),
count with them (M-step), repeat. Each experiment asks you to PREDICT first, then complete one to three lines
marked TODO, then run.

    python lab5_explore.py 1        # two coins: EM rounds from three starts
    python lab5_explore.py 2        # crowd labelling: whom to trust?
    python lab5_explore.py 3        # k-means cells: search one cell instead of everything
    python lab5_explore.py 4        # Program 4, a word cutter: EM over all cuts of a word
    python lab5_explore.py 5        # Program 5, a tiny reasoner: keep the traces that reach the right answer

Needs numpy and matplotlib. Every run is seeded, so you and your neighbour get the same numbers.
"""
import sys
import numpy as np
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------------------------
# Experiment 1. Two coins, one hidden (Lecture 5). Records HH, HT, TT; each was made by coin A or B
# (picked with chance 1/2). EM: soft labels, then count heads, repeat.
# PREDICT: starting from (thetaA, thetaB) = (0.6, 0.6), where does EM go, and why?
# ---------------------------------------------------------------------------------------------
RECORDS = [(2, 0), (1, 1), (0, 2)]                     # (heads, tails) of HH, HT, TT


def em_coins(theta_a, theta_b, rounds=20):
    path = [(theta_a, theta_b)]
    for _ in range(rounds):
        heads_a = flips_a = heads_b = flips_b = 0.0
        for h, t in RECORDS:
            pa = 0.5 * theta_a ** h * (1 - theta_a) ** t
            pb = 0.5 * theta_b ** h * (1 - theta_b) ** t
            # TODO (1 line): the soft label q = share of this record given to coin A (the E-step)
            raise NotImplementedError("Experiment 1: write the soft label")
            heads_a += q * h; flips_a += q * (h + t)
            heads_b += (1 - q) * h; flips_b += (1 - q) * (h + t)
        theta_a, theta_b = heads_a / flips_a, heads_b / flips_b        # the M-step: count and divide
        path.append((theta_a, theta_b))
    return np.array(path)


def experiment1():
    for start in [(0.75, 0.25), (0.6, 0.4), (0.6, 0.6)]:
        p = em_coins(*start)
        print("start %-12s round 1: thetaA = %.3f   after 20 rounds: thetaA = %.3f, thetaB = %.3f"
              % (start, p[1, 0], p[-1, 0], p[-1, 1]))
        plt.plot(p[:, 0], "o-", label="thetaA from %s" % (start,))
    plt.axhline((3 + 3 ** 0.5) / 6, color="#0057e7", ls="--", label="the peak 0.789")
    plt.xlabel("round"); plt.ylabel("thetaA"); plt.legend(); plt.title("Experiment 1: EM on two coins"); plt.show()
    # TRY: start from (0.4, 0.6). Which coin ends up with the larger heads chance, and why?


# ---------------------------------------------------------------------------------------------
# Experiment 2. Crowd labelling [Dawid and Skene, 1979]. Three people label 8 photos as cat (1) or dog (0).
# The true label is the hidden coin; person k is right with an unknown accuracy a_k.
# PREDICT: person 3 disagrees with the others on 3 photos; persons 1 and 2 each slip once. What will EM say about their accuracy?
# ---------------------------------------------------------------------------------------------
LABELS = np.array([   # rows: photos; columns: persons 1, 2, 3
    [1, 1, 0], [0, 0, 0], [1, 1, 1], [0, 0, 1], [1, 1, 1], [1, 0, 0], [1, 1, 0], [1, 0, 1]])


def crowd_em(rounds=10, a0=0.8):
    a = np.full(LABELS.shape[1], a0)
    for _ in range(rounds):
        # E-step: soft truth q = chance that each photo is a cat, given the labels and the accuracies
        like_cat = np.prod(np.where(LABELS == 1, a, 1 - a), axis=1)
        like_dog = np.prod(np.where(LABELS == 0, a, 1 - a), axis=1)
        q = like_cat / (like_cat + like_dog)
        # TODO (1 line): the M-step. a_k = expected number of photos person k got right / number of photos.
        #                (Person k is right on photo i with chance q_i if they said cat, 1 - q_i if they said dog.)
        raise NotImplementedError("Experiment 2: write the M-step")
    return q, a


def experiment2():
    q, a = crowd_em()
    print("soft truth (chance of cat) per photo:", np.round(q, 2))
    print("accuracy per person:", np.round(a, 3))
    print("majority vote:", (LABELS.sum(axis=1) >= 2).astype(int))
    plt.bar(["person 1", "person 2", "person 3"], a, color="#c86400")
    plt.ylim(0, 1); plt.title("Experiment 2: EM learns whom to trust"); plt.show()
    # TRY: make person 3 answer at random (replace column 3 by random 0/1). What happens to a_3?


# ---------------------------------------------------------------------------------------------
# Experiment 3. k-means cells for search. 2,000 "texts" as 2-D vectors. Put them in K cells by k-means
# (EM with hard labels), then answer each query by searching only its own cell.
# PREDICT: with more cells, how many distance computations do you save, and how often is the true nearest
# neighbour missed?
# ---------------------------------------------------------------------------------------------
def kmeans(X, K, rounds=20, seed=0):
    rng = np.random.default_rng(seed)
    centres = X[rng.choice(len(X), K, replace=False)]
    for _ in range(rounds):
        d = np.linalg.norm(X[:, None, :] - centres[None], axis=2)
        # TODO (1 line): the hard E-step. cell[i] = index of the nearest centre of point i.
        raise NotImplementedError("Experiment 3: write the nearest-centre step")
        centres = np.array([X[cell == k].mean(axis=0) if np.any(cell == k) else centres[k] for k in range(K)])
    return centres, cell


def experiment3():
    rng = np.random.default_rng(1)
    X = rng.standard_normal((2000, 2)); Q = rng.standard_normal((200, 2))
    for K in (3, 10, 40):
        centres, cell = kmeans(X, K)
        missed = cost = 0
        for q in Q:
            c = np.argmin(np.linalg.norm(centres - q, axis=1))
            inside = np.where(cell == c)[0]
            cost += K + len(inside)
            best = np.argmin(np.linalg.norm(X - q, axis=1))
            missed += best not in inside
        print("K = %2d cells: %4.0f distance computations per query (instead of 2000), nearest neighbour missed %2.0f%%"
              % (K, cost / len(Q), 100 * missed / len(Q)))
    # TRY: search the 2 nearest cells instead of 1. What do you gain and pay?


# ---------------------------------------------------------------------------------------------
# Experiment 4 (Program 4). A word cutter: the Unigram tokenizer [Kudo, 2018] on one word. Each piece n, o, no, on, oo
# has a chance; a cut of "noon" has the product of its pieces' chances. EM: the share of each cut (E-step), then
# piece chance = weighted count of the piece / weighted count of all pieces (M-step).
# PREDICT: with all pieces equally likely at the start, which cut wins? And if "oo" starts favoured?
# ---------------------------------------------------------------------------------------------
PIECES = ["n", "o", "no", "on", "oo"]


def cuts(word):
    """Every way to cut word into pieces from PIECES, each as a tuple of pieces."""
    if not word:
        return [()]
    return [(p,) + rest for p in PIECES if word.startswith(p) for rest in cuts(word[len(p):])]


def em_cut(chance, word="noon", rounds=4):
    chance = dict(zip(PIECES, chance))
    all_cuts = cuts(word)
    for r in range(1, rounds + 1):
        weight = {c: np.prod([chance[p] for p in c]) for c in all_cuts}
        # TODO (1 line): share = {cut: its weight / the total weight of all cuts}   (the E-step)
        raise NotImplementedError("Experiment 4: write the share of each cut")
        count = {p: sum(share[c] * c.count(p) for c in all_cuts) for p in PIECES}
        total = sum(count.values())
        chance = {p: count[p] / total for p in PIECES}                 # the M-step: count and divide
        best = max(share, key=share.get)
        print("  round %d: best cut %-10s share %.3f" % (r, "|".join(best), share[best]))
    return chance


def experiment4():
    print("all pieces equally likely:")
    em_cut([1 / 5] * 5)
    print("oo favoured (n 1/4, oo 1/2, the others 1/12):")
    em_cut([1 / 4, 1 / 12, 1 / 12, 1 / 12, 1 / 2])
    # TRY: a 20-letter word has up to 2**19 cuts. Replace the list of cuts by a running total, letter by letter
    #      (forward-backward, Lecture 5, Section 6), and check that you get the same shares.


# ---------------------------------------------------------------------------------------------
# Experiment 5 (Program 5). A tiny reasoner (Monte Carlo EM, as in STaR [Zelikman et al., 2022]). The model writes careful
# reasoning with chance pi (right answer with chance 3/4) or hasty reasoning (right with chance 1/4).
# Each round: sample 1,000 questions, KEEP only the traces whose answer is right, and set pi to the share of
# careful traces among those kept.
# PREDICT: starting at pi = 1/2, what is pi after one round? After five?
# ---------------------------------------------------------------------------------------------
def star(pi=0.5, rounds=5, n=1000, keep_all=False, seed=4):
    rng = np.random.default_rng(seed)
    path = [pi]
    for _ in range(rounds):
        careful = rng.random(n) < pi
        right = rng.random(n) < np.where(careful, 0.75, 0.25)
        # TODO (2 lines): kept = the traces to train on (only the right ones, or all of them if keep_all);
        #                 then pi = the share of careful traces among the kept.
        raise NotImplementedError("Experiment 5: write the keep-and-retrain step")
        path.append(pi)
    return path


def experiment5():
    for keep_all in (False, True):
        p = star(keep_all=keep_all)
        print("%-24s pi per round: %s" % ("keep everything:" if keep_all else "keep right answers:", np.round(p, 3)))
        plt.plot(p, "o-", label="keep everything" if keep_all else "keep right answers")
    plt.xlabel("round"); plt.ylabel("share of careful reasoning"); plt.legend()
    plt.title("Experiment 5: keeping right answers teaches careful reasoning"); plt.show()
    # TRY: what if hasty reasoning were right as often as careful reasoning (0.75 and 0.75)?


if __name__ == "__main__":
    {"1": experiment1, "2": experiment2, "3": experiment3, "4": experiment4, "5": experiment5}.get(
        sys.argv[1] if len(sys.argv) > 1 else "1", experiment1)()
