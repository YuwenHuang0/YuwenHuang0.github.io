# Week 2 evidence card

Name: ______________________    Date: ______________

This card records what you predicted and what you found while working
through the notebook `lab.ipynb`. Write every prediction **before** the
run. A prediction that turned out wrong, followed by the reason, is worth
more than a right one without a reason. The task numbers are those of the
slides and of the notebook.

## The diffusion chain

Task 2. Your prediction of $q(x_4)$, written before the forward sweep:

Task 3. Your reverse transition agrees with the reference: yes / no. If no,
what differed?

Task 4. Your prediction of the proportions, written before ancestral
sampling, and the proportions of the 5000 samples:

Task 5. The exploration you chose (E1 to E5):

| exploration | hypothesis | prediction | result | explanation |
|---|---|---|---|---|
|  |  |  |  |  |

Task 6. The denoising posterior by message passing and by enumeration
agree: yes / no.

In one sentence: what does a diffusion model learn, in the words of this
week?

## Task 7, the research track (if done): pre-registration and verdict

Fill in the first five lines before running, the last three after. Do not
change the first five once the numbers are in.

| | your entry |
|---|---|
| Question that a number can answer |  |
| Hypothesis |  |
| Prediction, with a threshold |  |
| Baseline it must beat |  |
| What result would refute it |  |
| Result against the threshold | supported / refuted / unclear |
| Where the repair stops working or hurts |  |
| What I would try next, and why |  |

## Task 8. One claim, one test, one limit

Claim I am willing to defend:

The single test that supports it most strongly:

One condition I did **not** test:
