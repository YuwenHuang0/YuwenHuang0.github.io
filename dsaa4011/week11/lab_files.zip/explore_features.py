"""Small, CPU-only experiments on real, saved DINOv3 feature maps."""
from pathlib import Path
import json
import numpy as np
from PIL import Image

DATA = Path(__file__).resolve().parent / 'data'

def load_example(name='cats', method='dino'):
    """Return the 256-square RGB image and aligned 16-by-16 feature grid."""
    if name not in ('cats', 'retina') or method not in ('dino', 'rgb'):
        raise ValueError('Choose cats/retina and dino/rgb.')
    suffix='features' if method=='dino' else 'rgb'
    with np.load(DATA/f'{name}_{suffix}.npz', allow_pickle=False) as z:
        features=z['features'].copy()
    image=np.asarray(Image.open(DATA/f'{name}.png').convert('RGB'))
    validate_features(features)
    return image,features

def validate_features(features):
    f=np.asarray(features)
    if f.ndim!=3 or min(f.shape)<1 or not np.isfinite(f).all():
        raise ValueError('Features must have finite values and shape rows, columns, channels.')
    return f.astype(np.float64,copy=False)

def cosine_similarity(features, row, col):
    """Compare each location with ONE selected vector. Scores are NOT probabilities."""
    f=validate_features(features)
    if isinstance(row,bool) or isinstance(col,bool) or not isinstance(row,(int,np.integer)) or not isinstance(col,(int,np.integer)):
        raise ValueError('Row and column must be integer indices.')
    if not (0<=row<f.shape[0] and 0<=col<f.shape[1]):
        raise ValueError('Query is outside this feature grid.')
    norms=np.linalg.norm(f,axis=-1)
    if norms[row,col]<=1e-12:
        raise ValueError('Cosine is undefined for a zero query vector. Choose another location.')
    unit=np.divide(f,norms[...,None],out=np.zeros_like(f),where=norms[...,None]>1e-12)
    scores=np.einsum('hwc,c->hw',unit,unit[row,col])
    return np.clip(scores,-1,1)

def pca_colours(features):
    """Fit one PCA to this grid, then map 3 projected coordinates to display RGB."""
    f=validate_features(features);a=f.reshape(-1,f.shape[-1]);a=a-a.mean(0)
    _,_,vt=np.linalg.svd(a,full_matrices=False)
    projection=a@vt[:min(3,len(vt))].T
    if projection.shape[1]<3:projection=np.pad(projection,((0,0),(0,3-projection.shape[1])))
    lo=np.percentile(projection,2,axis=0);hi=np.percentile(projection,98,axis=0)
    rgb=np.clip((projection-lo)/np.maximum(hi-lo,1e-12),0,1)
    return rgb.reshape(f.shape[0],f.shape[1],3)

def prototype_score(features, positive, negative):
    """Optional two-click head: similarity to positive minus similarity to negative."""
    return cosine_similarity(features,*positive)-cosine_similarity(features,*negative)

def show_query(image,features,row,col,title='DINOv3',threshold=.6):
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    if not np.isfinite(threshold) or not -1<=threshold<=1:
        raise ValueError('Similarity threshold must be in [-1, 1].')
    scores=cosine_similarity(features,row,col)
    h,w=features.shape[:2];ph=image.shape[0]/h;pw=image.shape[1]/w
    fig,axes=plt.subplots(1,3,figsize=(11,3.8),layout='constrained')
    axes[0].imshow(image);axes[0].add_patch(Rectangle((col*pw,row*ph),pw,ph,fill=False,edgecolor='#00e6df',linewidth=2))
    axes[0].set_title(f'Query: row {row}, column {col} (0-based)')
    plot=axes[1].imshow(scores,cmap='magma',vmin=-1,vmax=1,interpolation='nearest')
    axes[1].set_title(f'{title}: cosine similarity')
    fig.colorbar(plot,ax=axes[1],fraction=.046,label='Similarity, not probability')
    axes[2].imshow(scores>=threshold,cmap='gray',vmin=0,vmax=1,interpolation='nearest')
    axes[2].set_title(f'Similarity ≥ {threshold:g}\nnot a trained segmentation')
    for ax in axes:ax.axis('off')
    return fig,scores

def run(name='cats',row=6,col=5,method='dino',threshold=.6,output='runs/query'):
    import matplotlib.pyplot as plt
    image,f=load_example(name,method)
    fig,scores=show_query(image,f,row,col,method.upper(),threshold)
    dest=Path(output);dest.mkdir(parents=True,exist_ok=True)
    fig.savefig(dest/'query.png',dpi=150);plt.close(fig)
    np.save(dest/'similarity.npy',scores,allow_pickle=False)
    record={'image':name,'method':method,'query_0_based':[row,col],'feature_shape':list(f.shape),
            'threshold':float(threshold),'query_self_similarity':float(scores[row,col]),
            'selected_cells':int((scores>=threshold).sum()),'cell_count':int(scores.size),
            'warning':'A similarity mask is not a vessel prediction or an accuracy measurement.'}
    (dest/'result.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    return record

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image',choices=['cats','retina'],default='cats')
    parser.add_argument('--method',choices=['dino','rgb'],default='dino')
    parser.add_argument('--row',type=int,default=6);parser.add_argument('--col',type=int,default=5)
    parser.add_argument('--threshold',type=float,default=.6);parser.add_argument('--output',default='runs/query')
    a=parser.parse_args();print(json.dumps(run(a.image,a.row,a.col,a.method,a.threshold,a.output),indent=2))
