# Week 2 laboratory: the diffusion chain

This directory contains the material of *Laboratory Slides 2*. In the
laboratory session the instructor presents the main ideas and you read the
slides. The notebook `lab.ipynb` and the program `chains.py` are for
exploration after the session, at your own pace; the notebook follows the
slides task by task.

## The question of the laboratory

The lecture ran the sum-product and the max-product algorithm on a tree of
five machines. This laboratory runs the same two rules on a chain from
current machine learning: a diffusion model is a chain factor graph. Its
noise schedule is a sequence of forward messages, the reverse transition
that the model learns is a ratio of forward messages, and sampling from the
model is ancestral sampling on the chain. The research track asks what a
real denoising network can and cannot represent.

## The files

| file | contents |
|---|---|
| `lab.ipynb` | the notebook: Tasks 1 to 8, the research track, references |
| `chains.py` | the chain, the two rules on a chain, and the reference; `python chains.py` prints every number quoted on the slides, and `python chains.py --check` compares every number with brute-force enumeration |
| `evidence_card.md` | the record of your predictions and results: one claim, one test, one limit |
| `starter.py`, `test_public.py` | the exercises of the tree solver (`factor_to_variable`, `variable_to_factor`, `normalize`) and their tests |
| `model.py`, `engine.py` | the tree solver of the lecture, in the `(domains, local_functions, evidence)` convention |
| `requirements.txt` | the Python packages: `pip install -r requirements.txt` |

## The eight tasks

The table is the same as on the slides and in the notebook.

| task | what you do | expected output |
|---|---|---|
| 1 | run the first cell; read `chain_messages` in `chains.py` | none; this task is reading |
| 2 | write what you expect $q(x_4)$ to be; run the forward sweep | five lines, ending near (0.25, 0.25, 0.25, 0.25) |
| 3 | write `my_reverse_transition(t)` from equation (5) of the slides | four lines of `True` |
| 4 | predict, then draw 5000 pictures by ancestral sampling | about (0.55, 0.05, 0.05, 0.35) |
| 5 | one exploration, E1 to E5; if unsure, E5 (already written) | what you predicted, or not |
| 6 | check the denoising posterior against enumeration | `agree: True` |
| 7 | research track, optional: the factorized reverse transition | the tables of the slides |
| 8 | fill in `evidence_card.md` | one claim, one test, one limit |

## Names on the slides and in the code

| on the slides | in the code |
|---|---|
| the two rules (1) and (2), on a chain | `chain_messages(unary, pairwise, mode)` |
| the reference, on a chain | `enumerate_chain(unary, pairwise, mode)` |
| $m_{f \to i}$, on any tree | `factor_to_variable(scope, table, target, incoming)` |
| $m_{i \to f}$, on any tree | `variable_to_factor(domain_size, incoming)` |
| the normalized belief | `normalize(...)` |
| the whole tree | `sum_product(domains, local_functions, evidence, root=0)` |
| the degree-two warm-up | `factor_message(factor, incoming)`, `variable_belief(left, right)` |
| the reference, on any tree | `enumerate_marginals(domains, local_functions, evidence)` |
| the transition matrix $Q_t$ | `transition_matrix(beta, pixels)` |
| the marginals $q(x_t)$ | `forward_marginals(data, schedule, pixels)` |
| the reverse transition $R_t$ | `reverse_transition(t, data, schedule, pixels)` |
| ancestral sampling | `ancestral_sample(n, rng, reverse_fn=...)` |
| the denoising posterior | `denoising_posterior(observed, step=t)` |
| the number of steps until noise | `steps_until_noise(schedule)` |
| the factorized reverse transition $F_t$ | `factorized_reverse_transition(t)` |
| the factorization error, the sampling error | `factorization_error(t)`, `sampling_error(reverse_fn=...)` |
| the pairwise correction $\varphi$ | `pairwise_correction()`, with `normalize_rows` |
| the equal-step schedule | `equal_step_schedule(k)` |

Every helper accepts your own `data`, `schedule` and `pixels`.

## The research track (Task 7)

A denoising network for pictures with $n$ pixels cannot output the reverse
transition, which has $4^n$ entries. It outputs one distribution per pixel
and multiplies them: a Gaussian with covariance $\sigma_t^2 I$ in Ho, Jain
and Abbeel (2020, equation 1), and one categorical distribution per position
in Austin et al. (2021) and in the masked diffusion language models of Sahoo
et al. (2024) and Nie et al. (2025). This is allowed because a small noise
step reverses in the same functional form as it goes forward
(Sohl-Dickstein et al. 2015, section 2.2, citing Feller 1949). On the
two-pixel chain both tables can be computed. The factorized transition keeps
every per-pixel marginal exact and still has a sampling error of 0.075,
against 0.002 for the exact transition; the error falls with more, smaller
steps (0.087 with 8 equal steps, 0.047 with 16) and depends on a pairwise
correction whose right strength varies with the step. Which correction to
apply at each step, and how to learn it, is open.

## Further exploration, not on the slides

`chains.py` also contains a second chain: a chain of reasoning steps scored
by a verifier, read by greedy, MAP and marginal decoding
(`example_problem`, `greedy_decoding`, `map_decoding`, `marginal_decoding`,
`run_experiment`, `sweep`, `order_experiment`). It is left for your own
exploration; `python chains.py` prints its numbers too.

## Checks

```
python chains.py --check
python chains.py
python -m pytest -q test_public.py
```

## Using AI

You may use any assistant for the code. Do not paste chat transcripts;
nobody grades prompt style. What the evidence card examines is the
hypothesis and the prediction that you wrote before each run, the reference
that you compared against, the boundary case that you found, and your
explanation.

## What to save

`evidence_card.md` and the notebook. This laboratory is formative practice
and carries no separate mark.

## References

The numbers are those of the slides; the full list, with all authors,
titles and venues, is in the last section of the slides and at the end of
the notebook.
